package MovieRecord;

import java.util.LinkedList;

public class Delete_MovieID {
    LinkedList<MovieList> namelist = new LinkedList<>();
    UserInput userInput = new UserInput();
    Search_Movie search = new Search_Movie();

    public Delete_MovieID(LinkedList<MovieList> namelist) {
        this.namelist = namelist;}

    public void delete() {
        String id = userInput.get_ID();
        String date = userInput.get_release_date();
        String revenue = userInput.get_revenue();
        String runtime = userInput.get_runtime();
        String title = userInput.get_title();
        String vote = userInput.get_voteAverage();
        String company = userInput.get_companie();
        String genre = userInput.get_genre();
        String prod = userInput.get_prodCountry();
        int index = search.searchMovie(namelist,id,date,revenue,runtime,
                title,vote,company,genre,prod);
        while (index<0)
        {
            System.out.println("Movie ID doesn't exist");
            id = userInput.get_ID();
            date = userInput.get_release_date();
            revenue = userInput.get_revenue();
            runtime = userInput.get_runtime();
            title = userInput.get_title();
            vote = userInput.get_voteAverage();
            company = userInput.get_companie();
            genre = userInput.get_genre();
            prod = userInput.get_prodCountry();
            index = search.searchMovie(namelist,id,date,revenue,runtime,
                    title,vote,company,genre,prod);
        }
        namelist.remove(index);
        search.write_to_Database("Data/movies.csv",namelist);
        System.out.println("Movie deleted successfully");
    }
    }

