package MovieRecord;

import java.util.Scanner;

public class UserInput {
    Scanner sc = new Scanner(System.in);
    public String get_ID() {
        System.out.println("Enter Movie ID : ");
        String input = sc.nextLine();
        if (input.matches("[1-9][0-9]{5}]")) {
            System.out.println("Enter Valid Movie ID : ");
            input = get_ID();
        }
        return input;
    }

    public String get_release_date() {
        System.out.println("Please enter Release Date (dd/mm/yyyy) ");
        String input = sc.nextLine();
        if (!input.matches("(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/[1-9][0-9]{3}")) {
            System.out.println("Enter Valid Release Date : ");
            input = get_release_date();
        }
        return input;
    }

    public String get_revenue() {
        System.out.println("Enter Movie Revenue");
        String input = sc.nextLine();
        if (!input.matches("[1-9][0-9]*")) {
            System.out.println("Enter Valid Revenue : ");
            input = get_revenue();
        }
        return input;
    }

    public String get_runtime() {
        System.out.println("Enter Movie Runtime");
        String input = sc.nextLine();
        if (!input.matches("[1-9][0-9]*")) {
            System.out.println("Enter Valid Runtime : ");
            input = get_runtime();
        }
        return input;
    }

    public String get_title() {
        System.out.println("Enter Movie Title");
        String input = sc.nextLine();
        if (input.matches("[A-Z][a-z]{1,20}")) {
            System.out.println("Movie Title must be in Alphabet : ");
            input = get_title();
        }
        return input;
    }

    public String get_voteAverage() {
        System.out.println("Enter Movie Vote Average");
        String input = sc.nextLine();
        if (!input.matches("[1-9][0-9]*")) {
            System.out.println("Enter Valid Vote Average : ");
            input = get_voteAverage();
        }
        return input;
    }

    public String get_companie() {
        System.out.println("Enter Movie Company");
        String input = sc.nextLine();
        if (!input.matches("[A-Z][a-z]{1,20}")) {
            System.out.println("Enter Valid Company : ");
            input = get_companie();
        }
        return input;
    }

    public String get_genre() {
        System.out.println("Enter Movie Genre");
        String input = sc.nextLine();
        if (input.matches("[A-Z][a-z]{1,20}")) {
            System.out.println("Enter Valid Genre : ");
            input = get_genre();
        }
        return input;
    }

    public String get_prodCountry() {
        System.out.println("Enter Movie Prod Country");
        String input = sc.nextLine();
        if (input.matches("[A-Z][a-z]{1,20}")) {
            System.out.println("Enter Valid Prod Country : ");
            input = get_prodCountry();
        }
        return input;
    }

}
