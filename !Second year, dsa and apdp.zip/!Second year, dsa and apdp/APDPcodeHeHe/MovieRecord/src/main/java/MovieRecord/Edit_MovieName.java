package MovieRecord;

import java.util.LinkedList;

public class Edit_MovieName {
    LinkedList<MovieList> namelist = new LinkedList<>();
    UserInput userInput = new UserInput();
    Search_Movie search = new Search_Movie();

    public Edit_MovieName(LinkedList<MovieList> namelist) {
        this.namelist = namelist;
    }
    public void edit()
    {
        String movie_id = userInput.get_ID();
        String release_date = userInput.get_release_date();
        String revenue = userInput.get_revenue();
        String runtime = userInput.get_runtime();
        String title = userInput.get_title();
        String voteAverage = userInput.get_voteAverage();
        String company = userInput.get_companie();
        String genre = userInput.get_genre();
        String prodCountry = userInput.get_prodCountry();

        int index = search.searchMovie
                (namelist,movie_id,release_date,revenue,runtime,title,voteAverage,
                        company,genre,prodCountry);

        while (index<0)
        {
            System.out.println("Baby Name does not exist");
            movie_id = userInput.get_ID();
            release_date = userInput.get_release_date();
            revenue = userInput.get_revenue();
            runtime = userInput.get_runtime();
            title = userInput.get_title();
            voteAverage = userInput.get_voteAverage();
            company = userInput.get_companie();
            genre = userInput.get_genre();
            prodCountry = userInput.get_prodCountry();
            index = search.searchMovie(namelist,movie_id,release_date,revenue,
                    runtime,title,voteAverage,company,genre,prodCountry);
        }
        System.out.println("Enter Movie Data to Edit ");
        movie_id = userInput.get_ID();
        release_date = userInput.get_release_date();
        revenue = userInput.get_revenue();
        runtime = userInput.get_runtime();
        title = userInput.get_title();
        voteAverage = userInput.get_voteAverage();
        company = userInput.get_companie();
        genre = userInput.get_genre();
        prodCountry = userInput.get_prodCountry();

        namelist.set(index,new MovieList(Integer.parseInt(movie_id),release_date, Integer.parseInt(revenue),
                Integer.parseInt(runtime),title,voteAverage,company,genre,prodCountry));
        search.write_to_Database("Data/movies.csv", namelist);
    }

    public void edit(String movie_id,String release_date,String revenue,String runtime,String title,String voteAverage,
                     String company,String genre,String prodCountry)
    {
        int index= search.searchMovie(namelist,movie_id,release_date,revenue,
                runtime,title,voteAverage,company,genre,prodCountry);
         search.write_to_Database("Data/movies.csv", namelist);
        System.out.println("Successfully edited movie ");
    }
}
