package MovieRecord;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class Movie_main {
    static Scanner sc = new Scanner(System.in);
    static LinkedList<MovieList> namelist = new LinkedList<>();     //namelist -> movienamelist
    public LinkedList<MovieList> dataRead(String filename)
    {
        namelist = new LinkedList<>();
        FileReader fr = null;
        try {
            fr = new FileReader(filename);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        CSVReader csvReader = new CSVReader(fr);
        String[] str;
        while (true)
        {
            try {
                if (!((str = csvReader.readNext() )!=null)) break;
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            } catch (CsvValidationException e){
                throw new RuntimeException(e);
            }
            try {
                namelist.add(new MovieList(Integer.parseInt(str[0]),
                        str[1],
                        Integer.parseInt(str[2]),
                        Integer.parseInt(str[3]),
                        str[4],
                        str[5],
                        str[6],
                        str[7],
                        str[8]));

            }catch (NumberFormatException e) {

            }
        }
        try {
            csvReader.close();
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fr.close();
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
        return namelist;
    }

    public static void display() {
        System.out.println("Welcome to the Movie_Database");
        System.out.println("1. Add a movie to the database");   //insert
        System.out.println("2. Edit a movie from the database");    //update
        System.out.println("3. Delete a movie record from the database");  //delete
        System.out.println("4. All movies in descending order of runtime");
        System.out.println("5. All the Movie records of the selected genre sorting in title");
        System.out.println("6. The nummber of Movie is there in each prod_country");
        System.out.println("7. Exit");
        System.out.println("Enter your choice... ");

    }
    public static String get_menu() {
        String input = sc.nextLine();
        if(! input.matches("[1-8]"))
        {
            System.out.println("Please enter Number between 1 and 7");
            input = get_menu();
        }
        return input;
    }

    public static void menu()
    {
        display();
        switch(get_menu())
        {
            case "1":
            {
                namelist = new LinkedList<>();
                Movie_main main = new Movie_main();
                namelist = main.dataRead("Data/movies.csv");
                System.out.println(namelist.size());
                Add_Movies addMovies = new Add_Movies(namelist);
                addMovies.Add_Movies();
                break;
            }
            case "2":{
                namelist = new LinkedList<>();
                Movie_main main = new Movie_main();
                namelist = main.dataRead("Data/movies.csv");
                System.out.println(namelist.size());
                Edit_MovieName editMovieName = new Edit_MovieName(namelist);
                editMovieName.edit();
                break;
            }
            case "3":{
                namelist = new LinkedList<>();
                Movie_main main = new Movie_main();
                namelist = main.dataRead("Data/movies.csv");
                System.out.println(namelist.size());
                Delete_MovieID deleteMovieID = new Delete_MovieID(namelist);
                deleteMovieID.delete();
                break;
            }
            case "4":{}
            case "5":{}
            case "6":{}
            case "7":{}
        }
    }
    public static void main(String[] args) {
        System.out.println("Please Wait a moment...");
        Movie_main main = new Movie_main();
        namelist = main.dataRead("Data/movies.csv");
        System.out.println(namelist.size());
        menu();
    }
}
