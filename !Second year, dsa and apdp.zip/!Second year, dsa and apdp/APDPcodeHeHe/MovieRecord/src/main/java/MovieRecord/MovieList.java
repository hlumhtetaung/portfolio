package MovieRecord;

public class MovieList {
    private int movie_id;
    private String release_date;
    private int revenue;
    private int runtime;
    private String title;
    private String voteAverage;
    private String company;
    private String genre;
    private String prodCountry;

    public MovieList(int movie_id, String release_date, int revenue, int runtime, String title, String voteAverage, String company, String genre, String prodCountry) {
        this.movie_id = movie_id;
        this.release_date = release_date;
        this.revenue = revenue;
        this.runtime = runtime;
        this.title = title;
        this.voteAverage = voteAverage;
        this.company = company;
        this.genre = genre;
        this.prodCountry = prodCountry;

    }

    public int getMovie_id() {
        return movie_id;}

    public String getRelease_date() {
        return release_date;}

    public int getRevenue() {
        return revenue;}

    public int getRuntime() {
        return runtime;}

    public String getTitle() {
        return title;}

    public String getVoteAverage() {
        return voteAverage;}

    public String getCompany() {
        return company;}

    public String getGenre() {
        return genre;}

    public String getProdCountry() {
        return prodCountry;}


}
