package MovieRecord;

import java.util.LinkedList;

public class Add_Movies {
    UserInput uin = new UserInput();
    Search_Movie search = new Search_Movie();
    LinkedList<MovieList> namelist = new LinkedList<>();

    public Add_Movies(LinkedList<MovieList> namelist) {
        this.namelist = namelist;
    }
    public void Add_Movies()
    {
        String id = uin.get_ID();
        String releasedate = uin.get_release_date();
        String revenue = uin.get_revenue();
        String runtime = uin.get_runtime();
        String title = uin.get_title();
        String voteAverage = uin.get_voteAverage();
        String companie = uin.get_companie();
        String genre = uin.get_genre();
        String prodCountry = uin.get_prodCountry();

        while (search.searchMovie(namelist, id, releasedate, revenue, runtime, title,
                voteAverage, companie, genre, prodCountry) >=0 )
        {
            System.out.println("Movie name is already existed");
            id = uin.get_ID();
            releasedate = uin.get_release_date();
            revenue = uin.get_revenue();
            runtime = uin.get_runtime();
            title = uin.get_title();
            voteAverage = uin.get_voteAverage();
            companie = uin.get_companie();
            genre = uin.get_genre();
            prodCountry = uin.get_prodCountry();
        }
        namelist.add(new MovieList(Integer.parseInt(id),releasedate,Integer.parseInt(revenue),
                Integer.parseInt(runtime),title,voteAverage,companie,genre,prodCountry));
        search.write_to_Database("Data/movies.csv", namelist);
        System.out.println("Movie added successfully");
    }

    public void add_movie(MovieList movieList)
    {
        namelist.add(movieList);
        search.write_to_Database("Data/movies.csv", namelist);
        System.out.println("Movie added successfully");
    }

}
