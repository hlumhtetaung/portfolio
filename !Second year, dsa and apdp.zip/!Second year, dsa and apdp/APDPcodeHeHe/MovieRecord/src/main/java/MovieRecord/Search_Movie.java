package MovieRecord;

import com.opencsv.CSVWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;

public class Search_Movie {
    public int searchMovie(LinkedList<MovieList> namelist, String movie_id, String release_date,
                           String revenue, String runtime, String title, String voteAverage, String company,
                           String genre, String prodCountry) {
        int index = 0;
        for(MovieList bn : namelist) {
            if (bn.getMovie_id() == Integer.parseInt(movie_id)
                    && bn.getRelease_date().equals(release_date)
                    && bn.getRevenue() == Integer.parseInt(revenue)
                    && bn.getRuntime() == Integer.parseInt(runtime)
                    && bn.getTitle().equals(title)
                    && bn.getVoteAverage().equals(voteAverage)
                    && bn.getCompany().equals(company)
                    && bn.getGenre().equals(genre)
                    && bn.getProdCountry().equals(prodCountry))
            {
                return index;
            }
            index++;
        }
        return -1;
    }

    public void write_to_Database(String filename,  LinkedList<MovieList> namelist) {
        FileWriter fw = null;
        try {
            fw = new FileWriter(filename, false);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        CSVWriter writer = new CSVWriter(fw);
        for (MovieList bn : namelist) {
            String[] str = {String.valueOf(bn.getMovie_id()),
                    bn.getRelease_date(),
            String.valueOf(bn.getRevenue()),
                    String.valueOf(bn.getRuntime()),
            bn.getTitle(),
            bn.getVoteAverage(),
            bn.getCompany(),
            bn.getGenre(),
            bn.getProdCountry()
            };
            writer.writeNext(str);
        }
        try {
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            fw.close();
        }catch (IOException e){
            throw new RuntimeException(e);
        }
    }
}
