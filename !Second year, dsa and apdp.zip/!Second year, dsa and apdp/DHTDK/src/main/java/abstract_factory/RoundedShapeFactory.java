package abstract_factory;

public class RoundedShapeFactory extends AbstractFactory {
    @Override
    public Shape getType(String shapeType) {
        if (shapeType.equalsIgnoreCase("rectangle")) {
            return new roundedRectangle();
        }
        else if (shapeType.equalsIgnoreCase("square")) {
            return new roundedSquare();
        }

        return null;
    }
}
