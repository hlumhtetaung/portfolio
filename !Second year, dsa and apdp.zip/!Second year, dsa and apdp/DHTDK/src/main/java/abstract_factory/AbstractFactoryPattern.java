package abstract_factory;

public class AbstractFactoryPattern {
    public static void main(String[] args) {
        AbstractFactory factory = FactoryProducer.getFactory(true);
        Shape shape1 = factory.getType("square");
        shape1.draw();

        AbstractFactory factory_simple = FactoryProducer.getFactory(false);
        Shape shape2 = factory_simple.getType("square");
        shape2.draw();
    }
}
