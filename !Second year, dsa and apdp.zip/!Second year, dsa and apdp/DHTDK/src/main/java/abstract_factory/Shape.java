package abstract_factory;

public interface Shape {
    void draw();
}
