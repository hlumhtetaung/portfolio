package abstract_factory;

public class Rectangle implements Shape{

    @Override
    public void draw() {
        System.out.println("Rectangle draw 🔵");
    }
}

class Square implements Shape {

    @Override
    public void draw() {
        System.out.println("Square draw 🟦");
    }
}

class roundedRectangle implements Shape {

    @Override
    public void draw() {
        System.out.println("Rounded rectangle draw 🟦");
    }
}

class roundedSquare implements Shape {

    @Override
    public void draw() {
        System.out.println("Rounded square draw 🟦");
    }
}