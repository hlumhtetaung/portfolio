package abstract_factory;

public abstract class AbstractFactory {
    public abstract Shape getType(String shapeType);

}
