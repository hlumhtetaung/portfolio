package abstract_factory;

public class ShapeFactory extends AbstractFactory {

    @Override
    public Shape getType(String shapeType) {
        if (shapeType.equalsIgnoreCase("square")) {
            return new Square();
        }
        else if (shapeType.equalsIgnoreCase("rectangle")) {
            return new Rectangle();
        }

        return null;
    }
}
