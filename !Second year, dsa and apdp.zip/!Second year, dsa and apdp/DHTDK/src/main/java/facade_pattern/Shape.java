package facade_pattern;

public interface Shape {
    void draw();
}
