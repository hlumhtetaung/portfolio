package template;

public class TemplateDemo {
    public static void main(String[] args) {
        BeverageMaker tea = new TeaMaker();
        System.out.println("Tea maker");
        tea.beverageMaker();

        System.out.println();

        BeverageMaker coffee = new CoffeeMaker();
        System.out.println("Coffee maker");
        coffee.beverageMaker();
    }
}
