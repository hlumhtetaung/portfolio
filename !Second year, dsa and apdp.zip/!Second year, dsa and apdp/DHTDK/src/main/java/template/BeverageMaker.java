package template;

public abstract class BeverageMaker {
    // Define template method, final method
    public final void beverageMaker() {
        boilWater();
        brew();
        pourInCup();
        addCondiments();
    }

    // abstract methods to be implemented by subclasses
    abstract void brew();
    abstract void addCondiments();

    // common methods
    void boilWater() {
        System.out.println("Boiling water");
    }

    void pourInCup() {
        System.out.println("Pouring into cup");
    }
}
