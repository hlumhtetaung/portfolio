package creational_design_pattern_factory;

public class Square implements Shape{
    @Override
    public void draw() {
        System.out.println("Draw square 🟦");
    }
}
