package creational_design_pattern_factory;

public interface Shape {
    void draw();
}
