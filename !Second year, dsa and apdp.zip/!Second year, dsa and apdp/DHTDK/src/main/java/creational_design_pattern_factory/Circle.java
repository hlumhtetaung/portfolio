package creational_design_pattern_factory;

public class Circle implements Shape {

    @Override
    public void draw() {
        System.out.println("Draw Circle 🔵");
    }
}
