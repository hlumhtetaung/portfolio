package private_class_data_pattern;

public class Circle {
    private CircleData circleData;

    public Circle(double radius) {
        this.circleData = new CircleData(radius);
    }

    public double calculateArea() {
        return Math.PI * Math.pow(this.circleData.getRadius(), 2);
    }
}
