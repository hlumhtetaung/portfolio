package private_class_data_pattern;

public class PrivatePatternDemo {
    public static void main(String[] args) {
        Circle circle = new Circle(20);
        System.out.println("Circle Area: " + circle.calculateArea());
    }
}
