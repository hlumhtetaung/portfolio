package private_class_data_pattern;

public class CircleData {
    private double radius;

    public CircleData(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }
}
