package b;
import a.A;
// inheritance, extends A
public class C extends A {
    public static void main(String[] args) {
        C obj = new C();
        System.out.println(obj.var);
        obj.display();
    }
}
