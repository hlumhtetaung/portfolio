package b;
import a.Person;
public class Painter extends Person{
    public void work(){
        System.out.println("Painter work!");
    }
}
