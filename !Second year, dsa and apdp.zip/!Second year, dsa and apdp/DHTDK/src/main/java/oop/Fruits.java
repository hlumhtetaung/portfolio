package oop;

public class Fruits {
    //define fields
    String FruitName;
    int price;

    //create constructor

    //no parameter constructor
    public Fruits(){
        System.out.println("This is fruits constructor.");
    }
    //one parameter constructor
    public Fruits(String FruitName){
        System.out.println("Fruit Name: "+FruitName);
    }

    //two parameter constructor
    public Fruits(String FruitName, int price){
        System.out.println(FruitName+" costs "+ price);
    }
}
