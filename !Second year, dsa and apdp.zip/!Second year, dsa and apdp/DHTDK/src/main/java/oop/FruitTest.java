package oop;

public class FruitTest {
    public static void main(String[] args) {
        Fruits f1 = new Fruits();
        Fruits f2 = new Fruits("Pineapple");
        Fruits f3 = new Fruits("Pineapple", 5);
    }
}
