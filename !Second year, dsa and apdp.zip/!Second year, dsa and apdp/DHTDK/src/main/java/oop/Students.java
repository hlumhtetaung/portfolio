package oop;

public class Students {
    //define fields
    String name;
    int age;
    String gender;
    String email;

    //method
    public void doHomework(){
        System.out.println("Do Homework!");
    }

    public void sentEmail(){
        System.out.println("Send Email!");
    }
}
