package oop;

public class StudentTest {
    public static void main(String[] args) {
        //object creation
        Students s1 = new Students();
        s1.name = "Hein Htoo Naing";
        s1.age = 20;
        s1.gender = "Female";
        s1.email = "heinhtoonaing@imu.edu.mm";

        System.out.println("Name: "+s1.name+"\n"+"Age: "+s1.age+"\n"
                +"Gender: "+s1.gender+"\n"+"Email: "+s1.email);

        System.out.println();

        Students s2 = new Students();
        s2.name = "Kaung Myat Lwin";
        s2.age = 21;
        s2.gender = "Female";
        s2.email = "kaungmyatlwin@imu.edu.mm";

        System.out.println("Name: "+s2.name+"\n"+"Age: "+s2.age+"\n"
                +"Gender: "+s2.gender+"\n"+"Email: "+s2.email);
    }
}
