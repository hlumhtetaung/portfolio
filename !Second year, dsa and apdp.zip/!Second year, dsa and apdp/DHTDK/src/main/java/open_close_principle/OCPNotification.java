package open_close_principle;


public interface OCPNotification {
    public void sendOTP(String medium);
}

class EmailNotification implements OCPNotification {
    @Override
    public void sendOTP(String medium)
    {
        // do something
    }
}

class PhoneNotification implements OCPNotification {
    @Override
    public void sendOTP(String medium){
        // do something
    }
}