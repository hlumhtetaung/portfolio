package a;

public class Teacher extends Person{
    public void work(){
        System.out.println("Teacher work!");
    }
}
