package a;

public class B {

    public static void main(String[] args) {
        A obj = new A();
        System.out.println(obj.var);
        obj.display();
    }
}
