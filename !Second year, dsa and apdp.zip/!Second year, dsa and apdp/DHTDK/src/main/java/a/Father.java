package a;

public class Father {

    public void work(){
        System.out.println("Father work!");
    }
}

class Son extends Father{
    public void play(){
        System.out.println("Son play!");
    }
}

