package a;

public class A {
    //Access modifier private, default, protected, public
    //private within the class
    //default, within the package
    //public, anywhere
    //protected, within the package, can use another package (inheritance)

    //instance var
      protected int var = 10;

    //instance method
      protected void display(){
        System.out.println("Var value: " + var);
    }

    public static void main(String[] args) {
        //object creation
        A obj = new A();
        System.out.println(obj.var);
        obj.display();
    }
}
