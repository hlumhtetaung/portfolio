package a;

public class MethodOverloadTest {
    public static void main(String[] args) {
        System.out.println(multiplyMethod.multiply(3, 5));
        System.out.println(multiplyMethod.multiply(3.5, 5.5));
        System.out.println(multiplyMethod.multiply(3, 5));
    }
}
