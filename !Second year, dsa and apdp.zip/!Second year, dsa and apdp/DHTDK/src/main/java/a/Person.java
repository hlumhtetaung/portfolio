package a;

public class Person {
    // overridden method
    public void work(){
        System.out.println("Person work!");
    }
}

class Doctor extends Person{
    // Specific implementation
    // overriding method
    public void work(){
        System.out.println("Doctor work!");
    }
}
