package a;

public class GeneralTest {
    public static void main(String[] args) {
        Father f;
        //convert subclass to superclass, more general (widen), can access super class method
        //type casting
        f = (Father) new Son(); // new operator return subclass object
        f.work();
    }
}
