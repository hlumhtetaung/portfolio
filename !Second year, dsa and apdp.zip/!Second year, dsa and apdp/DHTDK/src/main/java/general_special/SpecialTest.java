package general_special;

public class SpecialTest {
    public static void main(String[] args) {
        // convert super class into subclass
        // narrow, down casting, more specific
//        SoftwareEngineering soft;
//        soft = (SoftwareEngineering) new Employee();
//        soft.develop();
//        soft.work();

        Employee emp;
        emp = new SoftwareEngineering();

        SoftwareEngineering soft= (SoftwareEngineering) emp;

        soft.work();
        soft.develop();

    }
}
