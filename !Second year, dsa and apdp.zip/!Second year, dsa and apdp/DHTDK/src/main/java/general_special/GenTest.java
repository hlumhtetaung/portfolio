package general_special;

public class GenTest {
    public static void main(String[] args) {
        // convert subclass into super class

        Employee emp; // emp is super class reference
        emp = (Employee) new SoftwareEngineering(); // new operator return subclass reference
        emp.work();
        // can access super class method, not subclass method

    }
}
