package general_special;

public class Employee {
    public void work(){
        System.out.println("Employee work!👷👷👷");
    }
}

class SoftwareEngineering extends Employee{
    public void develop(){
        System.out.println("Software Engineering develop code!!");
    }

    public void work(){
        System.out.println("Software Engineering work!👷👷👷");
    }
}
