package single_ton;

public class SingleTon {
    public static void main(String[] args) {
        // SingleObject obj = new SingleObject();

        SingleObject obj = SingleObject.getInstance();
        obj.showMessage();
    }
}
