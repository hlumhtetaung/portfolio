package single_ton;

public class SingleObject {
    // object creation
    private static SingleObject instance = new SingleObject();

    // private constructor
    private SingleObject() {

    }

    // object, return method
    public static SingleObject getInstance() {
        return instance;
    }

    public void showMessage() {
        System.out.println("Hello, Welcome to singleton pattern!");
    }
}
