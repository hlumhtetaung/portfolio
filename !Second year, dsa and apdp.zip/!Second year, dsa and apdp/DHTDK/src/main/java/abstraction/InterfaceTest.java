package abstraction;

public class InterfaceTest implements InterfaceEx{
    @Override
    public void method1()
    {
        System.out.println("This is abstract method!!");
    }
}
