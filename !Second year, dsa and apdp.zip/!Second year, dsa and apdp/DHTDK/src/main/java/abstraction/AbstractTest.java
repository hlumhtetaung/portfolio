package abstraction;

public class AbstractTest {

    public static void main(String[] args) {
        Circle c = new Circle("white", 2.5);
        // c.toString()
        System.out.println(c.toString());

        Rectangle r = new Rectangle("blue", 2, 4);
        // r.toString()
        System.out.println(r.toString());
    }
}
