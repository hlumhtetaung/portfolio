package abstraction;

import java.io.FileNotFoundException;
import java.io.IOException;

public class InterfaceOverridingTest implements InterfaceOverriding{
//    @Override
//    public void method1() throws IOException
//    {
//        // can't declare checked exceptions in implement method
//    }

//    @Override
//    public void method1() throws FileNotFoundException
//    {
//        // can't declare checked exceptions in implement method
//    }

    @Override
    public void method1() throws ArithmeticException
    {
        // This is on check exception
    }
}
