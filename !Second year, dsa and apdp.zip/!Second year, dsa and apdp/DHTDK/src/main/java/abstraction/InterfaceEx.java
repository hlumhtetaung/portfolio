package abstraction;

public interface InterfaceEx {
    // abstract method
    public abstract void method1();

    // no constructor

    // static method
    public static void method2()
    {
        System.out.println("This is static method!");
        method6(); // can call private method 6 because its static method
        // static can only call static methods
    }

    // default method
    public default void method3()
    {
        System.out.println("This is default method!");
        method5();
        method6();
        // default method can call both private (static and non-static)
    }

    // no instance method
//    public void method4()
//    {
//        // implementation
//    }

    // non-static private method
    private void method5()
    {
        System.out.println("This is private method! A non static one!");
    }

    //static private method
    private static void method6()
    {
        System.out.println("This is static private method!");
    }
}
