package abstraction;

public interface InterfaceOverriding {
    public default void method1()
    {
        System.out.println("This is method1!");
    }
}
