package abstraction;

abstract class InterfaceOverridingTask2 implements InterfaceOverriding {
    // abstract class don't need implementation and overriding method
}
