package abstraction;

public abstract class Shape {

    String color;
    // constructor

    public Shape(String color){
        System.out.println("This is a shape constructor!");
        this.color = color;
    }
    // abstract method

    public abstract double area();

    public abstract String toString();

    public String getColor(){
        return this.color;
    }

}
