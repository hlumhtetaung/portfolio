package abstraction;

public class Rectangle extends Shape{

    double width;
    double height;

    public Rectangle(String color, double width, double height) {
        super(color);
        this.width = width;
        this.height = height;
    }

    @Override
    public double area() {
        return width * height;
    }

    @Override
    public String toString() {
        return "Rectangle Area: " + area() + "\nRectangle color: " + getColor();
    }
}
