package abstraction;

public abstract class AbstractEx {
    // abstract method
    // In abstract class, abstract method may or may not exist
    int num = 10;
    public abstract void abstractMethod(); // abstract method, no-body (without implementation)
    public AbstractEx(){
        System.out.println("This is abstract class constructor!");
    }
    public void show(){
        System.out.println("This is abstract exercise.");
    }
}

class Ex extends AbstractEx{

    @Override
    public void abstractMethod() {
        System.out.println("This is abstract method demo!");
    }
}
