package abstraction;

public class InterfaceTest1 {
    public static void main(String[] args) {
        InterfaceTest it = new InterfaceTest();
        it.method1();
        it.method3();

        InterfaceEx.method2(); // call static method
    }
}
