package composition;

public class Composition {
    public static void main(String[] args) {
        Car car1 = new Car("BMW", new Engine("Diesel"));
        car1.show();
    }
}
