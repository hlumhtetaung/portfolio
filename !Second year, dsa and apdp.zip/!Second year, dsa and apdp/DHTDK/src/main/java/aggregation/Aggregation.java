package aggregation;

public class Aggregation {
    public static void main(String[] args) {
        Address add1 = new Address("City 1", "State 1", "Country 1");
        Address add2 = new Address("City 2", "State 2", "Country 2");

        Employee emp1 = new Employee(1, "John", add1);
        Employee emp2 = new Employee(2, "Mavis", add2);

        emp1.display();
        emp2.display();
    }
}
