package encapsulation;

public class Bank {
    private String accountType;
    private int balance;

    public Bank(int balance)
    {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public int getBalance() {
        return balance;
    }

    // deposit
    public void deposit(int amount)
    {
        if(amount > 0)
        {
            balance += amount;
        }
        else
        {
            System.out.println("Deposit amount should be positive!");
        }
    }

    public void withdraw(int amount)
    {
        if(amount > 0 && amount < balance)
        {
            balance -= amount;
        }
        else
        {
            System.out.println("Error withdrawing!");
        }
    }
}
