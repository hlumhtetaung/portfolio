package encapsulation;

public class Student {
    private String name;
    private String batchNo;
    private int age;

    public Student()
    {
        this.name = "";
        this.batchNo = "";
        this.age = 0;
    }

    public Student(String name, String batchNo, int age)
    {
        this.name = name;
        this.batchNo = batchNo;
        this.age = age;
    }

    // getter method, setter method


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
