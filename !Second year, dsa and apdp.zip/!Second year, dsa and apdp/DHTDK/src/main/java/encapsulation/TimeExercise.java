package encapsulation;

public class TimeExercise {
    private int hr;
    private int min;
    private int sec;

    public TimeExercise(){
        this.hr = 0;
        this.min = 0;
        this.sec = 0;
    }

    public TimeExercise(int hr, int min, int sec){
        this.hr = hr;
        this.min = min;
        this.sec = sec;
    }

    public int getHr() {
        return hr;
    }

    public void setHr(int hr) {
        this.hr = hr;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getSec() {
        return sec;
    }

    public void setSec(int sec) {
        this.sec = sec;
    }
}
