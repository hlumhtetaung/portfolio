package encapsulation;

import java.util.Scanner;

public class RectangleTest {
    public static void main(String[] args) {
        // object array
        Rectangle[] rec = new Rectangle[3];

        for(int i = 0; i < rec.length; i++)
        {
            rec[i] = input();
        }

        for(int j = 0; j < rec.length; j++)
        {
            System.out.println("Rectangle " + (j + 1) + " area: " + area(rec[j]));
        }
    }

    private static Rectangle input()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter width: ");
        int length = sc.nextInt();
        System.out.println("Enter length: ");
        int width = sc.nextInt();
        Rectangle rec = new Rectangle(length, width);

        return rec;
    }

    private static int area(Rectangle rec)
    {
        return rec.getLength() * rec.getWidth();
    }

}
