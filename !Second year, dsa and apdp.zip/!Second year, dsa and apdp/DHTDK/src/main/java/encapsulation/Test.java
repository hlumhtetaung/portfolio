package encapsulation;

public class Test {
    public static void main(String[] args) {
        Student s1 = new Student("Kaung Myat Soe", "B-109", 18);
        System.out.println(s1.getName() + " " + s1.getBatchNo() + " " + s1.getAge());
        Student s2 = new Student();
        s2.setName("Gay Hein Htoo Naing");
        s2.setBatchNo("B-109");
        s2.setAge(20);
        System.out.println(s2.getName() + " " + s2.getBatchNo() + " " + s2.getAge());
    }
}
