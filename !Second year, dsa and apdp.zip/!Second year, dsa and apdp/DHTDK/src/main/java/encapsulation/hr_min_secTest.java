package encapsulation;

import java.sql.Time;
import java.util.Scanner;

public class hr_min_secTest {
    public static void main(String[] args) {
        TimeExercise t1 = input();
        TimeExercise t2 = input();

        int sec1 = totalSecs(t1);
        int sec2 = totalSecs(t2);
        int sec3 = sec1 + sec2;
        System.out.println("Total seconds: " + sec3);

        // change sec3 to hour:min:sec
        TimeExercise t3 = secToHr(sec3);
        System.out.println("Time 2: " + t3.getHr() + ":" + t3.getMin() + ":" + t3.getSec());
    }

    public static TimeExercise secToHr(int sec3)
    {
        TimeExercise t = new TimeExercise();
        t.setHr(sec3 / 3600);
        t.setMin((sec3 % 3600) / 60);
        t.setSec((sec3 % 3600) % 60);

        return t;
    }

    public static TimeExercise input()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter hour: ");
        int hr = sc.nextInt();
        System.out.println("Enter minute: ");
        int min = sc.nextInt();
        System.out.println("Enter second: ");
        int sec = sc.nextInt();

        TimeExercise t = new TimeExercise(hr, min, sec);

        return t;
    }

    public static int totalSecs(TimeExercise t)
    {
        return (t.getHr() * 3600 + t.getMin() * 60 + t.getSec());
    }
}
