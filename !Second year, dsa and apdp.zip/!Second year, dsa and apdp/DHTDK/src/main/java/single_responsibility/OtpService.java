package single_responsibility;

public class OtpService {
    public void sendOTP(String medium)
    {
        if(medium.equalsIgnoreCase("Email"))
        {
            // do something
        }
    }
}
