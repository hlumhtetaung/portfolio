package single_responsibility;

public class PrinterService {
    public void passBook()
    {
        // do something
    }
}
