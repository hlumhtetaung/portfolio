package single_responsibility;

public class LoanService {
    public void getLoanInterest(String loanType)
    {
        if(loanType.equalsIgnoreCase("Personal Loan"))
        {
            // do something
        }
        else if (loanType.equalsIgnoreCase("Car Loan"))
        {
            // do something
        }
    }
}
