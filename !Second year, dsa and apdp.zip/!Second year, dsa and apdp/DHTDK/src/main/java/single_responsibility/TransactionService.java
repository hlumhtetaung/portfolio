package single_responsibility;

public class TransactionService {
    double balance;
    String account;

    public void withdraw(String AccountType, double balance)
    {
        // do something
    }

    public void deposit(String AccountType, double balance)
    {
        // do something
    }
}
