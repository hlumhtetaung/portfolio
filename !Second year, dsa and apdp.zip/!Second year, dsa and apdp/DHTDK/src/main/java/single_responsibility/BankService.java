package single_responsibility;

public class BankService {
    // transaction service
    // printer service
    // loan service
    // OTP service

    double balance;
    String account;

    public void withdraw(String AccountType, double balance)
    {
        // do something
    }

    public void deposit(String AccountType, double balance)
    {
        // do something
    }

    public void passBook()
    {
        // do something
    }

    public void getLoanInterest(String loanType)
    {
        if(loanType.equalsIgnoreCase("Personal Loan"))
        {
            // do something
        }
        else if (loanType.equalsIgnoreCase("Car Loan"))
        {
            // do something
        }
    }

    public void sendOTP(String medium)
    {
        if(medium.equalsIgnoreCase("Email"))
        {
            // do something
        }
    }

}
