package searching;

import java.util.Arrays;

public class BinarySearchMethod {
    public static void main(String[] args) {
        String[] array = {"a", "b", "D", "E", "C", "Z", "Y"};
        Arrays.sort(array);
        String search = "H";

        binary(array, search);
    }

    public static void binary(String[] array, String search){
        int low = 0;
        int high = array.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;

            if (search.equals(array[mid])) {
                System.out.println("Search found at " + mid);
                break;
            } else if (search.compareTo(array[mid]) < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        if (low > high){
            System.out.println("Search data not found.");
        }
    }
}
