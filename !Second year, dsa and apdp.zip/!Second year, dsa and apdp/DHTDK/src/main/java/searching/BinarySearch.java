package searching;

import java.util.Arrays;

public class BinarySearch {
    public static void main(String[] args) {
        //making array
        String[] array = {"a", "b", "D", "E", "C", "Z", "Y"};
        Arrays.sort(array);
        System.out.println(Arrays.toString(array));
        String search = "H";

        //finding midpoint
        int low = 0;
        int high = array.length - 1;

        //finding number in array
        while (low <= high) {
            int mid = (low + high) / 2;

            if (search.equals(array[mid])) {
                System.out.println("Search found at " + mid);
                break;
            } else if (search.compareTo(array[mid]) < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        if (low > high){
            System.out.println("Search data not found.");
        }
    }
}
