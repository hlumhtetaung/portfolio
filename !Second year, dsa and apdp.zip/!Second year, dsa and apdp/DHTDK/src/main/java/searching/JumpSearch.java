package searching;

public class JumpSearch {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50};
        int search = 30;
        int previous = 0;
        // Jump steps
        int step = (int) Math.sqrt(array.length);

        for(int i = 0; i < array.length; i += step){
            if(array[i] > search){
                break;
            }
            previous = i;
        }

        int i = previous;

        // linear search
        // for loop linear search
//        int j;
//
//        for(j = i; j < array.length; j++){
//            if(array[j] == search){
//                System.out.println("Search found at index: " + j);
//                break;
//            }
//        }
//        if(j == array.length){
//            System.out.println("Search not found.");
//        }


        int found_index = -1;
        while ( i < array.length && i < previous + step) {
            if ( array[i] == search ) {
                found_index = i;
                break;
            }
            i ++;
        }

        if ( found_index == -1 ){
            System.out.println("Not Found!");
        }
        else {
            System.out.println("Search Dat is found at index : " + found_index);
        }
    }
}