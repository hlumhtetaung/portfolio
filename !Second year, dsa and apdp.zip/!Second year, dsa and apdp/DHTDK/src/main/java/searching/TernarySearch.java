package searching;

import java.util.Arrays;

public class TernarySearch {
    public static void main(String[] args) {
        String[] array = {"a", "b", "D", "E", "C", "Z", "Y"};
        Arrays.sort(array);
        String search = "E";
        int low = 0;
        int high = array.length - 1;
        int found_index = -1;
        while (low <= high){
            int mid1 = low + ((high - low)/3);
            int mid2 = high - ((high - low)/3);
            if(array[mid1].equals(search)){
                found_index = mid1;
            }
            if(array[mid2].equals(search)){
                found_index = mid2;
            }
            if(search.compareTo(array[mid1]) < 0){
                high = mid1 - 1;
            }
            else if(search.compareTo(array[mid2]) > 0){
                high = mid2 + 1;
            }
            else{
                low = mid1 + 1;
                high = mid2 - 1;
            }

        }
        if(found_index >= 0){
            System.out.println("Search data found at "+found_index);
        }
        else{
            System.out.println("Search not found.");
        }
    }


}
