package searching;

import java.util.Arrays;
import java.util.Scanner;

public class LinearSearch {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = new int[5];

        //Adding elements to array
        for (int i=0; i<array.length; i++) {
            System.out.print("Enter the elements for array: ");
            array[i] = sc.nextInt();
        }

        //printing array
        for (int j=0; j<array.length; j++){
            System.out.print(array[j]+" ");
        }
        System.out.println();
        System.out.println(Arrays.toString(array));

        //finding number
        int search;
        System.out.print("Enter the number to search: ");
        search = sc.nextInt();
        int k;
        for (k=0; k<array.length; k++){
            if (search == array[k]){
                System.out.println("The number is in the array.");
                break;
            }
        }
        if(k == array.length){
            System.out.println("The number is not in the array.");
        }
    }
}
