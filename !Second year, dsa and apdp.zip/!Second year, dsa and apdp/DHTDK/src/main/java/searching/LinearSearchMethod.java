package searching;

import java.util.Scanner;

public class LinearSearchMethod {
    static Scanner sc = new Scanner(System.in);

    //input method
    public static void input(int[] array){
        for (int i=0; i<array.length; i++) {
            System.out.print("Enter the elements for array: ");
            array[i] = sc.nextInt();
        }
    }
    //linear search method
    public static void linearsearch(int[] array, int key){
        int k;
        for (k=0; k<array.length; k++){
            if (key == array[k]){
                System.out.println("The number is in the array. Found at index "+k);
                break;
            }
        }
        if(k == array.length){
            System.out.println("The number is not in the array.");
        }
    }

    public static void main(String[] args) {
        System.out.print("Enter array size: ");
        int size = sc.nextInt();

        int[] array = new int[size];

        input(array);

        System.out.print("Enter search data: ");
        int key = sc.nextInt();
        linearsearch(array, key);
    }
}
