package searching;

import java.util.Arrays;

public class BinarySearchReturnMethodIncorrect {
    public static void main(String[] args) {
        String[] array = {"a", "b", "D", "E", "C", "Z", "Y"};
        Arrays.sort(array);
        String search = "E";

        binary(array, search);
    }

    public static int binary(String[] array, String search) {
        int low = 0;
        int high = array.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;

            if (search.equals(array[mid])) {
                return mid;
            } else if (search.compareTo(array[mid]) < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        if (low > high) {
            return 0;
        }
        return low;
    }
}
