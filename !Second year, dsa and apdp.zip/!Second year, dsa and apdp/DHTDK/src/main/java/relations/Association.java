package relations;

public class Association {
    public static void main(String[] args) {
        Bank bank = new Bank("KBZ");

        Employee emp1 = new Employee("John");
        Employee emp2 = new Employee("Mavis");

        System.out.println(emp1.getName() + " is employee of " + bank.getBankName());
        System.out.println(emp2.getName() + " is employee of " + bank.getBankName());
    }
}
