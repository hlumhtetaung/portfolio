package apdp_dhtdk;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileEx {
    public static void main(String[] args) throws FileNotFoundException {
        // check exception
        FileReader f = new FileReader("");
    }
}
