package apdp_dhtdk;

public class MethodEx2 {
    int instavar = 10;

    static int staticvar = 15;

    public static void main(String[] args) {
        MethodEx2 obj = new MethodEx2();
        System.out.println("The instance variable: "+obj.instavar);
        System.out.println("The static variable: "+staticvar);
    }

}
