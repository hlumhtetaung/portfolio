package apdp_dhtdk;

public class Exception {
    public static void main(String[] args) {
        int num = 32;
        int result;
        try{
            result = num / 0;

        }
        catch(ArithmeticException e){
            System.out.println(e);
        }
    }

}
