package apdp_dhtdk;

public class MethodEx {
    //no return type, no parameter
    public static void display(){
        System.out.println("This is method.");
    }

    //no return type with parameter
    public static void sum(int a, int b){
        int sum = a + b;
        System.out.println(sum);
    }

    //return int, with parameter
    public static int add(int a, int b){
        return a + b;
    }

    public static void main(String[] args) {
        display();
        sum(2,4);
        int result = add(10, 23);
        System.out.println(result);
    }
}
