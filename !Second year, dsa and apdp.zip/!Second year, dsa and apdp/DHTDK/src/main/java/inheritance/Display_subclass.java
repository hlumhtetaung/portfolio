package inheritance;

public class Display_subclass extends Display {
    int sum = x + x;
    public void display(){
        System.out.println("This is subclass " + sum);
    }

    public void myMethod() {
        Display_subclass sub = new Display_subclass();
        sub.display();
        super.display(); //invoke super class

        System.out.println("Value of super class: "+super.x); //invoke super class
        System.out.println("Value of sub class: "+sub.sum);
    }

    public static void main(String[] args) {
        Display_subclass obj = new Display_subclass();
        obj.myMethod();
    }
}
