package inheritance;

public class Calculation_subclass extends Calculation {
    public void mul(int a, int b){
        z = a * b;
        System.out.println("The multiplication of a and b is "+z);
    }

    public static void main(String[] args) {
        Calculation_subclass cal = new Calculation_subclass();

        cal.add(5, 10);
        cal.sub(5,10);
        cal.mul(5, 10);

    }
}
