package inheritance;

public class ThisKeyword {
    int x;

    public ThisKeyword(){
        this.x = 0;
    }

    public ThisKeyword(int x){
        this.x = x;
    }
}
