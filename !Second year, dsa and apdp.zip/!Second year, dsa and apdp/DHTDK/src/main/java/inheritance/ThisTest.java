package inheritance;

public class ThisTest extends ThisKeyword{
    public static void main(String[] args) {
        ThisKeyword key1 = new ThisKeyword();
        ThisKeyword key2 = new ThisKeyword(2);

        System.out.println("The first key is " + key1.x);
        System.out.println("The second key is " + key2.x);
    }
}
