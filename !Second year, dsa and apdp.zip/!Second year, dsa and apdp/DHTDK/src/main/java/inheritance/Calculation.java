package inheritance;

public class Calculation {
    int z;
    public void add(int a, int b) {
        z = a + b;
        System.out.println("The addition of a and b is "+z);
    }

    public void sub(int a, int b){
        z = a - b;
        System.out.println("The subtraction of a and b is "+z);
    }

}
