package inheritance;

public class StudentSuperConstructor {
    public static void main(String[] args) {
        MyStu stu = new MyStu("John", 24);
        stu.getInfo();
    }
}
