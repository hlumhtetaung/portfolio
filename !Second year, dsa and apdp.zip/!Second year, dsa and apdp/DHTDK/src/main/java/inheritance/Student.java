package inheritance;

public class Student {
    String name;
    int age;

    Student(String name, int age){
        this.name = name;
        this.age = age;
    }

    public void getInfo(){
        System.out.println("Student Information: " + this.name + " " + this.age);
    }
}
class MyStu extends Student{

    MyStu(String name, int age) {
        super(name, age); // invoke student class constructor
    }
}
