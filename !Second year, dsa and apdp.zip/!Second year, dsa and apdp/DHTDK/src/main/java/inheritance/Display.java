package inheritance;

public class Display {
    //class member
    int x = 10;
    public void display(){
        System.out.println("This is super class "+ x);
    }

}
