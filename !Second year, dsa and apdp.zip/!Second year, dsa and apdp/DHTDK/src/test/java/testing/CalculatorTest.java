package testing;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    Calculator cal;

    @BeforeEach
    void setUp() {
        cal = new Calculator();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    @DisplayName("Add the two numbers testing")
    void add() {
        int add = cal.add(2, 4);
        assertEquals(6, add);
        System.out.println("Adding testing successful");
    }

    @Test
    @DisplayName("Subtract the two numbers testing")
    void sub() {
        int sub = cal.sub(4, 2);
        assertEquals(2, sub);
        System.out.println("Subtraction testing successful");
    }

    @Test
    @DisplayName("Multiply the two numbers testing")
    void multi() {
        int multi = cal.multi(2, 2);
        assertEquals(4, multi);
        System.out.println("Multiplication testing successful");
    }

    @Test
    @DisplayName("Divide the two numbers testing")
    void div() {
        int div = cal.div(4, 2);
        assertEquals(2, div);
        System.out.println("Division testing successful");
    }
}