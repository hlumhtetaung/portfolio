package sorting;

public class HeapSort {
    public static void main(String[] args) {
        int[] array = {4, 2, 3, 1, 6, 5, 9, 8, 7};
        System.out.println("Before sorting: ");
        print(array);

        heapSort(array);

        System.out.println("\nAfter sorting: ");
        print(array);
    }

    public static void print(int[] array){
        for(int a : array)
        {
            System.out.print(a + " ");
        }
        System.out.println();
    }

    public static void heapSort(int[] array)
    {
        int n = array.length;
        for(int i = n / 2; i >= 0; i--)
        {
            heapSortIF(array, n, i);
        }

        for(int i = n - 1; i >= 0; i--) // swap root node and last node
        {
            int temp = array[0];
            array[0] = array[i];
            array[i] = temp;

            heapSortIF(array, i, 0);
        }
    }

    public static void heapSortIF(int[] array, int size, int i)
    {
        int max = i;
        int L = 2 * i + 1;
        int R = 2 * i + 2;

        if(L < size && array[L] > array[max])
        {
            max = L;
        }
        if (R < size && array[R] > array[max])
        {
            max = R;
        }

        if(max != i) // max is not equal parent node, swap max and parent node
        {
            int temp = array[max];
            array[max] = array[i];
            array[i] = temp;
            heapSortIF(array, size, max);
        }
    }

}
