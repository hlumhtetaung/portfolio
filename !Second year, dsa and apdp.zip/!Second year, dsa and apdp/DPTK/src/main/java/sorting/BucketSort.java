package sorting;

public class BucketSort {
    public static void main(String[] args) {
        int[] A = {29, 25, 3, 49, 9, 37, 21, 43};
        System.out.println("Before sorting: ");
        print(A);

        int max = maxValue(A);
        int[] sorted = bucketSort(A, max);
        System.out.println("\nAfter sorting: ");
        print(sorted);
    }

    public static void print(int[] A){
        for(int a : A)
        {
            System.out.print(a + " ");
        }
    }

    public static int maxValue(int[] A){
        int max = A[0];
        for(int i = 1; i < A.length; i++)
        {
            if(A[i] > max)
            {
                max = A[i];
            }
        }
        return max;
    }

    public static int[] bucketSort(int[]A, int max)
    {
        int[] bucket = new int[max + 1];
        int[] sorted = new int[A.length];

        for(int i = 0; i < A.length; i++)
        {
            bucket[A[i]]++;
        }

        int index = 0;
        for(int i = 0; i < bucket.length; i++)
        {
            for(int j = 0; j < bucket[i]; j++)
            {
                sorted[index] = i;
                index++;
            }
        }
        return sorted;
    }
}
