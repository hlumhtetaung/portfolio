package sorting;

public class QuickSort {
    static int[] array = {1, 5, 3, 6, 7, 9, 8, 2};


    public static void main(String[] args) {

        System.out.println("Before sorting: ");
        print(array);
        QuickSort(0, array.length - 1);
        System.out.println("\nAfter sorting: ");
        print(array);
    }

    // print method
    public static void print(int[] array){
        for(int a : array){
            System.out.print(a + " ");
        }
    }

    // sorting method
    public static void QuickSort(int L, int R){
        if(R - L <= 0){
            return;
        }
        int P = L;
        int parti = partition(L, R, P);
        QuickSort(L, parti - 1); // left partition
        QuickSort(parti + 1, R); // right partition
    }

    public static int partition(int L, int R, int P) {
        L++;
        while (L <= R) {
            while (array[L] < array[P] && L < R) {
                L++;
            }
            while (array[R] > array[P] && R >= 0) {
                R--;
            }
            if (L < R) {
                swap(L, R);
            }
            else{
                break;
            }
        }
        swap(R, P);
        return R;
    }

    // swapping elements
    public static void swap(int a, int b){
        int temp = array[a];
        array[a] = array[b];
        array[b] = temp;
    }
}
