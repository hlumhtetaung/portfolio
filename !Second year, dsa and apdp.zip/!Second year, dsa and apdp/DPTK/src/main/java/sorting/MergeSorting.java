package sorting;

public class MergeSorting {

    public static void main(String[] args) {
        int[] array = {2, 3, 1, 6, 4, 5, 9, 7};

        System.out.println("Before sorting: ");
        print(array);
        sort(array, 0, array.length - 1);
        System.out.println("\nAfter sorting: ");
        print(array);
    }

    public static void print(int [] array){
        for(int a : array){
            System.out.print(a + " ");
        }
    }

    public static void sort(int[] array, int L, int R){
        if(L < R){
            int m = (L + R) / 2;
            sort(array, L, m); // divide left array
            sort(array, m + 1, R); // divide right array
            merge(array, L, m, R);
        }
    }

    public static void merge(int[] array, int L, int m, int R){
        int n1 = m - L + 1; // left array size
        int n2 = R - m; // right array size

        int [] LA = new int[n1]; // create left array
        int [] RA = new int[n2]; // create right array

        for(int i = 0; i < n1; i++){
            LA[i] = array[L + i];
        }

        for(int j = 0; j < n2; j++){
            RA[j] = array[m + 1 + j];
        }

        int i = 0;
        int j = 0;
        int k = L;
        while(i < n1 && j < n2){
            if(LA[i] < RA[j]){
                array[k] = LA[i];
                i++;
                k++;
            }
            else{
                array[k] = RA[j];
                j++;
                k++;
            }
        } // end while
        if(i < n1){
            array[k] = LA[i];
            i++;
            k++;
        }
        if(j < n2){
            array[k] = RA[j];
            j++;
            k++;
        }

    }

}
