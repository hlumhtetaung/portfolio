package sorting;

public class InsertionSort {
    public static void main(String[] args) {
        int[] A = {4, 3, 2, 6, 5, 8, 9, 1};
        System.out.println("Before sorting: ");
        print(A);
        insertionSort(A);

        System.out.println("\nAfter sorting: ");
        print(A);
    }

    public static void print(int[] A){
        for(int a : A){
            System.out.print(a + " ");
        }
    }

    public static void insertionSort(int[] A){
        int n = A.length;
        for(int i = 1; i < n; i++){
            int j = i;
            int temp = A[i];
            while( j > 0 && A[j-1] > temp ){
                A[j] = A[j-1];
                j--;
            }
            A[j] = temp;
        }

    }
}
