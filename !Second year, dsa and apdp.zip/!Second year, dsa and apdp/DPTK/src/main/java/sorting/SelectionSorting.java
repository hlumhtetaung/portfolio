package sorting;

import java.util.Scanner;

public class SelectionSorting {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = new int[5];
        for(int i = 0; i < 5; i++){
            System.out.print("Enter data: ");
            array[i] = sc.nextInt();
        }
        System.out.println("Before sorting: ");
        print(array);
        SelectionSort(array);
        System.out.println("\nAfter sorting: ");
        print(array);
    }

    public static void print(int[] array){
        for(int a : array){
            System.out.print(a + " ");
        }
    }

    public static void SelectionSort(int[] array){
        for(int i = 0; i < array.length; i++){
            int start = i;
            for(int j = i + 1; j < array.length; j++){
                if(array[j] < array[start]){
                    start = j;
                }
            }
            int temp = array[start];
            array[start] = array[i];
            array[i] = temp;
        }

    }
}
