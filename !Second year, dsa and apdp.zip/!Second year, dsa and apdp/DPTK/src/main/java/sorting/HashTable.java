package sorting;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;

public class HashTable {
    public static void main(String[] args) {
        Hashtable<Integer, String> hash = new Hashtable<>();
        hash.put(1, "Apple");
        hash.put(2, "Orange");
        hash.put(3, "Juice");
        hash.put(4, "Coffee");

        for(Map.Entry<Integer, String> h : hash.entrySet()){
            System.out.println(h.getKey() + " " + h.getValue());
        }

        System.out.println("++++++++++++");

        Enumeration k = hash.keys();

        while(k.hasMoreElements()){
            int key = (Integer) k.nextElement();
            System.out.println(key + " " + hash.get(key));
        }

        System.out.println("+++++++++++++");

        System.out.println(hash.values());
    }
}
