package sorting;

import java.util.Scanner;

public class BubbleSort{

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int[] A= new int[5];
        for(int i=0; i< A.length;i++)
        {
            System.out.print("Enter Data : ");
            A[i]= sc.nextInt();
        }
        System.out.println("Before Sorting");
        print(A);

        bubbleSort(A);

        System.out.println("After Sorting");
        print(A);
    }

    public static void print(int[] A)
    {
        for (int a : A)
            System.out.print(a+" ");
    }
    public static void bubbleSort(int[] A)
    {
        int n=A.length;
        for(int i=1; i<= n; i++)
        {
            for (int j=1; j<=(n-i); j++)
            {
                if (A[j-1] > A[j]){
                    int temp = A[j-1];
                    A[j-1] = A[j];
                    A[j] = temp;
                }
            }
        }
    }
}