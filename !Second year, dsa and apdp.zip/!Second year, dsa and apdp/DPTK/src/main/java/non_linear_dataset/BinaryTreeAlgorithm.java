package non_linear_dataset;

public class BinaryTreeAlgorithm {

    public static void inOrder(Node root)
    {
        if (root != null)
        {
            inOrder(root.left); // recursive
            System.out.print(root.data + " ");
            inOrder(root.right);
        }
    }

    public static void preOrder(Node root)
    {
        if (root != null)
        {
            System.out.print(root.data + " ");
            preOrder(root.left); // recursive
            preOrder(root.right);
        }
    }

    public static void postOrder(Node root)
    {
        if (root != null)
        {
            preOrder(root.left); // recursive
            preOrder(root.right);
            System.out.print(root.data + " ");
        }
    }

    public static void main(String[] args) {
        Node root = new Node('*');

        root.left = new Node('+');
        root.left.left = new Node('a');
        root.left.right = new Node('b');

        root.right = new Node('-');
        root.right.left = new Node('c');
        root.right.right = new Node('d');

        System.out.println("InOrder process: ");
        inOrder(root);

        System.out.println("\nPreorder process: ");
        preOrder(root);

        System.out.println("\nPostorder process: ");
        postOrder(root);


    }
}
