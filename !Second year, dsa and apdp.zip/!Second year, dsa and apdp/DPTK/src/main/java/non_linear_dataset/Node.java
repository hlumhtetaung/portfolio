package non_linear_dataset;

public class Node {
    char data;
    Node left;
    Node right;

    public Node(char data)
    {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}
