package non_linear_dataset;

public class FloyWarShallAlgorithm {
    static int INF = 999999;
    public static void main(String[] args)
    {
        int[][] graph = {{0, 3, INF, 5},
                {2, 0, INF, 4},
                {INF, 1, 0, INF},
                {INF, INF, 2, 0}};

        FloyWarShall(graph);
    }

    public static void FloyWarShall(int[][] graph)
    {
        int n = graph.length;
        int[][] A = new int[n][n];
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
            {
                A[i][j] = graph[i][j];
            }
        }
        for(int k = 0; k < n; k++)
        {
            for(int i = 0; i < n; i++)
            {
                for(int j = 0; j < n; j++)
                {
                    if(A[i][k] + A[k][j] < A[i][j])
                    {
                        A[i][j] = A[i][k] + A[k][j];
                    }
                }
            }
        } // end for

        print(A);
    }

    public static void print(int[][] A)
    {
        for(int i = 0; i < A.length; i++)
        {
            for(int j = 0; j < A.length; j++)
            {
                if(A[i][j] == INF)
                {
                    System.out.print("INF ");
                }
                else
                {
                    System.out.print(A[i][j] + " ");
                }
            }
            System.out.println();
        }
    }

}
