package recursive;

import java.util.Scanner;

public class NumberAddition {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number: ");
        int num = sc.nextInt();
        int answer = sum(num);
        System.out.println("Sum: " + answer);
    }

    public static int sum(int num){
        if(num < 1){
            return 0;
        }
        else {
            return num + sum(num - 1);
        }
    }
}
