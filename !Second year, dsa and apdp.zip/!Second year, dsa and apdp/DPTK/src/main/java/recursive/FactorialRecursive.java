package recursive;

import java.util.Scanner;

public class FactorialRecursive {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the factorial number: ");
        int fact = sc.nextInt();
        int answer = factorial(fact);
        System.out.println("The factoral of " + fact + " is " + answer);
    }

    // recursive function
    public static int factorial(int fact){
        if(fact <= 1){
            return 1;
        }
        else {
            return fact * factorial(fact - 1);
        }
    }

}
