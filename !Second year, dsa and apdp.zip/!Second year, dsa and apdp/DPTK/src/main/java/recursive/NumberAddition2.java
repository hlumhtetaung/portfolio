package recursive;

import java.util.Scanner;

public class NumberAddition2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number to perform addition: ");
        int num = sc.nextInt();


        int answer = addition(num);
        System.out.println("The answer is " + answer);
    }

    public static int addition(int num) {
        if(num < 1){
            return 0;
        }
        else{
            return num + addition(num - 1);
        }
    }

}
