package recursive;

public class ArrayAddition {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        System.out.println("Array: ");
        for(int i : array){
            System.out.print(i + " ");
        }

        int answer = sumrecursive(array, array.length);
        System.out.println("\nSum: " + answer);
    }

    public static int sumrecursive(int[] array, int n){
        if(n == 0){
            return 0;
        }
        else {
            return array[n - 1] + sumrecursive(array, (n - 1));
        }
    }

}
