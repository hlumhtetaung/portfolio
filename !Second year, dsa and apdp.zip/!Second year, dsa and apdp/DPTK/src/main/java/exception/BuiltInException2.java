package exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BuiltInException2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter Array Size: ");
            int n = sc.nextInt();

            int[] A = new int[n];

            for (int i = 0; i < n; i++) {
                System.out.println("Enter data: ");
                A[i] = sc.nextInt();
                int result = A[i] / i;
                System.out.println(result);
            }
        } catch (ArithmeticException e) {
            System.out.println("not divisible by 0");
        } catch (InputMismatchException e) {
            System.out.println("wrong input");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index out of bound");
        }
    }
}
