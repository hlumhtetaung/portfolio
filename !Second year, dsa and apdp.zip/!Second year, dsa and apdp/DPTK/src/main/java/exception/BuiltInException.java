package exception;

// error

public class BuiltInException {
    public static void main(String[] args) {
        try {
//            int[] A = {2, 3, 6, 1, 9};

//        for (int i = 0; i < A.length; i++) {
//            int result = A[i] * A[i + 1];
//            System.out.println(result);
//        }

            int num = 7;
            int divisor = 1;

            while (divisor <= num) {
                if (num % divisor != 0) {
                    divisor++;
                } else break;
            }

            if (num == divisor) {
                System.out.println("Prime number");
            }
            else {
                System.out.println("Not prime number");
            }
        } catch (ArithmeticException e) {
            System.out.println("not divisible by zero");
        }
    }
}
