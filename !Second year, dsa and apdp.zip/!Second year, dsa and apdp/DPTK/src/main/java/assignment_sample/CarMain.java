package assignment_sample;

import com.opencsv.exceptions.CsvValidationException;

import java.io.IOException;

public class CarMain {
    public static void main(String[] args) throws CsvValidationException, IOException {
        new CarOperation().menu();
    }
}
