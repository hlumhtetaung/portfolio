package assignment_sample;

public class Car {
    private int carNum;
    private String carName;
    private int carModel;
    private int kilometer;
    private String fuelType;
    private String driveType;
    private int price;

    public Car(int carNum, String carName, int carModel, int kilometer, String fuelType, String driveType, int price) {
        this.carNum = carNum;
        this.carName = carName;
        this.carModel = carModel;
        this.kilometer = kilometer;
        this.fuelType = fuelType;
        this.driveType = driveType;
        this.price = price;
    }

    public int getCarNum() {
        return carNum;
    }

    public void setCarNum(int carNum) {
        this.carNum = carNum;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public int getCarModel() {
        return carModel;
    }

    public void setCarModel(int carModel) {
        this.carModel = carModel;
    }

    public int getKilometer() {
        return kilometer;
    }

    public void setKilometer(int kilometer) {
        this.kilometer = kilometer;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getDriveType() {
        return driveType;
    }

    public void setDriveType(String driveType) {
        this.driveType = driveType;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
