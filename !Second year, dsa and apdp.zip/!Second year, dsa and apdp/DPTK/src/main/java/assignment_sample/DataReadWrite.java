package assignment_sample;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.*;
import java.util.ArrayList;

public class DataReadWrite {
    public static ArrayList<Car> openCSVRead() throws IOException, CsvValidationException {
        ArrayList<Car> cars = new ArrayList<>();
        FileReader fr = new FileReader("Data/carsDataset.csv");
        CSVReader csv = new CSVReader(fr);
        String[] st;
        while ((st = csv.readNext()) != null) {
            cars.add(new Car(Integer.parseInt(st[0]), st[1], Integer.parseInt(st[2]),
                    Integer.parseInt(st[3]), st[4], st[5], Integer.parseInt(st[6])));
        }

        csv.close();
        fr.close();
        return cars;
    }

    public static void DataWrite(ArrayList<Car> cars, String fname, boolean append) throws IOException {
        FileWriter fw = new FileWriter(fname, append);
        PrintWriter pw = new PrintWriter(fw);

        for (Car c : cars) {
            pw.write(c.getCarNum() + "," + c.getCarName() + "," + c.getCarModel() + "," + c.getKilometer() +
                    "," + c.getFuelType() + "," + c.getDriveType() + "," + c.getPrice() + "\n");
        }

        fw.close();
        pw.close();
    }

    public static void RenameFile(String oldFile, String newFile) {
        File old = new File(oldFile);
        File New = new File(newFile);
        File temp = new File(oldFile);  // old file stored in temp

        old.delete();

        New.renameTo(temp);        // new file name changes to old file name
    }
}
