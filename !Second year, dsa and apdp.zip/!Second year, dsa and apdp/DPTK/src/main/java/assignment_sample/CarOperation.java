package assignment_sample;

import com.opencsv.exceptions.CsvValidationException;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class CarOperation implements CarInterface{
    Scanner sc = new Scanner(System.in); // scanner as global variable

    public void menu() throws CsvValidationException, IOException {
        System.out.println("Welcome to car information system.");
        System.out.println("1. Insert car information");
        System.out.println("2. Update car information");
        System.out.println("3. Delete car information");
        System.out.println("4. View car information");
        System.out.println("5. Search car information");
        System.out.println("6. Sort car information");
        System.out.println("7. Count of cars");
        System.out.println("8. Exit");
        System.out.print("Choose Option: ");
        int option = sc.nextInt();

        switch (option) {
            case 1:
                insert();
                break;
            case 2:
                update();
                break;
            case 3:
                delete();
                break;
            case 4:
                view();
                break;
            case 5:
                search();
                break;
            case 6:
                sort();
                break;
            case 7:
                count();
                break;
            case 8:
                exit();
                break;
            default:
                System.out.println("Invalid option!");
        }
        repeat();
    }

    public void repeat() throws CsvValidationException, IOException {
        System.out.println("Do another operation? Y/N: ");
        char status = sc.next().charAt(0);
        if (status == 'Y') {
            menu();
        }
        else
            exit();
    }

    public void exit() {
        System.out.println("Thank you for using car system!");
        System.exit(0);
    }

    @Override
    public void insert() throws IOException {
        ArrayList<Car> cars = new ArrayList<>();

        System.out.println("Enter car no: ");
        int cno = sc.nextInt();
        System.out.println("Enter car name: ");
        String cname = sc.next();
        System.out.println("Enter car model: ");
        int cmodel = sc.nextInt();
        System.out.println("Enter car kilometer: ");
        int kilo = sc.nextInt();
        System.out.println("Enter car fuel type: ");
        String fuelType = sc.next();
        System.out.println("Enter car drive type: ");
        String driveType = sc.next();
        System.out.println("Enter car price: ");
        int price = sc.nextInt();

        cars.add(new Car(cno, cname, cmodel, kilo, fuelType, driveType, price));
        DataReadWrite.DataWrite(cars, "Data/carsDataset.csv", true);
        System.out.println("Insert successfully.");
    }

    @Override
    public void update() throws CsvValidationException, IOException {
        boolean flag = false;
        System.out.println("Enter Car No: ");
        int cno = sc.nextInt();
        System.out.println("Enter update car price: ");
        int price = sc.nextInt();

        ArrayList<Car> cars = DataReadWrite.openCSVRead();

        for (Car c : cars) {
            if (c.getCarNum() == cno) {
                c.setPrice(price);
                System.out.println("Update successfully.");
                flag = true;
                break;
            }

        }
        if (!flag) {
            System.out.println(cno + " doesn't exist!");
        }
        else {
            DataReadWrite.DataWrite(cars, "Data/NewCarDataset.csv", true);
            DataReadWrite.RenameFile("Data/carsDataset.csv", "Data/NewCarDataset.csv");
        }
    }

    @Override
    public void delete() throws CsvValidationException, IOException {
        boolean flag = false;
        System.out.println("Enter delete car No: ");
        int cno = sc.nextInt();

        ArrayList<Car> cars = DataReadWrite.openCSVRead();
        for (Car c : cars) {
            if (c.getCarNum() == cno) {
                cars.remove(c);
                flag = true;
                System.out.println("Delete successfully.");
                break;
            }
        }
        if (!flag) {
            System.out.println(cno + " doesn't exist!");
        }
        else {
            DataReadWrite.DataWrite(cars, "Data/NewCarDataset.csv", true);
            DataReadWrite.RenameFile("Data/carsDataset.csv", "Data/NewCarDataset.csv");
        }
    }

    @Override
    public void view() throws CsvValidationException, IOException {
        ArrayList<Car> cars = DataReadWrite.openCSVRead();
        viewTable(cars);
    }

    public void viewTable(ArrayList<Car> cars) {
        AsciiTable table = new AsciiTable();
        table.addRule();

        List<Object> title = Arrays.asList("Car number", "Car Name", "Car Model", "Kilometer", "Fuel Type",
                "Drive Type", "Price");
        table.addRow(title);
        table.addRule();

        for (Car c : cars) {
            List<Object> data = Arrays.asList(c.getCarNum(), c.getCarName(), c.getCarModel(), c.getKilometer(),
                    c.getFuelType(), c.getDriveType(), c.getPrice());
            table.addRow(data);
            table.addRule();
        }
        table.setTextAlignment(TextAlignment.CENTER);
        System.out.println((table.render()));
    }

    @Override
    public void search() throws CsvValidationException, IOException {
        ArrayList<Car> searchCar = new ArrayList<>();
        boolean flag = false;
        long startTime = System.currentTimeMillis();
        System.out.println("Enter car model: ");
        int model = sc.nextInt();

        ArrayList<Car> cars = DataReadWrite.openCSVRead();
        for (Car c : cars) {
            if (c.getCarModel() == model) {
                searchCar.add(c);
                flag = true;
            }
        }
        if (!flag) {
            System.out.println(model + " does not exist.");
        }
        else {
            Collections.sort(searchCar, Comparator.comparing(Car :: getPrice));
            viewTable(searchCar);
        }
        long endTime = System.currentTimeMillis();
        long totalTime = endTime - startTime;
        System.out.println("The total time taken is " + totalTime + "ms");

        Runtime runtime = Runtime.getRuntime();
        runtime.gc();

        long memory = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Memory used by bytes " + memory + " bytes.");
        System.out.println("Memory used by megabytes " + memory / (1024L * 1024L) +"MB");
    }

    @Override
    public void sort() throws CsvValidationException, IOException {
        ArrayList<Car> cars = DataReadWrite.openCSVRead();

        Collections.sort(cars, Comparator.comparing(Car::getCarModel)); // ascending sort
//        Collections.sort(cars, Collections.reverseOrder(Comparator.comparing(Car::getCarModel))); // descending sort

        viewTable(cars);
    }

    @Override
    public void count() throws CsvValidationException, IOException {
        ArrayList<Car> cars = DataReadWrite.openCSVRead();
        AsciiTable table = new AsciiTable();
        table.addRule();

        List<Object> title = Arrays.asList("Car Model", "No of car");
        table.addRow(title);
        table.addRule();

        Map<Integer, Long> count = cars.stream().collect(Collectors.groupingBy
                (Car :: getCarModel, Collectors.counting()));
        for (Map.Entry<Integer, Long> entry : count.entrySet()) {
            int model = entry.getKey();
            long noOfCar = entry.getValue();

            List<Object> data = Arrays.asList(model, noOfCar);
            table.addRow(data);
            table.addRule();
        }
        table.setTextAlignment(TextAlignment.CENTER);
        System.out.println(table.render(25));
    }


}
