package assignment_sample;

import com.opencsv.exceptions.CsvValidationException;

import java.io.IOException;

public interface CarInterface  {
    // ADT operations for system

    void insert() throws IOException;
    void update() throws CsvValidationException, IOException;
    void delete() throws CsvValidationException, IOException;
    void view() throws CsvValidationException, IOException;
    void search() throws CsvValidationException, IOException;
    void sort() throws CsvValidationException, IOException;
    void count() throws CsvValidationException, IOException;
}
