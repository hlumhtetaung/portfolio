package exercises;

public class StudentInformation {
    String name;
    int age;
    String bno;
    String grade;

    public StudentInformation(int age, String name, String bno, String grade) {
        this.age = age;
        this.name = name;
        this.bno = bno;
        this.grade = grade;
    }
    //override
    public String toString(){
        return name+" "+age+" "+bno+" "+grade;
    }
}
