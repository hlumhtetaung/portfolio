package exercises;

import java.util.Scanner;

public class InterestRateCalculator {
    public static void main(String[] args) {
        //input request from the user for calculation
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter initial amount: ");
        double iniamt = sc.nextDouble();
        System.out.print("Enter number of years: ");
        int yrs = sc.nextInt();
        System.out.print("Enter interest rate: ");
        double rate = sc.nextDouble()/100;

        //calculating interest
        double total = iniamt*Math.pow((1+rate), yrs);
        System.out.println("The final amount after "+yrs+" years: ");
        System.out.printf("%.2f", total);
    }
}
