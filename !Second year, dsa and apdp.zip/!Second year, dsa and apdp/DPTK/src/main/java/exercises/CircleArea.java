package exercises;

import java.util.Scanner;

public class CircleArea {
    static double[] radius = new double[5];

    public static void area(){
        for (double v : radius) {
            double area = 3.142 * Math.pow(v, 2);
            System.out.println("area of the circle: "+area);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        for(int i=0; i<radius.length; i++){
            System.out.print("Enter radius for circle: ");
            radius[i] = sc.nextDouble();
        }

        area();

    }
}
