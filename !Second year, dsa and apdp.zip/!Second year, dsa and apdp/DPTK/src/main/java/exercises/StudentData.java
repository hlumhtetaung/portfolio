package exercises;

import java.util.Scanner;

public class StudentData {
    public static void main(String[] args) {
        StudentInformation[] st = new StudentInformation[5];
        insert(st);
        print(st);
    }

    public static void insert(StudentInformation[] st){
        Scanner sc = new Scanner(System.in);
        for(int i=0; i<st.length; i++){
            sc.nextLine();
            System.out.print("Enter student name: ");
            String name = sc.nextLine();
            System.out.print("Enter student age: ");
            int age = sc.nextInt();
            System.out.print("Enter student batch no: ");
            String bno = sc.next();
            System.out.print("Enter student grade: ");
            String grade = sc.next();

            st[i] = new StudentInformation(age, name, bno, grade);
        }
    }
    public static void print(StudentInformation[] st){
        for (StudentInformation studentInformation : st) {
            System.out.println(studentInformation.toString());
        }
    }
}
