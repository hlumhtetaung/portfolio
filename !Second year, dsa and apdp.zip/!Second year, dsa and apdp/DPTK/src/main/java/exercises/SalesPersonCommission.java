package exercises;

import java.util.Scanner;

public class SalesPersonCommission {
    public static void main(String[] args) {
        double salary;
        double salesamt;
        double commission;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter basic salary of the sales person: ");
        salary = sc.nextInt();
        System.out.print("Enter the sales amount: ");
        salesamt = sc.nextInt();
        commission = salesamt * 0.15;
        if(salesamt<500){
            System.out.println("There are no commissions.");
            System.out.println("salary for this month: "+salary);
        }
        else if(salesamt>500){
            System.out.println("The commission for this month is "+commission);
            System.out.println("The total salary for this month is "+(salary+commission));
        }
    }
}
