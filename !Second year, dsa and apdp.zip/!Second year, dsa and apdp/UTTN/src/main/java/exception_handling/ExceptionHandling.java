package exception_handling;

import java.util.Scanner;

public class ExceptionHandling {
    static void divide(int num1, int num2) {
        try{
            int result = num1 / num2;
            System.out.println(result);

//            String s1 = "Foobar"; // String
////            int i1 = Integer.parseInt(s1); // number formatting
//
//            String s = null;
////            System.out.println(s.length());
//
//            Scanner sc = new Scanner(System.in);
//            System.out.println("Enter your name: ");
//            int i = sc.nextInt();

        } catch (ArithmeticException e) { // specific arithmetic error
            System.out.println("Arithmetic Error.");
        } catch (NumberFormatException e) { // catch number formatting exception
            System.out.println("Number Format Exception.");
        } catch (Exception e) { // general for unknown exception
            System.out.println("Exception Error.");
            System.out.println(e.toString());
        }
    }

    public static void main(String[] args) {
        divide(3, 0);
    }
}
