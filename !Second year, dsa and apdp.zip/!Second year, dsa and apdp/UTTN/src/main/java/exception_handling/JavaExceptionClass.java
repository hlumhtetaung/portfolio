package exception_handling;

import Inheritance.Child;
import Inheritance.Parent;

import java.util.Scanner;

public class JavaExceptionClass {
    public static void main(String[] args) {
//        int[] arr = new int[3];
//        System.out.println(arr[5]); // array index out of bound

//        int i = 3;
//        System.out.println(i / 0); // divided by 0

//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter a number: ");
//        int num1 = sc.nextInt();

//        System.out.println(add(10));

        Parent parent = new Parent("Jame", 5000);
//        Child child = new Child("James", 5000); // class cast exception
    }
}
