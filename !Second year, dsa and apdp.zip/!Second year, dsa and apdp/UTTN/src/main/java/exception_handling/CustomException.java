package exception_handling;


public class CustomException extends Exception {
        String exceptionName;

        CustomException(String name) {
            this.exceptionName = name;
        }

        @Override
        public String toString() {
            return "customException{" +
                    "exceptionName='" + exceptionName + '\'' +
                    '}';
        }
}