package exception_handling;

public class CustomExceptionMain {
    public static void main(String[] args) {
        try {
            throw new CustomException("User Defined Exception.");
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
