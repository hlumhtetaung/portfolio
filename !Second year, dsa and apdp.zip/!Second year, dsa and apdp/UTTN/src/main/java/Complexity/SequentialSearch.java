package Complexity;

public class SequentialSearch {
    static int SequentialSearch(int[] arr, int k)
    {
        int i = -1;
        do {
            i += 1;

        }while (i < arr.length && arr[i] != k);
        if(i < arr.length)
        {
            return i;
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {20, 35, 3, 4, 8, 7, 9, 12, 22, 34};
        int key = 20;
        int result = SequentialSearch(arr, key);
        System.out.println("The result key is " + result);
    }
}
