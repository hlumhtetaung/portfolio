package arraylist_adt;

public class main {
    public static void main(String[] args) {
        ArrayListADT ArrADT = new ArrayListADT(3);
        ArrADT.add(0, "Mg Mg");
        ArrADT.add(1, "Ko Ko");
        ArrADT.add(2, "Kyaw Gyi");

        System.out.println(ArrADT.get(2));
    }
}
