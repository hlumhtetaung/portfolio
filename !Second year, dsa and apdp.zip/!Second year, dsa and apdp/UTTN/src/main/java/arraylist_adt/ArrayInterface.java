package arraylist_adt;

public interface ArrayInterface {
    String get(int i);
    String set(int i, String str);
    void add(int i, String str);
    String remove(int i);
}
