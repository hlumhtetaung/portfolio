package arraylist_adt;

public class ArrayListADT implements ArrayInterface {
    String localArr[];
    public ArrayListADT(int ArrLength){
        this.localArr = new String[ArrLength];
    }

    @Override
    public String get(int i) {
        return localArr[i];
    }

    @Override
    public String set(int i, String str) {
        return null;
    }

    @Override
    public void add(int i, String str) {
        this.localArr[i] = str;
    }

    @Override
    public String remove(int i) {
        return "";
    }
}
