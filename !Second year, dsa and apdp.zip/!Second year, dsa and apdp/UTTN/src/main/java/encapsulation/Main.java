package encapsulation;

public class Main {
    public static void main(String[] args) {
        Student st = new Student();
        st.setName("Mg Mg");
        st.setAge(20);

        System.out.println("He is " + st.getName() + " and " + st.getAge() + " years old.");

    }
}
