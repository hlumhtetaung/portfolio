package dsa_dttn;

import java.util.Arrays;

public class array {
    public static void main(String[] args) {
        int size = 19;
        int[] array = new int[size];
        for (int i : array){
            System.out.print(i + " ");
        }
        System.out.println();

        array[0] = 69;
        array[1] = 96;
        array[18] = 6900;
        System.out.print(Arrays.toString(array));

        System.out.println();

        int[] arr = {10, 20, 30, 40, 69};
        for (int j : arr) {
            System.out.print(j + " ");
        }
    }
}
