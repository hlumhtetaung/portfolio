package time_comparison;

public class SelectionSort {
    public static void publicMethod() {
        long startTime = System.currentTimeMillis();
        int a[] = new int[1000];
        int j = 0;
        for (int i = 1000; i > 0; i--) {
            a[j] = i;
            j++;
        }

//        selectionSort(a);
        bubbleSort(a);
        long endTime = System.currentTimeMillis();
        System.out.println("Total for execution time: " + (endTime - startTime) + "ms");
        startTime = System.currentTimeMillis();
//        recurSelectionSort(a, 999, 0);
        endTime = System.currentTimeMillis();
        System.out.println("Total recursive execution time: " + (endTime - startTime) + "ms");
    }

    public static void bubbleSort(int[] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 1; j < a.length - 1; j++) {
                if (a[j - 1] > a[j]) {
                    int temp = a[j];
                    a[j] = a[j - 1];
                    a[j - 1] = temp;
                }
            }
        }
    }

//    public static void selectionSort(int[] a) {
//        for (int i = 0; i < a.length; i++) {
//            int start = i;
//            for (int j = i + 1; j < a.length; j++) {
//                if (a[j] < a[start]) {
//                    start = j;
//                }
//            }
//            int temp = a[start];
//            a[start] = a[i];
//            a[i] = temp;
//        }
//    }

    public static void main(String[] args) {
        publicMethod();
    }
}
