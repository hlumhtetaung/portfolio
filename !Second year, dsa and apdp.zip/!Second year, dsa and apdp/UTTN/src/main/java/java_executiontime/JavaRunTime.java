package java_executiontime;

public class JavaRunTime {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        long total = 0;

        for (int i = 0; i < 10000000; i++)
        {
            for (int j = 0; j < 100; j++)
            {
                total += j;
            }
        }
        System.out.println(total);

        long stopTime = System.currentTimeMillis();
        long executionTime = stopTime -  startTime;

        System.out.println("Total execution time is " + executionTime);

    }
}
