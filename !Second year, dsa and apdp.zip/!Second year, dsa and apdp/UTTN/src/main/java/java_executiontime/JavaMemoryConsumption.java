package java_executiontime;

import java.util.ArrayList;
import java.util.List;

public class JavaMemoryConsumption {
    private static final long MEGABYTE = 1024L * 1024L;

    public static long bytesToMegaBytes(long bytes)
    {
        return bytes / MEGABYTE;
    }

    public static void main(String[] args)
    {
        List<Person> list = new ArrayList<Person>();

        for(int i = 0; i <= 100000; i++)
        {
            list.add(new Person(20, "Kim"));
        }

        Runtime runtime = Runtime.getRuntime();
        runtime.gc();

        long memory = runtime.totalMemory() + runtime.freeMemory();
        System.out.println("Use memory: " + memory);
        System.out.println("Use memory in megabytes: " + bytesToMegaBytes(memory));
        System.out.println("Total memory: " + runtime.totalMemory());
        System.out.println("Total free memory: " + runtime.freeMemory());
        System.out.println("Max memory: " + bytesToMegaBytes(runtime.maxMemory()));
    }
}
