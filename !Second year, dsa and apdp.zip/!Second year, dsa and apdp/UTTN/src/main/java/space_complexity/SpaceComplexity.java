package space_complexity;

public class SpaceComplexity {
    int isum(int[] a, int n) {
        int x = 0; // 4 byte for x
        for (int i = 0; i < n; i++) { // 4 byte for i
            x = x + a[i];
        }
        return x;
    }

}
