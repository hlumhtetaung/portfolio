package queue_adt;

public interface QueueInterface {

    void enqueue(String element);
    String dequeue();
    String peek();
    boolean isFull();
    boolean isEmpty();

}
