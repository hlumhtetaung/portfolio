package queue_adt;

import java.util.LinkedList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        QueueImplementation queue = new QueueImplementation(5);
        LinkedList myll = new LinkedList();

        Scanner sc = new Scanner(System.in);

        while(!queue.isFull()){
            System.out.println("Enter a name: ");
            String element = sc.nextLine();
            queue.enqueue(element);
        }

        queue.enqueue("mg mg");

        while(!queue.isEmpty()){
            System.out.print(queue.dequeue() + " : ");
        }
    }
}
