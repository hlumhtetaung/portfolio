package queue_adt;

public class QueueImplementation implements QueueInterface {

    int front;
    int rear;
    int size;
    String arr[];

    QueueImplementation(int size){
        this.arr = new String[size];
        this.size = size;
        this.front = -1;
        this.rear = -1;

    }

    @Override
    public void enqueue(String element) {
        if(!isFull()){
            if(rear == this.size){
                rear = -1;
            }
            arr[++rear] = element;
            if(front == -1){
                front++;
            }
        }
        else{
            System.out.println("Queue is full!");
        }
    }

    @Override
    public String dequeue() {
        if(isEmpty()){
            return "Queue is empty";
        }
        String element = arr[front++];
        if(front == size){
            front = -1;
        }
        return element;
    }

    @Override
    public String peek() {
        return arr[front];
    }

    @Override
    public boolean isFull() {
        return rear == size - 1;
    }

    @Override
    public boolean isEmpty() {
        return front == -1;
    }
}
