package stack;

public class IntegerStackADT implements IntegerStackInterface {
    int stack[];
    int top;

    // constructor
    IntegerStackADT(int size){
        this.stack = new int[size];
        this.top = -1;
    }


    @Override
    public void push(int element) {
        if(isFull()){
            System.out.println("Stack is full, can't fit anymore.");
            return;
        }
        this.stack[++top] = element;
    }

    @Override
    public int pop() {
        if(isEmpty()){
            return 0;
        }
        return this.stack[top--];
    }

    @Override
    public int peek() {
        if(isEmpty()){
            return 0;
        }
        return this.stack[top];
    }

    @Override
    public int size() {
        return this.stack.length;
    }

    @Override
    public boolean isFull() {
        return top == this.stack.length - 1;
    }

    @Override
    public boolean isEmpty() {
        return top == -1;
    }

    public void printStack(){
        for(int i = 0; i <= top; i++){
            System.out.print(stack[i]+" ");
        }
    }


    public static void main(String[] args) {
        IntegerStackADT stack_adt = new IntegerStackADT(3);
        stack_adt.push(1);
        stack_adt.push(2);
        stack_adt.push(3);
        stack_adt.printStack();
        System.out.println();
        stack_adt.push(4);
        System.out.println("element popped: " + stack_adt.pop());
        stack_adt.printStack();
    }
}
