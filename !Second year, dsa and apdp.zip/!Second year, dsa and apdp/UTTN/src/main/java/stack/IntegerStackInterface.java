package stack;

public interface IntegerStackInterface {
    void push(int element);
    int pop();
    int peek();
    int size();
    boolean isFull();
    boolean isEmpty();
}
