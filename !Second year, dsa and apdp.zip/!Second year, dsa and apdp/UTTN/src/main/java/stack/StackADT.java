package stack;

import java.util.Arrays;

public class StackADT implements StackInterface{
    String stack[];
    int top;

    // constructor
    StackADT(int size){
        this.stack = new String[size];
        this.top = -1;
    }

    @Override
    public void push(String element) {
        if(isFull()){
            System.out.println("Stack is full can't push.");
            return;
        }
        this.stack[++top] = element;
    }

    @Override
    public String pop() {
        if(isEmpty()){
            return "Stack is empty.";
        }
//        String element = this.stack[top];
//        top --;
        return this.stack[top--];
    }

    @Override
    public String peek() {
        if(isEmpty()){
            return "Stack is empty.";
        }
        return this.stack[top];
    }

    @Override
    public int size() {
        return this.stack.length;
    }

    @Override
    public boolean isFull() {
        return top == this.stack.length - 1;
    }

    @Override
    public boolean isEmpty() {
        return top == -1;
    }

    public void printStack(){
        for(int i = 0; i <= top; i++){
            System.out.print(stack[i]+" ");
        }
    }


    public static void main(String[] args) {
        StackADT stack_adt = new StackADT(3);
        stack_adt.push("Ko Ko");
        stack_adt.push("Mg Mg");
        stack_adt.push("Ma Ma");
        stack_adt.printStack();
        stack_adt.push("Nyi Nyi");
        System.out.println(stack_adt.pop());
        stack_adt.printStack();
    }
}
