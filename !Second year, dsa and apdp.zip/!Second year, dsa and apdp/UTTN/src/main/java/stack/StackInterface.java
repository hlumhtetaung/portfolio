package stack;

public interface StackInterface {
    void push(String element);
    String pop();
    String peek();
    int size();
    boolean isFull();
    boolean isEmpty();
}
