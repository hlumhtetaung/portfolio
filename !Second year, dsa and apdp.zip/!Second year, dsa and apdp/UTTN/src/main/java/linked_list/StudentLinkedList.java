package linked_list;

import java.util.LinkedList;

public class StudentLinkedList {
    public static void main(String[] args) {
        Student mgmg = new Student("Mg Mg", 20);
        Student mama = new Student("Ma Ma", 23);
        Student koko = new Student("Ko Ko", 24);

        LinkedList<Student> studentLinkedList = new LinkedList<Student>();

        studentLinkedList.add(mgmg); // add new[mg mg]
        studentLinkedList.add(mama); // add new[ma ma]
        print(studentLinkedList);
        System.out.println("After adding mg mg and ma ma: ");
        studentLinkedList.set(0, koko); // add new[ko ko]
        print(studentLinkedList);
        System.out.println("After replacing mg mg with ko ko: ");
    }

    static void print(LinkedList<Student> studentLinkedList)
    {
        for(Student st : studentLinkedList)
        {
            System.out.println(st.getInfo());
        }
    }

}
