package linked_list;

public class Student {
    String name;
    int age;

    Student(String name, int age)
    {
        this.name = name;
        this.age = age;
    }

    String getInfo(){
        return "Student name is: " + this.name + ", age is: " + this.age;
    }
}
