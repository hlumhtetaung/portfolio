package Inheritance;

public class Child extends Parent{

    public Child(String familyName, float income) {
        super(familyName, income);
    }

}
