package Inheritance;

public class Parent {
    protected float income;
    protected String familyName;

    public Parent(String familyName, float income)
    {
        this.familyName = familyName;
        this.income = income;
    }

    public void display()
    {
        System.out.println("Family name: " + this.familyName);
        System.out.println("Income: " + this.income);
    }
}
