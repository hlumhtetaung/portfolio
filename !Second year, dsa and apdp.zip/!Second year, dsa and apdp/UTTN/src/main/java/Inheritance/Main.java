package Inheritance;

public class Main {
    public static void main(String[] args) {
        Parent parent = new Parent("Golden", 50000);
        Child child = new Child("Silver", 400000);

        parent.display();
        child.display();

        Parent newChild = new Child("Metal", 300000);
        newChild.display();
    }
}
