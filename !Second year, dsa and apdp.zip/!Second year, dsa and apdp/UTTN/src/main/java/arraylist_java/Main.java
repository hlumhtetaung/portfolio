package arraylist_java;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Student s1 = new Student("Ko Ko", 18, "male");
        Student s2 = new Student("Mg Mg", 16, "male");
        Student s3 = new Student("Ma Ma", 20, "female");
        //Adding new students
        Student s4 = new Student("Ko Mg", 18, "male");
        Student s5 = new Student("Nyi Ma", 17, "female");
        Student s6 = new Student("Ma May", 21, "female");
        Student s7 = new Student("Kyaw Gyi", 18, "male");
        Student s8 = new Student("Nyi Nyi", 17, "male");

        ArrayList <Student> StudentList = new ArrayList<Student>();
        StudentList.add(s1);
        StudentList.add(s2);
        StudentList.add(s3);
        displayStudents(StudentList);

        System.out.println("Added new student: ");
        StudentList.add(s4);
        StudentList.add(s5);
        StudentList.add(s6);
        StudentList.add(s7);
        StudentList.add(s8);
        displayStudents(StudentList);

        System.out.print("Removed student: \n");
        StudentList.remove(s3);
        displayStudents(StudentList);
        System.out.println();

        System.out.println("Replace student 1 with student 3: ");
        StudentList.set(0, s3);
        displayStudents(StudentList);
    }

    static void displayStudents(ArrayList<Student> StudentList){
        for(Student st : StudentList){
            System.out.println("Student name: "+st.getName()+"\n"+"Age: "+st.getAge()+"\nGender: "+st.getGender()+"\n");
        }
    }

}
