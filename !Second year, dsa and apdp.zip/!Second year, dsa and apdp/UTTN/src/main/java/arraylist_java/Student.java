package arraylist_java;

public class Student {
    private String name;
    private int age;
    private String gender;

    public Student(String name, int age, String gender){
        this.name = name;
        this.gender = gender;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }
}
