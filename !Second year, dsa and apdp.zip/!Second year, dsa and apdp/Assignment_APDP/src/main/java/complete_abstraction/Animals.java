package complete_abstraction;

public interface Animals {
    void eat();
    void makeSound();
}
