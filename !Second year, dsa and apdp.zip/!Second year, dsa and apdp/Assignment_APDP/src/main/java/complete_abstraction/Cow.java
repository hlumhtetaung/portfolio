package complete_abstraction;

public class Cow implements Animals {

    @Override
    public void eat() {
        System.out.println("Cow eats grass.");
    }

    @Override
    public void makeSound() {
        System.out.println("Moo");
    }
}
