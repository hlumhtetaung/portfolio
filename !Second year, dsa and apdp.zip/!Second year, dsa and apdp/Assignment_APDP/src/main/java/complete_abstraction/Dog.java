package complete_abstraction;

public class Dog implements Animals {
    @Override
    public void eat() {
        System.out.println("Dog eat meat.");
    }

    @Override
    public void makeSound() {
        System.out.println("Woof");
    }
}
