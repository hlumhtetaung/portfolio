package association;

public class AssociationTesting {
    public static void main(String[] args) {
        Teacher teacher = new Teacher("Chang Li");
        Student student = new Student("Jinshi");

        student.teach(teacher);
    }
}

class Teacher {
    String teacher;

    public Teacher(String teacher) {
        this.teacher = teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
}

class Student {
    String student;

    public Student(String student) {
        this.student = student;
    }

    public String getStudent() {
        return student;
    }

    public void teach(Teacher teacher) {
        System.out.println(student + " is a student of " + teacher.teacher);
    }
}