package compile_time_polymorphism;

public class Addition {
    public String add() {
        return "Addition is the sum of two numbers";
    }

    public int add(int a, int b) {
        return a + b;
    }
}
