package compile_time_polymorphism;

public class AdditionTesting {
    public static void main(String[] args) {
        Addition calculation = new Addition();
        calculation.add();
        calculation.add(2, 4);
    }
}
