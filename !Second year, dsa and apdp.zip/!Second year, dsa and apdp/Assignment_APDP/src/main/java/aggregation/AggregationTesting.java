package aggregation;

class Department {
    String name;

    Department(String name) {
        this.name = name;
    }
}

class University {
    private String name;
    private Department department;  // Aggregation

    University(String name, Department department) {
        this.name = name;
        this.department = department;
    }

    void showDetails() {
        System.out.println(name + " has a department: " + department.name);
    }
}

public class AggregationTesting {
    public static void main(String[] args) {
        Department csDept = new Department("Computer Science");
        University uni = new University("Tech University", csDept);

        uni.showDetails();

        // The department can still exist independently
        Department mathDept = new Department("Mathematics");
        System.out.println("Independent department: " + mathDept.name);
    }
}

class PaymentProcessor {
    public void processPayment(String type) {
        if (type.equals("credit")) {
            System.out.println("Processing credit card");
        } else if (type.equals("paypal")) {
            System.out.println("Processing PayPal");
        } else {
            System.out.println("Unknown payment type");
        }
    }
}


