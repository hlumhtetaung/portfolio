public class StackedAndHeapMemory {
    public static void main(String[] args) {
        calculation obj = new calculation();
        int result = obj.add(2, 4);
        System.out.println(result);
    }
}

class calculation {
    int instanceVar = 5; // instance variable of the class

    public int add(int a, int b)
    {
        return a + b;
    }
}
