package inheritance;

public class Subclass extends SuperClass {
    public static void main(String[] args) {
        SuperClass.addition(2, 4);
    }
}
