package inheritance;

public class SuperClass {
    int num1;
    int num2;
    public static void addition(int num1, int num2) {
        int total = num1 + num2;
        System.out.println("The addition of " + num1 + " and " + num2 + " is " + total);
    }
}
