package polymorphism;

public interface Animals {
    void makeSound();
}

class Dog implements Animals {

    @Override
    public void makeSound() {
        System.out.println("Dog barks!");
    }
}

class Cat implements Animals {

    @Override
    public void makeSound() {
        System.out.println("Cat meows!");
    }
}
