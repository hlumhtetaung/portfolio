package polymorphism;

public class PolymorphismTest {
    public static void main(String[] args) {
        Animals dog = new Dog();
        dog.makeSound();

        Animals cat = new Cat();
        cat.makeSound();
    }
}
