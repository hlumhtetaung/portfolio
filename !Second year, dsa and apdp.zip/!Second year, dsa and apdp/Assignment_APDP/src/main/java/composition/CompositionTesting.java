package composition;

public class CompositionTesting {
    public static void main(String[] args) {
        Clock clock = new Clock();
        clock.startAlarm();
    }
}

class Alarm {
    void alarmStart() {
        System.out.println("Alarm is ringing...");
    }
}

class Clock {
    private Alarm alarm;

    Clock() {
        this.alarm = new Alarm();
    }

    void startAlarm() {
        System.out.println("Time: 7:00");
        alarm.alarmStart();
    }
}