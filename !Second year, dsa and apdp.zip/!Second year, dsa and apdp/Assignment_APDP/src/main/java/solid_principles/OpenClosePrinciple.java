package solid_principles;

public class OpenClosePrinciple {
    public static void main(String[] args) {
        print(new Rectangle(2, 4));
    }

    public static void print(Shape shape) {
        System.out.println("Area: " + shape.area());
    }
}

// interface for area of different shapes
interface Shape {
    int area();
}

class Rectangle implements Shape {
    private int width;
    private int height; // width and heights are to be set with parameter

    public Rectangle(int width, int height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public int area() {
        // method to return area of rectangle
        return width * height;
    }
}
