package solid_principles;

public class InterfaceSegregation {
    public static void main(String[] args) {

    }
}

interface Printer {
    void print();

}

interface Scanner {
    void scanner();
}

class simplePrinter implements Printer, Scanner {
    @Override
    public void print() {
        System.out.println("Printer is printing.");
    }

    @Override
    public void scanner() {
        System.out.println("This printer can't scan!");
    }
}

class advancedPrinter implements Printer, Scanner {
    @Override
    public void print() {
        System.out.println("Printer is printing.");
    }

    @Override
    public void scanner() {
        System.out.println("Printer is scanning.");
    }
}