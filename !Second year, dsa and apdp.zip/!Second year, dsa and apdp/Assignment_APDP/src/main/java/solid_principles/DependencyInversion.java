package solid_principles;

public class DependencyInversion {
    public static void main(String[] args) {
        WiredKeyboard keyboard = new WiredKeyboard();
        Computer computer = new Computer(keyboard);
        computer.type();
    }
}

interface Keyboard {
    void input();
}

class WiredKeyboard {
    public void input() {
        System.out.println("Wired keyboard input");
    }
}

class Computer {
    private WiredKeyboard keyboard;

    public Computer(WiredKeyboard keyboard) {
        this.keyboard = keyboard;
    }

    public void type() {
        keyboard.input();
    }
}
