package solid_principles;

public class LiskovSubstitution {
    public static void main(String[] args) {
        // Sparrow with original bird super class
        Bird bird = new Sparrow();
        bird.fly();

        // Sparrow with makeBirdFly object substitution
        Fly(new Sparrow());
    }

    public static void Fly(Bird bird) {
        bird.fly();
    }
}

class Bird {
    public void fly() {
        System.out.println("Birds fly!");
    }
}

class Sparrow extends Bird {
    public void fly() {
        System.out.println("Sparrow fly!");
    }


}

class Ostrich extends Bird {
    @Override
    public void fly() {
        System.out.println("Ostrich can't fly");
    }
}