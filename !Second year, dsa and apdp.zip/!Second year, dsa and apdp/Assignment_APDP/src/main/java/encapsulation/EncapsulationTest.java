package encapsulation;

public class EncapsulationTest {
    public static void main(String[] args) {
        Encapsulation en = new Encapsulation(5000);
        System.out.println(en.getBalance());
    }
}
