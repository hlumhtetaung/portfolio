package partial_abstraction;

public class Dog extends AbstractAnimalClass {
    public static void main(String[] args) {
        AbstractAnimalClass abs = new Dog();
        abs.makeSound();

        AbstractAnimalClass.eat();
    }

    @Override
    void makeSound() {
        System.out.println("The dog barks.");
    }
}
