package partial_abstraction;

public abstract class AbstractAnimalClass {
    abstract void makeSound();

    public static void eat() {
        System.out.println("It eats 3 times a day.");
    }
}
