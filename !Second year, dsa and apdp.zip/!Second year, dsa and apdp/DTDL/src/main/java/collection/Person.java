package collection;

public class Person {
    private int pID;
    private String PName;
    private String address;
    private int age;

    public Person(int pID, String PName, String address, int age) {
        this.pID = pID;
        this.PName = PName;
        this.address = address;
        this.age = age;
    }

    public int getpID() {
        return pID;
    }

    public void setpID(int pID) {
        this.pID = pID;
    }

    public String getPName() {
        return PName;
    }

    public void setPName(String PName) {
        this.PName = PName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "pID=" + pID +
                ", PName='" + PName + '\'' +
                ", address='" + address + '\'' +
                ", age=" + age +
                '}';
    }
}
