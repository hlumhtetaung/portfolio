package collection;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class Hashset_Example {
    public static void main(String[] args) {
        HashSet<String> hashset = new HashSet<>();
        hashset.add("One");
        hashset.add("Two");
        hashset.add("Three");
        hashset.add("Four");
        System.out.println("Initial set: " + hashset);
        HashSet<String> hashset1 = new HashSet<>();
        hashset1.add("Five");
        hashset1.add("Six");
        hashset.addAll(hashset1);
        System.out.println("Update List: " + hashset);
        hashset.removeIf(str->str.contains("Two"));
        System.out.println("After removing data: " + hashset);
        hashset.removeAll(hashset1);
        System.out.println("Update set: " + hashset);
        hashset.clear();
        System.out.println("Final list: " + hashset);
        System.out.println("==========================");
        System.out.println("Linked hashset");
        LinkedHashSet<String> linkedhashset = new LinkedHashSet<>();
        linkedhashset.add("One");
        linkedhashset.add("Two");
        linkedhashset.add("Three");
        linkedhashset.add("Four");
        System.out.println("Linked hashset: " + linkedhashset);
    }
}
