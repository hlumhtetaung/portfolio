package collection;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public class QueueExample {

    public static void main(String[] args) {
        Deque<Integer> d = new ArrayDeque<>();
        d.add(10);
        d.add(20);
        for(Integer element : d){
            System.out.println("Element: " + element);
        }
        d.clear();
        d.addFirst(564);
        d.addFirst(291);
        d.addLast(24);
        d.addLast(14);
        System.out.println("After clearing, new elements are: ");
        for(Integer element : d){
            System.out.println(element);
        }
        System.out.println();
        for (Iterator ditr = d.descendingIterator(); ditr.hasNext();){
            System.out.println(ditr.next());
        }
        System.out.println("Head element using element(): " + d.element());
        System.out.println("Head element using getFirst(): " + d.getFirst());
        System.out.println("Last element using getLast(): " + d.getLast());
    }
}
