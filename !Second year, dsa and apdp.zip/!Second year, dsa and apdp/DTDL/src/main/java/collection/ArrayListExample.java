package collection;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListExample {
    public static void main(String[] args) {
        ArrayList<Person> arrayList = new ArrayList<>();
        arrayList.add(new Person(1, "Hein Htoo Naing", "Yangon", 20));
        arrayList.add(new Person(2, "Sandi", "Mandalay", 18));
        arrayList.add(new Person(3, "May Thu Kha Chit", "Bago", 18));
        arrayList.add(1, new Person(4, "Nan Khine Thinzar", "Thai", 19));
        arrayList.add(1, new Person(5, "Hiki", "Thai", 20));
        for(Person p : arrayList){
            System.out.println(p.toString());
        }
        System.out.println();
        ListIterator<Person> listIterator = arrayList.listIterator(arrayList.size());
        while(listIterator.hasPrevious()){
            System.out.println(listIterator.previous().toString());
        }
    }

}
