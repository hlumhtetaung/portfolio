package collection;

import java.util.*;

public class SortedMap_Example {
    public static void main(String[] args) {
        SortedMap<Integer, String> sm = new TreeMap<>();
        sm.put(2, "Two");
        sm.put(3, "Three");
        sm.put(4, "Four");
        sm.put(5, "Five");
        sm.put(6, "Six");
        Set s = sm.entrySet();
        Iterator itr = s.iterator();
        while(itr.hasNext())
        {
            Map.Entry m = (Map.Entry) itr.next();
            System.out.println("Key: " + m.getKey() + ", Value: " + m.getValue());
        }
    }
}
