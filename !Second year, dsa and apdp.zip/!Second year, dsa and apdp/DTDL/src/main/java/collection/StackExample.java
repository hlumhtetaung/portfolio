package collection;

import java.util.Stack;

public class StackExample {

    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();
        stack.push("AAA");
        stack.push("BBB");
        stack.push("CCC");
        stack.push("DDD");
        stack.push("EEE");
        System.out.println(stack.peek());
        System.out.println();
        while(!stack.isEmpty()){
            System.out.println(stack.pop());
        }
        System.out.println();
        System.out.println(stack.empty());
    }
}
