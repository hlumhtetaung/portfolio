package collection;

import java.util.TreeMap;

public class TreeMap_Example {
    public static void main(String[] args) {
        TreeMap<Integer, String> map = new TreeMap<>();
        map.put(100, "One");
        map.put(102, "Two");
        map.put(101, "Three");
        map.put(103, "Four");
        System.out.println("Ascending Order: " + map);
        System.out.println("Descending Order: " + map.descendingMap());
        System.out.println("head map " + map.headMap(102, true));
        System.out.println("tail map " + map.tailMap(102, false));
        System.out.println("sub map " + map.subMap(100, true, 102, false));
    }
}
