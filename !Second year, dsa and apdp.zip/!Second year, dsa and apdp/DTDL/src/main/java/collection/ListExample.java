package collection;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ListExample {
    public static void main(String[] args) {
        List<String> al = new ArrayList<String>();
        al.add("Dana Aung");
        al.add("Zaw Thet Paing");
        al.add("Kaung Myat Soe");
        al.add("Zwe Yan Naing");
        al.add(1, "Thet Aung Hein");
        ListIterator<String> itr = al.listIterator();
        System.out.println("Forward Direction ");
        while (itr.hasNext()){
            System.out.println("Index: "+itr.nextIndex()+" Value: "+itr.next());
        }
    }
}
