package collection;

import java.util.PriorityQueue;

public class PriorityQueueExample {
    public static void main(String[] args) {
        PriorityQueue<String> p = new PriorityQueue<>();
        p.add("DDD");
        p.add("BBB");
        p.add("CCC");
        p.add("AAA");
        System.out.println("head" + p.element());
        System.out.println("head" + p.peek());
        System.out.println("Queue data ");
        while(!p.isEmpty()){
            System.out.println(p.remove());
        }
    }
}
