package popular_babyname;

import java.util.LinkedList;

public class EditBabyName {
    LinkedList<BabyName> namelist = new LinkedList<>();
    UserInput uin = new UserInput();
    Search search = new Search();

    public EditBabyName(LinkedList<BabyName> namelist) {
        this.namelist = namelist;
    }

    public void edit() {
        String name = uin.getName();
        String gender = uin.getGender();
        String year = uin.getYear();
        int index = search.search_name_gender_year(namelist, name, gender, year);
        while (index < 0) {
            System.out.println("Baby name doesn't exist to edit.");
            name = uin.getName();
            gender = uin.getGender();
            year = uin.getYear();
            index = search.search_name_gender_year(namelist, name, gender, year);
        }
        System.out.println("Enter data to edit.");
        name = uin.getName();
        gender = uin.getGender();
        year = uin.getYear();
        String count = uin.getCount();
        namelist.set(index, new  BabyName(name, gender, Integer.parseInt(year),
                0, Integer.parseInt(count)));
        search.ranking(year, gender, namelist);
        search.write_to_CSV("data/BabyName.csv", namelist);
        System.out.println("Successfully edit Baby Name.");
    }

    public void edit(String name, String gender, String year, int count) {
        int index = search.search_name_gender_year(namelist, name, gender, year);
        namelist.set(index, new BabyName(name, gender, Integer.parseInt(year), 0, count));
        search.ranking(year, gender, namelist);
        search.write_to_CSV("data/BabyName.csv", namelist);
        System.out.println("Successfully edit Baby Name.");
    }
}
