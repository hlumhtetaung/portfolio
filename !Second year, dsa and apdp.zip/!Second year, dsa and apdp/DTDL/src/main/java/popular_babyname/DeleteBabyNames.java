package popular_babyname;

import java.util.LinkedList;

public class DeleteBabyNames {
    LinkedList<BabyName> namelist = new LinkedList<>();
    UserInput uin = new UserInput();
    Search search = new Search();

    public DeleteBabyNames(LinkedList<BabyName> namelist) {
        this.namelist = namelist;
    }

    public void delete() {
        String name = uin.getName();
        String gender = uin.getGender();
        String year = uin.getYear();
        int index = search.search_name_gender_year(namelist, name, gender, year);
        while (index < 0) {
            System.out.println("Baby Name doesn't exist to delete.");
            name = uin.getName();
            gender = uin.getGender();
            year = uin.getYear();
            index = search.search_name_gender_year(namelist, name, gender, year);
        }

        namelist.remove(index);
        search.ranking(year, gender, namelist);
        search.write_to_CSV("data/Baby_Names.csv", namelist);
        System.out.println("Successfully deleted.");
    }

}
