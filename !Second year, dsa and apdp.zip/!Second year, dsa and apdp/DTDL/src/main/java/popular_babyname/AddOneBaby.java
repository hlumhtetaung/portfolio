package popular_babyname;

import java.util.LinkedList;

public class AddOneBaby {
    UserInput uin = new UserInput();
    Search search = new Search();
    LinkedList<BabyName> namelist = new LinkedList<>();

    public AddOneBaby(LinkedList<BabyName> namelist) {
        this.namelist = namelist;
    }

    public void addName() {
        String name = uin.getName();
        String gender = uin.getGender();
        String year = uin.getYear();

        while (search.search_name_gender_year(namelist, name, gender, year) >= 0) {
            System.out.println("Baby Name already exist.");
             name = uin.getName();
             gender = uin.getGender();
             year = uin.getYear();
        }

        String count = uin.getCount();
        namelist.add(new BabyName(name, gender, Integer.parseInt(year), 0, Integer.parseInt(count)));
        search.ranking(year, gender, namelist);
        search.write_to_CSV("data/Baby_Names.csv", namelist);
        System.out.println("Successful added a new baby name.");

    }

    public void addName(BabyName babyName) {
//        String name = uin.getName();
//        String gender = uin.getGender();
//        String year = uin.getYear();

//        while (search.search_name_gender_year(namelist, name, gender, year) >= 0) {
//            System.out.println("Baby Name already exist.");
//            name = uin.getName();
//            gender = uin.getGender();
//            year = uin.getYear();
//        }

//        String count = uin.getCount();
        namelist.add(babyName);
//        search.ranking(year, gender, namelist);
        search.write_to_CSV("data/Baby_Names.csv", namelist);
        System.out.println("Testing successful added new baby name");

    }
}
