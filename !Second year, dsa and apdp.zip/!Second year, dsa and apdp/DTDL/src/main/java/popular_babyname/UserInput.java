package popular_babyname;

import java.util.Scanner;

public class UserInput {
    Scanner sc = new Scanner(System.in);
    public String getName()
    {
        System.out.println("Enter baby name: ");
        String input = sc.nextLine();

        if(!input.matches("[A-Z][a-z]{1,20}"))
        {
            System.out.println("Name must be in letter only and at least two characters");
            input = getName();
        }
        return input;
    }
    public String getName(Scanner sc)
    {
        System.out.println("Enter baby name: ");
        String input = sc.nextLine();

        if(!input.matches("[A-Z][a-z]{1,20}"))
        {
            System.out.println("Name must be in letter only and at least two characters");
            input = getName();
        }
        return input;
    }

    public String getGender()
    {
        System.out.println("Enter gender: ");
        String input = sc.nextLine();
        if(!input.matches("[M|F]"))
        {
            System.out.println("Gender must be M or F");
            input = getGender();
        }
        return input;
    }
    public String getGender(Scanner sc)
    {
        System.out.println("Enter gender: ");
        String input = sc.nextLine();
        if(!input.matches("[M|F]"))
        {
            System.out.println("Gender must be M or F");
            input = getGender();
        }
        return input;
    }

    public String getYear()
    {
        System.out.println("Enter year: ");
        String input = sc.nextLine();
        if(!input.matches("[1-9][0-9]{3}"))
        {
            System.out.println("Year must be numerical value with only length 4");
            input = getYear();
        }
        return input;
    }
    public String getYear(Scanner sc)
    {
        System.out.println("Enter year: ");
        String input = sc.nextLine();
        if(!input.matches("[1-9][0-9]{3}"))
        {
            System.out.println("Year must be numerical value with only length 4");
            input = getYear();
        }
        return input;
    }

    public String getCount()
    {
        System.out.println("Enter count: ");
        String input = sc.nextLine();
        if(!input.matches("[1-9][0-9]*"))
        {
            System.out.println("Count must be greater than zero");
            input = getCount();
        }
        return input;
    }
    public String getCount(Scanner sc)
    {
        System.out.println("Enter count: ");
        String input = sc.nextLine();
        if(!input.matches("[1-9][0-9]*"))
        {
            System.out.println("Count must be greater than zero");
            input = getCount();
        }
        return input;
    }


}
