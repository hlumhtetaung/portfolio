package popular_babyname;

import java.util.LinkedList;

public class DeleteByYear {
    LinkedList<BabyName> namelist = new LinkedList<>();
    UserInput uin = new UserInput();
    Search se = new Search();

    public DeleteByYear(LinkedList<BabyName> namelist) {
        this.namelist = namelist;
    }

    public void deleteyear() {
        String year = uin.getYear();
        while(!se.search_year(namelist, year)) {
            System.out.println(year + " doesn't exist to delete.");
            year = uin.getYear();
        }

        LinkedList<BabyName> templist = new LinkedList<>();
        for (BabyName bn : namelist) {
            if (bn.getYear() == Integer.parseInt(year)) {
                templist.add(bn);
            } // end if
        } // end for loop
        namelist.removeAll(templist);
        se.write_to_CSV("data/Baby_Names.csv", namelist);
        System.out.println(year + " deleted successful");
        System.out.println(namelist.size());
    } // end delete year class

    public void deleteyear(String year) {
//        String year = uin.getYear();
        while(!se.search_year(namelist, year)) {
            System.out.println(year + " doesn't exist to delete.");
            year = uin.getYear();
        }

        LinkedList<BabyName> templist = new LinkedList<>();
        for (BabyName bn : namelist) {
            if (bn.getYear() == Integer.parseInt(year)) {
                templist.add(bn);
            } // end if
        } // end for loop
        namelist.removeAll(templist);
        se.write_to_CSV("data/Baby_Names.csv", namelist);
        System.out.println(year + " deleted successful");
        System.out.println(namelist.size());
    } // end delete year class

}
