package popular_babyname;

import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;

import java.util.Arrays;
import java.util.LinkedList;

public class ReportByYear {
    LinkedList<BabyName> namelist = new LinkedList<>();
    UserInput uin = new UserInput();
    Search se = new Search();

    public ReportByYear(LinkedList<BabyName> namelist) {
        this.namelist = namelist;
    } // end of ReportByYear class

    public void report_year() {
        LinkedList<BabyName> malelist = new LinkedList<>();
        LinkedList<BabyName> femalelist = new LinkedList<>();
        String year = uin.getYear();
        if(!se.search_year(namelist, year)) {
            System.out.println(year + " not found.");
            year = uin.getYear();
        }
        for (BabyName bn : namelist) {
            if (bn.getYear() == Integer.parseInt(year)) {
                if (bn.getGender().equals("M")) {
                    malelist.add(bn);
                } // end if
                else femalelist.add(bn);
            } // end if
        } // end for loop

        // start of male table
        System.out.println(year + " Male Baby Name List");
        AsciiTable table = new AsciiTable();
        table.addRule();
        table.addRow(Arrays.asList("Name", "Gender", "Rank", "Count"));
        table.addRule();
        for (BabyName bn : malelist) {
            table.addRow(Arrays.asList(bn.getName(), bn.getGender(), bn.getRank(), bn.getCount()));
            table.addRule();
        } // end for loop
        table.setTextAlignment(TextAlignment.CENTER);
        System.out.println(table.render());

        // start of female table
        System.out.println(year + " Female Baby Name List");
        AsciiTable table1 = new AsciiTable();
        table1.addRule();
        table1.addRow(Arrays.asList("Name", "Gender", "Rank", "Count"));
        table1.addRule();
        for (BabyName bn : femalelist) {
            table1.addRow(Arrays.asList(bn.getName(), bn.getGender(), bn.getRank(), bn.getCount()));
            table1.addRule();
        } // end for loop
        table1.setTextAlignment(TextAlignment.CENTER);
        System.out.println(table1.render());

    } // end report_year class


}
