package popular_babyname;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class BabyName_Main {
    static Scanner sc = new Scanner(System.in);
    static LinkedList<BabyName> namelist = new LinkedList<>();

    public LinkedList<BabyName> dataRead(String filename)
    {
        namelist = new LinkedList<>();
        FileReader fr = null;
        try {

            fr = new FileReader(filename);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        CSVReader cr = new CSVReader(fr);
        String[] str;
        while (true)
        {
            try {
                if (!((str = cr.readNext()) != null)) break;
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (CsvValidationException e) {
                throw new RuntimeException(e);
            }
            namelist.add(new BabyName(str[0], str[1], Integer.parseInt(str[2]),
                                        Integer.parseInt(str[3]), Integer.parseInt(str[4])));
        }

        try {
            cr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            fr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return namelist;
    } // end of dateRead class

    public static void display_menu()
    {
        System.out.println("++++++ 👶Popular baby name program🐣 ++++++");
        System.out.println("➕ 1. Adding one baby name to existing dataset.");
        System.out.println("✔️ 2. Adding raw baby name given in text file to existing dataset. ");
        System.out.println("✍️ 3. Editing one baby name from existing dataset. ");
        System.out.println("❌ 4. Delete one baby name from existing dataset. ");
        System.out.println("⁉️ 5. Deleting baby names from existing dataset by required year. ");
        System.out.println("📃 6. Reporting male and female baby names by required year. ");
        System.out.println("®️ 7. Reporting top 10 male baby names in each year. ");
        System.out.println("🏃‍♀️‍➡️ 8. Exit");
        System.out.println("Choose Menu No ....");
    }

    public static String get_menuno()
    {
        String input = sc.nextLine();
        if(! input.matches("[1-8]"))
        {
            System.out.println("Menu number must be 1 to 8!");
            input = get_menuno();
        }
        return input;
    }

    public static void menu()
    {
        display_menu();
        switch (get_menuno())
        {
            case "1": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                System.out.println(namelist.size());
                AddOneBaby addOneBaby = new AddOneBaby(namelist);
                addOneBaby.addName();
                menu();
                break;
            } // end case

            case "2": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                System.out.println(namelist.size());
                AddRawBabyName arb = new AddRawBabyName(namelist);
                arb.addRawBaby();
                System.out.println(namelist.size());
                menu();
                break;
            } // end case

            case "3": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                System.out.println(namelist.size());
                EditBabyName editBabyName = new EditBabyName(namelist);
                editBabyName.edit();
                menu();
                break;
            } // end case

            case "4": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                System.out.println(namelist.size());
                DeleteBabyNames deletebby = new DeleteBabyNames(namelist);
                deletebby.delete();
                menu();
                break;
            } // end case

            case "5": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                System.out.println(namelist.size());
                DeleteByYear deletebyYear = new DeleteByYear(namelist);
                deletebyYear.deleteyear();
                menu();
                break;
            } // end case

            case "6": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                ReportByYear report = new ReportByYear(namelist);
                report.report_year();
                menu();
                break;
            } // end case

            case "7": {
                namelist = new LinkedList<>();
                BabyName_Main main = new BabyName_Main();
                namelist = main.dataRead("data/Baby_Names.csv");
                ReportByYearCount report = new ReportByYearCount(namelist);
                report.count();
                menu();
                break;
            }
        } // end switch
    } // end menu class

    public static void main(String[] args) {
        System.out.println("Loading...");
        BabyName_Main main = new BabyName_Main();
        namelist = main.dataRead("data/Baby_Names.csv");
        System.out.println(namelist.size());
        menu();
    }
}
