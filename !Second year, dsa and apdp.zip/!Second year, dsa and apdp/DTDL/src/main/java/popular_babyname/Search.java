package popular_babyname;

import com.opencsv.CSVWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class Search {
    public int search_name_gender_year(LinkedList<BabyName> namelist,
                                       String name, String gender, String year)
    {
        int index = 0;
        for (BabyName bn : namelist)
        {
            if(bn.getName().equals(name) && bn.getGender().equals(gender) &&
                    bn.getYear() == Integer.parseInt(year))
            {
                return index;
            }
            index++;
        }
        return -1;
    }

    public boolean search_year(LinkedList<BabyName> namelist, String year)
    {
        for(BabyName bn : namelist)
        {
            if(bn.getYear() == Integer.parseInt(year))
            {
                return true;
            }
        }
        return false;
    }

    public void write_to_CSV(String filename, LinkedList<BabyName> namelist) {
        FileWriter fw = null;
        try {
            fw = new FileWriter(filename, false);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        CSVWriter pw = new CSVWriter(fw);
        for (BabyName bn : namelist) {
            String[] str = {bn.getName(), bn.getGender(),
                    String.valueOf(bn.getYear()), String.valueOf(bn.getRank()),
                    String.valueOf(bn.getCount())};
            pw.writeNext(str);
        } // end for
        try {
            pw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    } // end write_to_CSV class

    public void ranking(String year, String gender, LinkedList<BabyName> namelist) {
        LinkedList<BabyName> templist = new LinkedList<>();
        for (BabyName bn : namelist) {
            if (bn.getGender().equals(gender) && bn.getYear() == Integer.parseInt(year)) {
                templist.add(bn);
            }
        }

        // remove
        namelist.removeAll(templist);
        templist.sort(Collections.reverseOrder(Comparator.comparing(BabyName :: getCount)));
        int rank = 0;
        int tempcount = 0;

        for (BabyName bn : templist) {
            if (bn.getCount() != tempcount) {
                rank++;
            }
            tempcount = bn.getCount();
            bn.setRank(rank);
        }

        templist.sort(Comparator.comparing(BabyName :: getName));
        namelist.addAll(templist);


    }
}
