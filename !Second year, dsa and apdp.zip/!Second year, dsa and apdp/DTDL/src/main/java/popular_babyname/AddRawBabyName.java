package popular_babyname;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class AddRawBabyName {
    LinkedList<BabyName> namelist = new LinkedList<>();
    UserInput uin = new UserInput();
    Search search = new Search();

    public AddRawBabyName(LinkedList<BabyName> namelist) {
        this.namelist = namelist;
    }

    public void addRawBaby() {
        String year = uin.getYear();
        while (search.search_year(namelist, year)) {
            System.out.println("Year already exist.");
            year = uin.getYear();
        }
        LinkedList<BabyName> templist = new LinkedList<>();
        FileReader fr = null;
        try {
            fr = new FileReader("data/yob2022.txt");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        BufferedReader br = new BufferedReader(fr);
        String line;
        String str[];
        while (true) {
            try {
                if (!((line = br.readLine()) != null)) break;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            str = line.split(",");
            templist.add(new BabyName(str[0], str[1], Integer.parseInt(year), 0,
                    Integer.parseInt(year)));
        }

        try {
            br.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        namelist.addAll(templist);
        search.ranking(year, "M", namelist);
        search.ranking(year, "F", namelist);
        search.write_to_CSV("data/Baby_Names.csv", namelist);
        System.out.println("Successfully added raw data.");
    }
}
