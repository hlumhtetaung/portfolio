package popular_babyname;

import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;

import java.util.*;

public class ReportByYearCount {
    LinkedList<BabyName> nameList = new LinkedList<>();

    public ReportByYearCount(LinkedList<BabyName> nameList) {
        this.nameList = nameList;
    }

    public void count() {
        SortedMap<Integer /* year */, Integer /* count */> sm = new TreeMap<>();
        for (BabyName bn : nameList) {
            if (sm.containsKey(bn.getYear())) {
                int count = sm.get(bn.getYear());
                sm.replace(bn.getYear(), count + 1);
            }
            else {
                sm.put(bn.getYear(), 1);
            }
        }
        Set s = sm.entrySet();
        Iterator itr = s.iterator();
        AsciiTable table = new AsciiTable();

        table.addRule();
        table.addRow(Arrays.asList("Year", "Count"));
        table.addRule();
        while (itr.hasNext()) {
            Map.Entry m = (Map.Entry) itr.next();
            table.addRow(m.getKey(), m.getValue());
            table.addRule();
        }
        System.out.println(table.render());
        table.setTextAlignment(TextAlignment.CENTER);
    }
}
