package dataset;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Scanner_DataRead {
    public static void main(String[] args) throws FileNotFoundException {
        File data = new File("data/carsDataset.csv");
        Scanner sc = new Scanner(data);
        try
        {
            sc = new Scanner(data);
        }
        catch (FileNotFoundException e)
        {
            throw new RuntimeException(e);
        }
        while (sc.hasNext())
        {
            System.out.print(sc.next() + " ");
            System.out.println();
        }
        sc.close();
    }
}
