package dataset;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class BufferReader_DataRead {
    public static void main(String[] args) throws IOException {
        ArrayList<Car> cars = new ArrayList<>();

        FileReader fr = new FileReader("data/carsDataset.csv");
        BufferedReader br = new BufferedReader(fr);
        String line;
        String[] str;
        while ((line = br.readLine()) != null)
        {
//            System.out.println(line);
            str = line.split(",");
            cars.add(new Car(Integer.parseInt(str[0]), str[1], str[2], Integer.parseInt(str[3]),
                    Integer.parseInt(str[4]), str[5], str[6], Integer.parseInt(str[7])));
        }
        br.close();
        fr.close();
        for(Car ca : cars)
        {
            System.out.println(ca.toString());
        }
    }
}
