package dataset;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import de.vandermeer.asciitable.AsciiTable;
import de.vandermeer.skb.interfaces.transformers.textformat.TextAlignment;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class OpenCSV_DataRead {
    public static void main(String[] args) throws IOException, CsvValidationException {
        ArrayList<Car> cars = new ArrayList<>();
        FileReader fr = new FileReader("data/carsDataset.csv");
        CSVReader cr = new CSVReader(fr);
        String[] str;
        while((str = cr.readNext()) != null)
        {
            cars.add(new Car(Integer.parseInt(str[0]), str[1], str[2], Integer.parseInt(str[3]),
                    Integer.parseInt(str[4]), str[5], str[6], Integer.parseInt(str[7])));
        }
        fr.close();
        cr.close();
        AsciiTable table = new AsciiTable();
        table.addRule();
        table.addRow(Arrays.asList("ID", "Car Number", "Name", "Model", "Kilometer", "Fuel Type",
                                   "Drive Type", "Price"));
        table.addRule();
        for(Car c : cars)
        {
            table.addRow(Arrays.asList(c.getId(), c.getCarNum(), c.getCarName(), c.getModel(),
                          c.getKilometer(), c.getFuelType(), c.getDriveType(), c.getPrice()));
            table.addRule();
        }
        table.setTextAlignment(TextAlignment.CENTER);
        System.out.println(table.render());
    }
}
