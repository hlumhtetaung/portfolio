package dataset;

public class Car {
    int id;
    String CarNum;
    String CarName;
    int model;
    int kilometer;
    String FuelType;
    String DriveType;
    int price;

    public Car(int id, String carNum, String carName, int model, int kilometer, String fuelType, String driveType, int price) {
        this.id = id;
        CarNum = carNum;
        CarName = carName;
        this.model = model;
        this.kilometer = kilometer;
        FuelType = fuelType;
        DriveType = driveType;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCarNum() {
        return CarNum;
    }

    public void setCarNum(String carNum) {
        CarNum = carNum;
    }

    public String getCarName() {
        return CarName;
    }

    public void setCarName(String carName) {
        CarName = carName;
    }

    public int getModel() {
        return model;
    }

    public void setModel(int model) {
        this.model = model;
    }

    public int getKilometer() {
        return kilometer;
    }

    public void setKilometer(int kilometer) {
        this.kilometer = kilometer;
    }

    public String getFuelType() {
        return FuelType;
    }

    public void setFuelType(String fuelType) {
        FuelType = fuelType;
    }

    public String getDriveType() {
        return DriveType;
    }

    public void setDriveType(String driveType) {
        DriveType = driveType;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", CarNum='" + CarNum + '\'' +
                ", CarName='" + CarName + '\'' +
                ", model=" + model +
                ", kilometer=" + kilometer +
                ", FuelType='" + FuelType + '\'' +
                ", DriveType='" + DriveType + '\'' +
                ", price=" + price +
                '}';
    }
}
