package searching;

import java.util.Arrays;

public class BinarySearch {
    public static void main(String[] args) {
        int[] array = {4,2,5,6,1,7,9,8};
        Arrays.sort(array);
        System.out.println("After sorting: "+Arrays.toString(array));

        int index = Arrays.binarySearch(array, 7);
        if (index >= 0){
            System.out.println("Search data is found at "+index);
        }
        else{
            System.out.println("Search data is not found.");
        }
    }
}
