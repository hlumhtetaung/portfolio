package array;

import java.util.Arrays;

public class CopyArray {
    public static void main(String[] args) {
        int[] a = {10,12,13,14};
        int[] b = new int[3];
        System.arraycopy(a,1, b,1,2);
        System.out.println(Arrays.toString(b));
        int[] c = Arrays.copyOf(a, 8);
        System.out.println(Arrays.toString(c));
        int[] d = new int[5];
        Arrays.fill(d, 7);
        System.out.println(Arrays.toString(d));
    }
}
