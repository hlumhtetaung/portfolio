package array;

import java.util.Scanner;

public class VowelArray {
    public static void main(String[] args) {
        String[] vowels = {"a", "e", "i", "o", "u"};
        boolean isVowel = false;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a character: ");
        String character = sc.nextLine();
        for(String elements : vowels){
            if (elements.equals(character)) {
                isVowel = true;
                break;
            }
        }

        if(isVowel){
            System.out.println(character+" is a vowel.");
        }
        else{
            System.out.println(character+" is not a vowel.");
        }
    }
}
