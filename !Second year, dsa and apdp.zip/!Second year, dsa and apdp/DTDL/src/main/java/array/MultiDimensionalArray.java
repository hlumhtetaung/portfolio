package array;

import java.util.Arrays;

public class MultiDimensionalArray {
    public static void main(String[] args) {
//        int [][] array = new int[3][4];
        int[][] array = {{2,3,4,5}, {6,7,8,9}, {10,11,12,13}};

//        array[2][3] = 69;
//        array[1][2] = 50;
        for (int i=0; i<array.length; i++) {
            for (int j=0; j<array[i].length; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
        array[0][1] = 5;
        int[][] b = array.clone();
        System.out.println(Arrays.deepToString(b));
    }
}