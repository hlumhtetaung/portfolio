package array;

public class IntArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        for (int j : array) {
            System.out.print(j+" ");
        }

        System.out.println();

        for (int i = array.length - 1; i >= 0; i--){
            System.out.print(array[i]+" ");
        }
    }
}