package array;

public class Prices {
    public static void main(String[] args) {
        double sum = 0;
        double[] prices = {2.34, 7.89, 1.34, 2.00, 5.67, 3.14, 5.89, 4.56, 6.7};

        //sum of all prices in the array
        for(int i = 0; i<=prices.length - 1; i++){
            sum += prices[i];
        }
        System.out.print("sum of the prices: ");
        System.out.printf("%.2f",sum);
        System.out.println();

        //Values less than 5
        System.out.print("prices below $5: ");
        for(int i = 0; i<=prices.length - 1; i++){
            if(prices[i] < 5){
                System.out.print(prices[i]+" ");
            }
        }
        System.out.println();

        //average of prices
        double average = 0;
        average = sum/prices.length;
        System.out.print("average for all prices: ");
        System.out.printf("%.2f", average);
        System.out.println();

        //prices that are higher than average
        System.out.print("prices that are above average: ");
        for(int i = 0; i<=prices.length - 1; i++){
            if(prices[i]>average){
                System.out.print(prices[i]+" ");
            }
        }

    }
}
