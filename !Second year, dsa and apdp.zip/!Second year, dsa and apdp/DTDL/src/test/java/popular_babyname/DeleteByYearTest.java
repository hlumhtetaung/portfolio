package popular_babyname;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class DeleteByYearTest {

    LinkedList<BabyName> babyName;
    BabyName_Main main;
    DeleteByYear delete;

    @BeforeEach
    void setUp() {
        babyName = new LinkedList<>();
        main = new BabyName_Main();
        main.dataRead("data/Baby_Names.csv");
        delete = new DeleteByYear(babyName);
    }

    @AfterEach
    void tearDown() {
    }

    @DisplayName("Delete baby name testing")
    @Test
    void deleteyear() {
        delete.deleteyear("1881");
        System.out.println("Delete By Year successful!");
    }
}