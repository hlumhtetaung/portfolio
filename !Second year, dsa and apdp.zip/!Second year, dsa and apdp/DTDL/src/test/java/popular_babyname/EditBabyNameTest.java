package popular_babyname;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class EditBabyNameTest {
    LinkedList<BabyName> nameList;
    BabyName_Main main;
    EditBabyName editBabyName;

    @BeforeEach
    void setUp() {
        nameList = new LinkedList<>();
        main = new BabyName_Main();
        nameList = main.dataRead("data/Baby_Names.csv");
        editBabyName = new EditBabyName(nameList);
    }

    @AfterEach
    void tearDown() {
    }

    @DisplayName("Edit baby name test")
    @Test
    void edit() {
        editBabyName.edit("Anna", "F", "1882", 224);
//        assertEquals();
        System.out.println("Edit testing successful!");
    }
}