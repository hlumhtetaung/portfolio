package popular_babyname;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class AddOneBabyTest {

    LinkedList<BabyName> babyName;
    BabyName_Main main;
    AddOneBaby addOneBaby;

    @BeforeEach
    void setUp() {
        babyName = new LinkedList<>();
        main = new BabyName_Main();
        babyName = main.dataRead("data/Baby_Names.csv");
        addOneBaby = new AddOneBaby(babyName);
    }

    @AfterEach
    void tearDown() {

    }

    @DisplayName("Insert baby name testing")
    @Test
    void addName() {
        BabyName babyName = new BabyName("Aron", "F", 1995, 0, 6);
        addOneBaby.addName(babyName);
    }
}