package popular_babyname;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class UserInputTest {

    UserInput userInput;
    InputStream inputStream;

    @BeforeEach
    void setUp() {
        userInput = new UserInput();
        inputStream = System.in;
    }

    @AfterEach
    void tearDown() {
    }

    @DisplayName("Baby Name Testing!!")
    @Test
    void getName() {
        Scanner sc = new Scanner("Bishop");
        String name = userInput.getName(sc);
        assertEquals("Bishop", name);
        System.out.println("Baby name testing successful!");
    }

    @DisplayName("Gender Testing!!")
    @Test
    void getGender() {
        Scanner sc = new Scanner("M");
        String gender = userInput.getGender(sc);
        assertEquals("M", gender);
        System.out.println("Baby gender testing successful!");
    }

    @DisplayName("Year Testing!!")
    @Test
    void getYear() {
        Scanner sc = new Scanner("1996");
        String year = userInput.getYear(sc);
        assertEquals("1996", year);
        System.out.println("Baby year testing successful!");
    }

    @DisplayName("Count Testing!!")
    @Test
    void getCount() {
        Scanner sc = new Scanner("5");
        String count = userInput.getCount(sc);
        assertEquals("5", count);
        System.out.println("Count testing successful!");
    }
}