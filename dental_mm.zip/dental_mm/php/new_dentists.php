<?php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name         = trim($_POST['name']);
    $title        = trim($_POST['title']);
    $description  = trim($_POST['description']);
    $credentials  = trim($_POST['credentials']);

    $sql = "
      INSERT INTO dentists
        (name, title, description, credentials)
      VALUES
        (:name, :title, :description, :credentials)
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':name'        => $name,
        ':title'       => $title,
        ':description' => $description,
        ':credentials' => $credentials
    ]);

    if ($stmt) {
        echo "<script>alert('Dentist created successfully!');</script>";
    } else {
        echo "<script>alert('Failed to create dentist.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>DentalMM ‑ New Dentist</title>
    <link rel="stylesheet" href="../css/user-management.css" />
    <link rel="stylesheet" href="../css/new_user.css" />
</head>

<body>
    <div class="dashboard-container">
        <aside class="sidebar sidebar-left">
            <h2 class="logo">DentalMM</h2>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">🏠 Dashboard</a></li>
                    <li><a href="user-management.php">👥 Users</a></li>
                    <li class="active"><a href="dentist.php">🧑‍⚕️ Dentists</a></li>
                    <li><a href="services_admin.php">🔍 Services</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="form-container">
                <h2>Add New Dentist</h2>
                <form action="" method="POST">
                    <div class="form-row">
                        <div class="form-field">
                            <label for="name">Name</label>
                            <input id="name" name="name" type="text" required />
                        </div>
                        <div class="form-field">
                            <label for="title">Title</label>
                            <input id="title" name="title" type="text" required />
                        </div>
                    </div>
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                    <label for="credentials">Credentials</label>
                    <textarea id="credentials" name="credentials" rows="3"></textarea>
                    <button type="submit" class="btn btn-primary">Create Dentist</button>
                </form>
            </div>
        </main>
        <aside class="sidebar sidebar-right">
            <h3>Quick Actions</h3>
            <ul>
                <li><a href="new_user.php">➕ New User</a></li>
                <li class="active"><a href="#">➕ New Dentist</a></li>
                <li><a href="new_services.php">➕ New Service</a></li>
            </ul>
        </aside>
    </div>
</body>

</html>