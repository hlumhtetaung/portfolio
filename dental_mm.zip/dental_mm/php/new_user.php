<?php
include 'connect.php';

$user_count        = $conn->query("SELECT COUNT(*) FROM users WHERE role='patient'")->fetchColumn();
$service_count     = $conn->query("SELECT COUNT(*) FROM services")->fetchColumn();
$doctor_count      = $conn->query("SELECT COUNT(*) FROM dentists")->fetchColumn();
$appointment_count = $conn->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$contact_count     = $conn->query("SELECT COUNT(*) FROM contact_us")->fetchColumn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phoneNumber = $_POST['phone_number'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $last_visit = date('Y-m-d H:i:s');
    $role = $_POST['role'];
    $image = $_FILES['image'];

    $sql = "INSERT INTO users (first_name, last_name, age, gender, phone_number, email, password, address, last_visit_date, role, image)
    VALUE (:firstname, :lastname, :age, :gender, :phoneNumber, :email, :password, :address, :last_visit, :role, :image)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':firstname' => $firstName,
        ':lastname' => $lastName,
        ':age' => $age,
        ':gender' => $gender,
        ':phoneNumber' => $phoneNumber,
        ':email' => $email,
        ':password' => $password,
        ':address' => $address,
        ':last_visit' => $last_visit,
        ':role' => $role,
        ':image' => $image['name']
    ]);
    if ($stmt) {
        echo "<script>alert('User created successfully!');</script>";
    } else {
        echo "<script>alert('Failed to create user.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>DentalMM ‑ Add Users</title>
    <link rel="stylesheet" href="../css/user-management.css" />
    <link rel="stylesheet" href="../css/new_user.css">
</head>

<body>
    <div class="dashboard-container">
        <aside class="sidebar sidebar-left">
            <h2 class="logo">DentalMM</h2>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">🏠 Dashboard</a></li>
                    <li><a href="user-management.php">👥 Users</a></li>
                    <li><a href="dentist.php">🧑‍⚕️ Dentists</a></li>
                    <li><a href="services_admin.php">🔍 Services</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <section class="overview">
                <h1>User Management</h1>
                <p>Stats: Patients=<?= $user_count ?> |
                    Services=<?= $service_count ?> |
                    Docs=<?= $doctor_count ?> |
                    Apps=<?= $appointment_count ?> |
                    Contacts=<?= $contact_count ?></p>
            </section>

            <div class="form-container">
                <h2>Create New User</h2>
                <form action="" method="POST" enctype="multipart/form-data">

                    <div class="form-row">
                        <div class="form-field">
                            <label for="first_name">First Name</label>
                            <input id="first_name" name="first_name" type="text" required />
                        </div>
                        <div class="form-field">
                            <label for="last_name">Last Name</label>
                            <input id="last_name" name="last_name" type="text" required />
                        </div>
                    </div>

                    <!-- age + gender row -->
                    <div class="form-row">
                        <div class="form-field">
                            <label for="age">Age</label>
                            <input id="age" name="age" type="number" min="0" required />
                        </div>
                        <div class="form-field">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender" required>
                                <option value="">– Select –</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                    </div>

                    <!-- phone + email row -->
                    <div class="form-row">
                        <div class="form-field">
                            <label for="phone_number">Phone</label>
                            <input id="phone_number" name="phone_number" type="tel"
                                pattern="[0-9\-\+\s$$]*" />
                        </div>
                        <div class="form-field">
                            <label for="email">Email</label>
                            <input id="email" name="email" type="email" required />
                        </div>
                    </div>

                    <!-- full width fields -->
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" required />

                    <label for="role">Role</label>
                    <input id="role" name="role" type="text" value="patient" />

                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="3"></textarea>

                    <label for="image">Profile Picture</label>
                    <input id="image" name="image" type="file" accept="image/*" required>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </main>
        <aside class="sidebar sidebar-right">
            <h3>Quick Actions</h3>
            <ul>
                <li class="active"><a href="#">➕ New User</a></li>
                <li><a href="new_dentists.php">➕ New Dentist</a></li>
                <li><a href="new_services.php">➕ New Service</a></li>
            </ul>
        </aside>
    </div>
</body>

</html>