<?php
require_once 'connect.php';

$stmt = $conn->query("
    SELECT
      service_id,
      name,
      description,
      price
    FROM services
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DentalMM ‑ Service Management</title>
  <link rel="stylesheet" href="../css/user-management.css">
</head>
<body>
  <div class="dashboard-container">

    <!-- LEFT SIDEBAR -->
    <aside class="sidebar sidebar-left">
      <h2 class="logo">DentalMM</h2>
      <nav>
        <ul>
          <li><a href="admin_dashboard.php">🏠 Dashboard</a></li>
          <li><a href="user-management.php">👥 Users</a></li>
          <li><a href="dentist.php">🧑‍⚕️ Dentists</a></li>
          <li class="active"><a href="#">🔍 Services</a></li>
        </ul>
      </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
      <section class="overview">
        <h1>Service Management</h1>
        <p>Listing all the services you offer.</p>
      </section>

      <section class="user-table-section">
        <h2>All Services</h2>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Service ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($stmt->rowCount()): ?>
                <?php foreach ($stmt as $row): ?>
                  <tr>
                    <td data-label="Service ID"><?= htmlspecialchars($row['service_id']) ?></td>
                    <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
                    <td data-label="Description"><?= htmlspecialchars($row['description']) ?></td>
                    <td data-label="Price"><?= htmlspecialchars($row['price']) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="4" style="text-align:center;">No services found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </main>

    <!-- RIGHT SIDEBAR -->
    <aside class="sidebar sidebar-right">
      <h3>Quick Actions</h3>
      <ul>
        <li><a href="new_user.php">➕ New User</a></li>
        <li><a href="new_dentists.php">➕ New Dentist</a></li>
        <li><a href="new_services.php">➕ New Service</a></li>
      </ul>
    </aside>

  </div>

  <?php $conn = null; ?>
</body>
</html>