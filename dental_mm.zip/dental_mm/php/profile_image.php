<?php
session_start();
include "connect.php";

$id = $_SESSION['user_id'] ?? $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("SELECT image FROM users WHERE user_id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && !empty($row['image'])) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->buffer($row['image']) ?: 'image/jpeg';
        header("Content-Type: $mime");
        echo $row['image'];
        exit;
    }
}

// Serve default image
$defaultImagePath = "../images/default-image.webp";
if (file_exists($defaultImagePath)) {
    header("Content-Type: image/webp");
    readfile($defaultImagePath);
} else {
    header("Content-Type: image/png");
    echo base64_decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/wIAAgkBBX7GoY4AAAAASUVORK5CYII=");
}
exit;
