<?php
session_start();
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password)) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
        $stmt->execute([$email, $password]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['firstname'] = $user['first_name'];
            $_SESSION['lastname'] = $user['last_name'];
            $_SESSION['logged_in'] = true;
            if ($user['role'] == 'admin') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: home.php");
            }
        } else {
            $message = "Invalid email or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DentalMM - Login</title>
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
    <header class="header">
        <div class="header-container">
            <div class="logo">
                <h2>DentalMM</h2>
            </div>
            <nav class="nav">
                <a href="home.php">Home</a>
                <a href="services.php">Services</a>
                <a href="dentists_customer.php">Dentists</a>
                <a href="about-us.php">About</a>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="container">
            <div class="login-card">
                <div class="card-header">
                    <h1 class="card-title">Welcome Back</h1>
                    <p class="card-subtitle">Sign in to your DentalMM account</p>
                </div>

                <?php if (!empty($message)) : ?>
                    <div class="error-message" style="color: red; margin-bottom: 10px;">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>


                <form class="login-form" action="#" method="POST">
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="form-options">
                        <label class="checkbox-container">
                            <input type="checkbox" name="remember">
                            <span class="checkmark"></span>
                            Remember me
                        </label>
                        <a href="#" class="forgot-password">Forgot password?</a>
                    </div>

                    <button type="submit" class="login-btn">Sign In</button>
                </form>

                <div class="card-footer">
                    <p>Don't have an account?<a href="sign_up.php" style="text-decoration: none;"> Create an account</a></p>
                </div>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <center>
                        <h3>DentalMM</h3>
                        <p>Your trusted dental management platform</p>
                    </center>
                    <div class="footer-bottom">
                        <p>&copy; <?php echo date('Y'); ?> DentalMM. All rights reserved.</p>
                    </div>
                </div>


            </div>
    </footer>
</body>

</html>