<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'connect.php';
require __DIR__ . '/../PHPMailer-6.10.0/src/Exception.php';
require __DIR__ . '/../PHPMailer-6.10.0/src/PHPMailer.php';
require __DIR__ . '/../PHPMailer-6.10.0/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$uid = (int)$_SESSION['user_id'];
$msg = '';
$appointments_to_pay = [];
$user_email = '';
$user_name = '';

// Fetch user details
try {
    $user_stmt = $conn->prepare("SELECT email, first_name, last_name FROM users WHERE user_id = :uid");
    $user_stmt->execute([':uid' => $uid]);
    $user_data = $user_stmt->fetch(PDO::FETCH_ASSOC);
    if ($user_data) {
        $user_email = $user_data['email'];
        $user_name = htmlspecialchars($user_data['first_name'] . ' ' . $user_data['last_name']);
    } else {
        $msg = "Could not retrieve user details.";
    }
} catch (PDOException $e) {
    $msg = "Database error fetching user: " . $e->getMessage();
}

// Fetch appointments needing payment
try {
    $q = $conn->prepare("
      SELECT
        a.appointment_id, a.appointment_date, a.appointment_time,
        s.name AS service_name, s.price AS service_price,
        d.name AS dentist_name
      FROM appointments a
      JOIN services s ON a.service_id = s.service_id
      JOIN dentists d  ON a.doctor_id  = d.doctor_id
      LEFT JOIN payments p ON a.appointment_id = p.appointment_id
      WHERE a.user_id = :uid AND a.payment_status = 'unpaid' AND p.appointment_id IS NULL
      ORDER BY a.appointment_date, a.appointment_time
    ");
    $q->execute([':uid' => $uid]);
    $appointments_to_pay = $q->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $msg = "Database error fetching appointments: " . $e->getMessage();
}

// Handle Payment Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_appointment_id = isset($_POST['appointment_id']) ? (int)$_POST['appointment_id'] : 0;
    $payment_method = $_POST['payment_method'] ?? '';
    $service_price = 0;
    $selected_appt_details = null;

    foreach ($appointments_to_pay as $appt) {
        if ($appt['appointment_id'] === $selected_appointment_id) {
            $service_price = $appt['service_price'];
            $selected_appt_details = $appt;
            break;
        }
    }

    if ($selected_appointment_id && $service_price > 0 && !empty($payment_method)) {
        $transaction_id = uniqid('txn_');
        $payment_date = date('Y-m-d H:i:s');

        try {
            $insert_payment = $conn->prepare("
                INSERT INTO payments (appointment_id, user_id, payment_date, payment_amount, payment_method)
                VALUES (:appointment_id, :user_id, :payment_date, :payment_amount, :payment_method)
            ");
            $insert_payment->execute([
                ':appointment_id' => $selected_appointment_id,
                ':user_id'        => $uid,
                ':payment_date'   => $payment_date,
                ':payment_amount' => $service_price,
                ':payment_method' => $payment_method,
            ]);

            $update_appt_status = $conn->prepare("
                UPDATE appointments
                   SET payment_status = 'paid',
                       updated_at = NOW()
                 WHERE appointment_id = :appointment_id
                   AND user_id = :user_id
            ");
            $update_appt_status->execute([
                ':appointment_id' => $selected_appointment_id,
                ':user_id'        => $uid
            ]);

            // Send Confirmation Email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'coolapple2691@gmail.com';
                $mail->Password   = 'izru xysg sobs pzyq';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                $mail->setFrom('coolapple2691@gmail.com', 'DentalMM');
                $mail->addAddress($user_email, $user_name);

                $mail->isHTML(true);
                $mail->Subject = 'Payment Confirmation - DentalMM Appointment';
                $mail->Body = "
                    <h3>Thank you for your payment!</h3>
                    <p>Your payment for appointment #{$selected_appointment_id} has been successfully processed.</p>

                    <div style='border:2px dashed #4CAF50; padding:15px; margin:20px 0; border-radius:10px; background-color:#f9fff9;'>
                        <h2 style='color:#4CAF50; text-align:center; margin-top:0;'>🎟 Appointment Voucher</h2>
                        <p style='text-align:center; font-size:14px; color:#555;'>Please present this voucher when you arrive for your appointment.</p>
                        <hr style='border:none; border-top:1px solid #ddd;'>
                        <p><strong>Voucher Code:</strong> <span style='font-size:18px; color:#d35400; font-weight:bold;'>VCHR{$selected_appointment_id}</span></p>
                        <p><strong>Service:</strong> {$selected_appt_details['service_name']}</p>
                        <p><strong>Dentist:</strong> {$selected_appt_details['dentist_name']}</p>
                        <p><strong>Date:</strong> {$selected_appt_details['appointment_date']}</p>
                        <p><strong>Time:</strong> " . substr($selected_appt_details['appointment_time'], 0, 5) . "</p>
                        <p><strong>Amount Paid:</strong> $" . number_format($service_price, 2) . "</p>
                        <hr style='border:none; border-top:1px solid #ddd;'>
                        <p style='text-align:center; font-size:12px; color:#999;'>Valid only for the above date and time.</p>
                    </div>

                    <p>Thank you for choosing DentalMM!</p>
                ";

                $mail->AltBody = "Thank you for your payment! Your payment for appointment #{$selected_appointment_id} has been successfully processed. Amount Paid: $service_price. Transaction ID: {$transaction_id}.";

                $mail->send();
                $msg = "Payment successful! Confirmation email sent to {$user_email}.";
            } catch (Exception $e) {
                $msg = "Payment recorded successfully. However, the confirmation email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } catch (PDOException $e) {
            $msg = "Database error during payment recording: " . $e->getMessage();
        }
    } else {
        if ($selected_appointment_id === 0) $msg = "Please select an appointment to pay for.";
        elseif (empty($payment_method)) $msg = "Please select a payment method.";
        else $msg = "An unexpected error occurred. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Make Payment</title>
    <link rel="stylesheet" href="../css/user-management.css">
    <link rel="stylesheet" href="../css/payment.css">
</head>

<body>
    <header>
        <h1>Make Payment</h1>
        <nav>
            <a href="home.php">Home</a> |
            <a href="user_profile.php">Profile</a> |
            <a href="user_appointments.php">My Appointments</a> |
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <main>
        <?php if ($msg): ?>
            <div class="msg"><?= htmlspecialchars($msg) ?></div>
        <?php endif ?>

        <?php if (!empty($appointments_to_pay)): ?>
            <div class="payment-selection-form">
                <h2>Select Appointment and Method</h2>

                <form action="" method="POST">
                    <div class="appointment-info">
                        <p><strong>Appointments Requiring Payment:</strong></p>
                        <?php foreach ($appointments_to_pay as $appt): ?>
                            <label class="appt-option">
                                <input type="radio" name="appointment_id" value="<?= $appt['appointment_id'] ?>" required
                                    data-price="<?= $appt['service_price'] ?>"
                                    onclick="updatePaymentAmount(<?= $appt['appointment_id'] ?>, <?= $appt['service_price'] ?>)">
                                <span><?= htmlspecialchars($appt['service_name']) ?> with <?= htmlspecialchars($appt['dentist_name']) ?> on <?= $appt['appointment_date'] ?> at <?= substr($appt['appointment_time'], 0, 5) ?> ($<?= number_format($appt['service_price'], 2) ?>)</span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="payment-methods">
                        <p><strong>Choose Payment Method:</strong></p>
                        <label><input type="radio" name="payment_method" value="kpay" required> KPay</label>
                        <label><input type="radio" name="payment_method" value="ayapay" required> AyaPay</label>
                        <label><input type="radio" name="payment_method" value="credit_card" required> Credit Card</label>
                    </div>

                    <div class="form-actions">
                        <p><strong>Amount Due:</strong> <span id="payment_amount_display">\$0.00</span></p>
                        <button type="submit" class="btn btn-primary">Proceed to Payment</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="payment-selection-form no-appointments">
                <h2>No Pending Payments</h2>
                <p>You have no appointments currently requiring payment.</p>
                <div class="form-actions">
                    <a href="user_appointments.php" class="btn btn-primary">View Appointments</a>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <script>
        function updatePaymentAmount(appointmentId, price) {
            document.getElementById('payment_amount_display').textContent = `$${price.toFixed(2)}`;
        }
    </script>
</body>

</html>