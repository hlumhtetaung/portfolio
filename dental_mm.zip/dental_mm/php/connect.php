<?php
$servername = 'localhost';
$dbname = 'dentalmm';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", 
    $username, $password);

    $conn -> setAttribute(PDO::ATTR_ERRMODE, 
    PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    error_log("Database connection failed!" . $e -> getMessage());
    die("Database connection failed. Please check your connect.php and try again.");
}
