<?php
session_start();
include "connect.php";
$sql = "SELECT COUNT(*) FROM users WHERE role = 'patient'";
$result = $conn->query($sql);
$user_count = $result->fetchColumn();

$service_sql = "SELECT COUNT(*) FROM services";
$service_result = $conn->query($service_sql);
$service_count = $service_result->fetchColumn();

$doctor_sql = "SELECT COUNT(*) FROM dentists";
$doctor_result = $conn->query($doctor_sql);
$doctor_count = $doctor_result->fetchColumn();

$appointment_sql = "SELECT COUNT(*) FROM appointments";
$appointment_result = $conn->query($appointment_sql);
$appointment_count = $appointment_result->fetchColumn();

$contact_sql = "SELECT COUNT(*) FROM contact_us";
$contact_result = $conn->query($contact_sql);
$contact_count = $contact_result->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>DentalMM - Admin</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <div class="dashboard-container">
        <aside class="sidebar sidebar-left">
            <h2 class="logo">DentalMM</h2>
            <nav>
                <ul>
                    <li><a href="#" class="active">🏠 Dashboard</a></li>
                    <li><a href="user-management.php">👥 Users</a></li>
                    <li><a href="dentist.php">🧑‍⚕️ Dentists</a></li>
                    <li><a href="services_admin.php">🔍 Services</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <section class="overview">
                <h1>Welcome back, Admin!</h1>
                <p>Here’s a quick overview of your system.</p>

                <div class="stats-grid">
                    <div class="stat-card">
                        <h3>Total Users</h3>
                        <strong><?php echo $user_count; ?></strong>
                    </div>
                    <div class="stat-card">
                        <h3>Total Services</h3>
                        <strong><?php echo $service_count; ?></strong>
                    </div>
                    <div class="stat-card">
                        <h3>Total Doctors</h3>
                        <strong><?php echo $doctor_count; ?></strong>
                    </div>
                    <div class="stat-card">
                        <h3>Total Appointments</h3>
                        <strong><?php echo $appointment_count; ?></strong>
                    </div>
                    <div class="stat-card">
                        <h3>Total Contact Messages</h3>
                        <strong><?php echo $contact_count; ?></strong>
                    </div>
                </div>

                <section class="charts">
                    <h2>Overview Chart</h2>
                    <div class="chart-container">
                        <canvas id="overviewChart"></canvas>
                    </div>
                </section>
            </section>
        </main>

        <aside class="sidebar sidebar-right">
            <h3>Quick Actions</h3>
            <ul>
                <li><a href="new_user.php">➕ New User</a></li>
                <li><a href="new_dentists.php">➕ New Dentist</a></li>
                <li><a href="new_services.php">➕ New Service</a></li>
            </ul>
        </aside>
    </div>

    <script>
        // pull PHP counts into JS
        const dataCounts = [
            <?php echo $user_count; ?>,
            <?php echo $service_count; ?>,
            <?php echo $doctor_count; ?>,
            <?php echo $appointment_count; ?>,
            <?php echo $contact_count; ?>
        ];

        const labels = [
            'Users',
            'Services',
            'Doctors',
            'Appointments',
            'Contacts'
        ];

        const colors = [
            '#52796f',
            '#84a98c',
            '#cad2c5',
            '#f4d35e',
            '#ee964b'
        ];

        const ctx = document.getElementById('overviewChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: dataCounts,
                    backgroundColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>

</body>

</html>