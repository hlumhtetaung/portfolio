<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - DentalMM - Professional Dental Care</title>
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/about-us.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <h2>DentalMM</h2>
            </div>
            <nav class="nav">
                <a href="home.php">Home</a>
                <a href="services.php">Services</a>
                <a href="dentists_customer.php">Dentists</a>
                <a href="#">About</a>
                <a href="appointment.php">Appointment</a>
            </nav>
        </div>
    </header>

    <!-- About Hero Section -->
    <section class="about-hero">
        <div class="container">
            <div class="about-hero-content">
                <h1>About DentalMM</h1>
                <p>Dedicated to providing exceptional dental care with compassion, expertise, and cutting-edge technology for over 15 years.</p>
            </div>
        </div>
    </section>

    <!-- Mission & Vision Section -->
    <section class="mission-vision">
        <div class="container">
            <div class="mission-vision-grid">
                <div class="mission-card">
                    <div class="card-icon">🎯</div>
                    <h3>Our Mission</h3>
                    <p>To provide comprehensive, compassionate dental care that enhances the oral health and overall well-being of our patients while creating beautiful, confident smiles.</p>
                </div>
                <div class="vision-card">
                    <div class="card-icon">👁️</div>
                    <h3>Our Vision</h3>
                    <p>To be the leading dental practice in our community, known for excellence in patient care, innovative treatments, and creating lasting relationships built on trust.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Story Section -->
    <section class="our-story">
        <div class="container">
            <div class="story-content">
                <div class="story-text">
                    <h2>Our Story</h2>
                    <p>Founded in <?php echo date('Y') - 15; ?>, DentalMM began with a simple vision: to provide exceptional dental care in a warm, welcoming environment. What started as a small practice has grown into a comprehensive dental center serving thousands of families in our community.</p>

                    <p>Our journey has been marked by continuous growth, both in our team of skilled professionals and our commitment to staying at the forefront of dental technology and techniques. We believe that every patient deserves personalized care tailored to their unique needs and goals.</p>

                    <p>Today, we're proud to offer a full range of dental services, from routine cleanings to complex restorative procedures, all delivered with the same caring approach that has defined us from the beginning.</p>
                </div>
                <div class="story-image">
                    <img src="../images/Dental-Interior.jpg" alt="DentalMM Office Interior">
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="team-section">
        <div class="container">
            <div class="section-header">
                <h2>Meet Our Team</h2>
                <p>Experienced professionals dedicated to your oral health</p>
            </div>
            <div class="team-grid">
                <div class="team-member">
                    <div class="member-image">
                        <img src="../images/Dr. Hein.jpg" alt="Dr. Hein">
                    </div>
                    <div class="member-info">
                        <h3>Dr. Hein</h3>
                        <p class="member-title">Lead Dentist & Founder</p>
                        <p class="member-description">With over 15 years of experience, Dr. Hein specializes in cosmetic and restorative dentistry. He graduated from the University of Dental Medicine and is committed to continuing education.</p>
                        <div class="member-credentials">
                            <span>DDS, University of Dental Medicine</span>
                            <span>Member, Myanmar Dental Association</span>
                        </div>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="../images/Dr. Pai.jpg" alt="Dr. Pai">
                    </div>
                    <div class="member-info">
                        <h3>Dr. Pai</h3>
                        <p class="member-title">Pediatric Dentist</p>
                        <p class="member-description">Dr. Pai brings warmth and expertise to pediatric dentistry, making dental visits comfortable and fun for children. He has specialized training in child psychology and behavior management.</p>
                        <div class="member-credentials">
                            <span>DDS, Pediatric Specialty</span>
                            <span>Board Certified Pediatric Dentist</span>
                        </div>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="../images/Dr.Dana.jpg" alt="Dana">
                    </div>
                    <div class="member-info">
                        <h3>Dr. Dana</h3>
                        <p class="member-title">Senior Dental Hygienist</p>
                        <p class="member-description">Dr. Dana has been with our practice for 8 years, providing thorough cleanings and patient education. His gentle approach and attention to detail make every visit comfortable.</p>
                        <div class="member-credentials">
                            <span>RDH, Certified Dental Hygienist</span>
                            <span>Local Anesthesia Certified</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="values-section">
        <div class="container">
            <div class="section-header">
                <h2>Our Values</h2>
                <p>The principles that guide everything we do</p>
            </div>
            <div class="values-grid">
                <div class="value-item">
                    <div class="value-icon">❤️</div>
                    <h3>Compassionate Care</h3>
                    <p>We treat every patient with kindness, understanding, and respect, ensuring comfort throughout their dental journey.</p>
                </div>
                <div class="value-item">
                    <div class="value-icon">🔬</div>
                    <h3>Excellence</h3>
                    <p>We maintain the highest standards in dental care, using advanced technology and evidence-based treatments.</p>
                </div>
                <div class="value-item">
                    <div class="value-icon">🤝</div>
                    <h3>Trust</h3>
                    <p>We build lasting relationships with our patients through honest communication and transparent treatment planning.</p>
                </div>
                <div class="value-item">
                    <div class="value-icon">🌟</div>
                    <h3>Innovation</h3>
                    <p>We continuously invest in the latest dental technologies and techniques to provide the best possible outcomes.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Facilities Section -->
    <section class="facilities-section">
        <div class="container">
            <div class="facilities-content">
                <div class="facilities-text">
                    <h2>State-of-the-Art Facilities</h2>
                    <p>Our modern dental office is equipped with the latest technology to ensure accurate diagnoses and comfortable treatments.</p>

                    <div class="facilities-features">
                        <div class="feature-item">
                            <span class="feature-icon">📱</span>
                            <div>
                                <h4>Digital X-Rays</h4>
                                <p>Reduced radiation exposure with instant, high-quality imaging</p>
                            </div>
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon">🖥️</span>
                            <div>
                                <h4>Intraoral Cameras</h4>
                                <p>See what we see with detailed images of your teeth and gums</p>
                            </div>
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon">💺</span>
                            <div>
                                <h4>Comfort Amenities</h4>
                                <p>Relaxing environment with entertainment options and comfort features</p>
                            </div>
                        </div>
                        <div class="feature-item">
                            <span class="feature-icon">🧼</span>
                            <div>
                                <h4>Advanced Sterilization</h4>
                                <p>Hospital-grade sterilization protocols for your safety and peace of mind</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="facilities-image">
                    <img src="../images/dental-equipments.webp" alt="Modern Dental Equipment">
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="about-cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Experience the DentalMM Difference?</h2>
                <p>Schedule your consultation today and discover why thousands of patients trust us with their smiles.</p>
                <div class="cta-buttons">
                    <a href="#appointment" class="btn-primary">Make Appointment</a>
                    <a href="services.php" class="btn-outline">View Dental Services</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <h3>DentalMM</h3>
                    <p>Professional dental care you can trust</p>
                </div>
                <div class="footer-links">
                    <a href="home.php">Home</a>
                    <a href="services.php">Services</a>
                    <a href="dentists_customer.php">Dentists</a>
                    <a href="#">About</a>
                    <a href="appointment.php">Appointment</a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> DentalMM. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Add scroll effect to header
        window.addEventListener('scroll', function() {
            const header = document.querySelector('.header');
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>
</body>

</html>