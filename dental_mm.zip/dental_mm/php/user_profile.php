<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include 'connect.php';

$user_id = $_SESSION['user_id'];
$updated = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $age        = (int) $_POST['age'];
    $gender     = $_POST['gender'];
    $phone      = trim($_POST['phone_number']);
    $email      = trim($_POST['email']);
    $address    = trim($_POST['address']);

    $params = [
        ':first_name' => $first_name,
        ':last_name'  => $last_name,
        ':age'        => $age,
        ':gender'     => $gender,
        ':phone'      => $phone,
        ':email'      => $email,
        ':address'    => $address,
        ':user_id'    => $user_id
    ];

    $sql_pw = '';
    if (!empty($_POST['password'])) {
        $sql_pw = ", password = :password";
        $params[':password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
    }

    $sql_img = '';
    if (!empty($_FILES['image']['tmp_name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $sql_img = ", image = :image";
        $params[':image'] = file_get_contents($_FILES['image']['tmp_name']);
    }

    $sql = "
      UPDATE users SET
        first_name   = :first_name,
        last_name    = :last_name,
        age          = :age,
        gender       = :gender,
        phone_number = :phone,
        email        = :email,
        address      = :address
        {$sql_pw}
        {$sql_img},
        last_visit_date = NOW()
      WHERE user_id = :user_id
    ";

    $stmt = $conn->prepare($sql);
    if ($stmt->execute($params)) {
        $updated = true;
    }
}

$stmt = $conn->prepare("
  SELECT first_name, last_name, age, gender,
         phone_number, email, address, image
  FROM users
  WHERE user_id = :id
");
$stmt->execute([':id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$image_src = $user['image']
    ? 'data:image/jpeg;base64,' . base64_encode($user['image'])
    : 'https://via.placeholder.com/120';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <link rel="stylesheet" href="../css/user_profile.css">
</head>

<body>
    <header>
        <h1>My Profile</h1>
        <nav>
            <a href="home.php">Home</a> |
            <a href="user_appointments.php">My Appointments</a> |
            <a href="payment.php">Payment</a> |
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <main>
        <?php if ($updated): ?>
            <div class="msg">Profile updated successfully.</div>
        <?php endif; ?>
        <div class="form-container">
            <h2>Edit Profile</h2>
            <img src="<?= $image_src ?>" alt="Profile Picture">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-field">
                        <label for="first_name">First Name</label>
                        <input id="first_name" name="first_name" type="text"
                            value="<?= htmlspecialchars($user['first_name']) ?>" required>
                    </div>
                    <div class="form-field">
                        <label for="last_name">Last Name</label>
                        <input id="last_name" name="last_name" type="text"
                            value="<?= htmlspecialchars($user['last_name']) ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-field">
                        <label for="age">Age</label>
                        <input id="age" name="age" type="number" min="0"
                            value="<?= htmlspecialchars($user['age']) ?>" required>
                    </div>
                    <div class="form-field">
                        <label for="gender">Gender</label>
                        <select id="gender" name="gender" required>
                            <option value="">– Select –</option>
                            <option value="male" <?= $user['gender'] == 'male'   ? 'selected' : '' ?>>Male</option>
                            <option value="female" <?= $user['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
                            <option value="other" <?= $user['gender'] == 'other'  ? 'selected' : '' ?>>Other</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-field">
                        <label for="phone_number">Phone</label>
                        <input id="phone_number" name="phone_number" type="tel"
                            pattern="[0-9\-\+\s$$]*"
                            value="<?= htmlspecialchars($user['phone_number']) ?>">
                    </div>
                    <div class="form-field">
                        <label for="email">Email</label>
                        <input id="email" name="email" type="email"
                            value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                </div>
                <label for="password">New Password
                    <small>(leave blank to keep current)</small>
                </label>
                <input id="password" name="password" type="password">
                <label for="address">Address</label>
                <textarea id="address" name="address" rows="3"><?= htmlspecialchars($user['address']) ?></textarea>
                <label for="image">Change Profile Picture</label>
                <input id="image" name="image" type="file" accept="image/*">
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
        </div>
    </main>
</body>

</html>