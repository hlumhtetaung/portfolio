<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include 'connect.php';
$uid = (int)$_SESSION['user_id'];
$msg = '';

// Cancel
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['cancel_id'])) {
    $aid = (int)$_POST['cancel_id'];
    $del = $conn->prepare("
    DELETE FROM appointments
     WHERE appointment_id = :aid
       AND user_id = :uid
  ");
    if ($del->execute([':aid' => $aid, ':uid' => $uid])) {
        echo "<script>
            alert('Appointment #{$aid} cancelled successfully.');
            window.location.href = 'user_appointments.php';
        </script>";
    } else {
        $error_info = $del->errorInfo();
        echo "<script>
            alert('Error cancelling appointment: " . addslashes($error_info[2]) . "');
            window.location.href = 'user_appointments.php';
        </script>";
    }
}

// Change date/time
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && !empty($_POST['change_id'])
    && !empty($_POST['new_date'])
    && !empty($_POST['new_time'])
) {
    $aid = (int)$_POST['change_id'];
    $date = $_POST['new_date'];   // YYYY-MM-DD
    $time = $_POST['new_time'];   // HH:MM
    $upd = $conn->prepare("
    UPDATE appointments
       SET appointment_date = :d,
           appointment_time = :t,
           updated_at = NOW()
     WHERE appointment_id = :aid
       AND user_id = :uid
  ");
    if ($upd->execute([
        ':d' => $date,
        ':t' => $time . ':00',
        ':aid' => $aid,
        ':uid' => $uid
    ])) {
        echo "<script>
            alert('Appointment #{$aid} changed successfully.');
            window.location.href = 'user_appointments.php';
        </script>";
    } else {
        $error_info = $upd->errorInfo();
        echo "<script>
            alert('Error changing appointment: " . addslashes($error_info[2]) . "');
            window.location.href = 'user_appointments.php';
        </script>";
    }
}

// fetch
$q = $conn->prepare("
  SELECT
    a.appointment_id,
    a.appointment_date,
    a.appointment_time,
    a.status,
    a.notes,
    a.payment_status,
    s.name AS service,
    d.name AS dentist
  FROM appointments a
  LEFT JOIN services s ON a.service_id = s.service_id
  LEFT JOIN dentists d  ON a.doctor_id  = d.doctor_id
  WHERE a.user_id = :uid
  ORDER BY a.appointment_date, a.appointment_time
");
$q->execute([':uid' => $uid]);
$appts = $q->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Appointments</title>
    <link rel="stylesheet" href="../css/user-management.css">
    <link rel="stylesheet" href="../css/new_user.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            flex-shrink: 0;
        }

        main {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .change-form,
        .cancel-form {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .change-form input[type="date"],
        .change-form input[type="time"],
        .cancel-form button,
        .change-form button {
            padding: 0.4rem 0.7rem;
            font-size: 0.85rem;
        }

        .change-form input {
            min-width: 120px;
        }

        .navbar a {
            text-decoration: none;
        }

        .change-form button {
            margin-bottom: 25px;
        }

        .cancel-form button {
            margin-bottom: 25px;
        }
    </style>
</head>

<body>
    <header style="background: #52796f; color:#fff; padding:1rem; text-align:center;">
        <h1>My Appointments</h1>
        <nav class="navbar">
            <a href="home.php" style="color:#fff; margin:0 .5rem;">Home</a> |
            <a href="user_profile.php" style="color:#fff; margin:0 .5rem;">Profile</a> |
            <a href="payment.php" style="color:#fff; margin:0 .5rem;">Payment</a> |
            <a href="logout.php" style="color:#fff; margin:0 .5rem;">Logout</a>
        </nav>
    </header>

    <main>
        <?php if ($msg): ?>
            <div class="msg"><?= htmlspecialchars($msg) ?></div>
        <?php endif ?>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Service</th>
                        <th>Dentist</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Notes</th>
                        <th>Change</th>
                        <th>Cancel</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($appts)): ?>
                        <?php foreach ($appts as $r): ?>
                            <tr>
                                <td data-label="ID"><?= $r['appointment_id'] ?></td>
                                <td data-label="Date"><?= htmlspecialchars($r['appointment_date']) ?></td>
                                <td data-label="Time"><?= htmlspecialchars(substr($r['appointment_time'], 0, 5)) ?></td>
                                <td data-label="Service"><?= htmlspecialchars($r['service']) ?></td>
                                <td data-label="Dentist"><?= htmlspecialchars($r['dentist']) ?></td>
                                <td data-label="Status"><?= htmlspecialchars($r['status']) ?></td>
                                <td data-label="Payment"><?= htmlspecialchars($r['payment_status']) ?></td>
                                <td data-label="Notes"><?= htmlspecialchars($r['notes']) ?></td>

                                <td data-label="Change">
                                    <form method="POST" class="change-form">
                                        <input type="hidden" name="change_id" value="<?= $r['appointment_id'] ?>">
                                        <input type="date" name="new_date" value="<?= $r['appointment_date'] ?>" required>
                                        <input type="time" name="new_time" value="<?= substr($r['appointment_time'], 0, 5) ?>" required>
                                        <button type="submit" class="btn btn-primary" class="change">
                                            Change
                                        </button>
                                    </form>
                                </td>

                                <td data-label="Cancel">
                                    <form method="POST" class="cancel-form">
                                        <input type="hidden" name="cancel_id" value="<?= $r['appointment_id'] ?>">
                                        <button type="submit" class="btn btn-danger" class="cancel">
                                            Cancel
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" style="text-align:center;">No appointments found.</td>
                        </tr>
                    <?php endif ?>
                </tbody>
            </table>
        </div>
    </main>
</body>

</html>