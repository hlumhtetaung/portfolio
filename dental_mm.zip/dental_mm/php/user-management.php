<?php
require_once 'connect.php';

// stats
$user_count        = $conn->query("SELECT COUNT(*) FROM users WHERE role='patient'")->fetchColumn();
$service_count     = $conn->query("SELECT COUNT(*) FROM services")->fetchColumn();
$doctor_count      = $conn->query("SELECT COUNT(*) FROM dentists")->fetchColumn();
$appointment_count = $conn->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$contact_count     = $conn->query("SELECT COUNT(*) FROM contact_us")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>DentalMM ‑ User Management</title>
    <link rel="stylesheet" href="../css/user-management.css">
</head>

<body>

    <div class="dashboard-container">

        <!-- LEFT SIDEBAR -->
        <aside class="sidebar sidebar-left">
            <h2 class="logo">DentalMM</h2>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">🏠 Dashboard</a></li>
                    <li class="active"><a href="#">👥 Users</a></li>
                    <li><a href="dentist.php">🧑‍⚕️ Dentists</a></li>
                    <li><a href="services_admin.php">🔍 Services</a></li>
                </ul>
            </nav>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">
            <section class="overview">
                <h1>User Management</h1>
                <p>Stats: Patients=<?= $user_count ?> |
                    Services=<?= $service_count ?> |
                    Docs=<?= $doctor_count ?> |
                    Apps=<?= $appointment_count ?> |
                    Contacts=<?= $contact_count ?></p>
            </section>

            <section class="user-table-section">
                <h2>System Users</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $conn->query(
                                "SELECT user_id,
                    CONCAT(first_name,' ',last_name) AS name,
                    email, role
             FROM users"
                            );

                            if ($stmt->rowCount()):
                                foreach ($stmt as $row):
                                    $uid = htmlspecialchars($row['user_id']);
                            ?>
                                    <tr>
                                        <td data-label="ID"><?= $uid ?></td>
                                        <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
                                        <td data-label="Email"><?= htmlspecialchars($row['email']) ?></td>
                                        <td data-label="Role">
                                            <select class="role-select" data-uid="<?= $uid ?>">
                                                <option value="patient" <?= $row['role'] === 'patient' ? 'selected' : '' ?>>Patient</option>
                                                <option value="admin" <?= $row['role'] === 'admin'  ? 'selected' : '' ?>>Admin</option>
                                            </select>
                                        </td>
                                        <td data-label="Actions">
                                            <button class="update-role-btn" data-uid="<?= $uid ?>">Update</button>
                                            <button class="delete-user-btn" data-uid="<?= $uid ?>">Delete</button>
                                        </td>
                                    </tr>
                                <?php
                                endforeach;
                            else:
                                ?>
                                <tr>
                                    <td colspan="5" style="text-align:center;">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <!-- RIGHT SIDEBAR -->
        <aside class="sidebar sidebar-right">
            <h3>Quick Actions</h3>
            <ul>
                <li><a href="new_user.php">➕ New User</a></li>
                <li><a href="new_dentists.php">➕ New Dentist</a></li>
                <li><a href="new_services.php">➕ New Service</a></li>
            </ul>
        </aside>

    </div>

    <?php $conn = null; ?>

    <script>
        function postJson(url, data) {
            return fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            }).then(r => r.json());
        }

        document.querySelectorAll('.update-role-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const uid = btn.dataset.uid;
                const sel = document.querySelector(`.role-select[data-uid='${uid}']`);
                postJson('update_role.php', {
                        user_id: uid,
                        new_role: sel.value
                    })
                    .then(r => {
                        if (r.success) alert('Role updated');
                        else alert('Error: ' + r.error);
                    });
            });
        });

        document.querySelectorAll('.delete-user-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const uid = btn.dataset.uid;
                if (!confirm('Delete user #' + uid + '?')) return;
                postJson('delete_user.php', {
                        user_id: uid
                    })
                    .then(r => {
                        if (r.success) location.reload();
                        else alert('Error: ' + r.error);
                    });
            });
        });
    </script>

</body>

</html>