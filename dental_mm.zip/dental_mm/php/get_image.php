<?php
require_once 'connect.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $service_id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT image FROM services WHERE service_id = :service_id");
    $stmt->bindValue(':service_id', $service_id, PDO::PARAM_INT);
    $stmt->execute();

    $imageData = $stmt->fetchColumn();

    if ($imageData !== false) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $finfo->buffer($imageData);

        if ($mime_type === false) {
            header("Content-Type: application/octet-stream");
            echo $imageData;
        } else {
            header("Content-Type: " . $mime_type);
            echo $imageData;
        }
    } else {
        header("HTTP/1.0 404 Not Found");
        echo "Image not found.";
    }
    $stmt = null;
} else {
    header("HTTP/1.0 400 Bad Request");
    echo "Service ID not provided.";
}

?>