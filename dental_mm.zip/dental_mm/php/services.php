<?php
session_start();
include 'connect.php';

$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$msg = '';
$services = [];

try {
    $sql = "SELECT service_id, name, description, price, image FROM services";
    $params = [];

    if (!empty($search_term)) {
        $sql .= " WHERE name LIKE :search OR description LIKE :search";
        $params = [':search' => '%' . $search_term . '%'];
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $msg = "Database error: " . $e->getMessage();
} finally {
    $conn = null;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DentalMM - Our Services</title>
    <link rel="stylesheet" href="../css/services.css">
</head>

<body>
    <header class="site-header">
        <div class="header-container">
            <div class="site-branding">
                <span class="logo">
                    <h2>DentalMM</h2>
                </span>
            </div>
            <nav class="site-nav">
                <a href="home.php">Home</a>
                <a href="#">Services</a>
                <a href="#dentists">Dentists</a>
                <a href="about-us.php">About</a>
                <a href="appointment.php">Appointment</a>
            </nav>
        </div>
    </header>

    <main class="content-area">
        <div class="container">
            <h1>Our Services</h1>

            <div class="search-container">
                <form action="" method="GET">
                    <input type="text" name="search" placeholder="Search for services..." value="<?= htmlspecialchars($search_term) ?>">
                    <button type="submit">Search</button>
                </form>
            </div>

            <?php if ($msg): ?>
                <p class="error-message"><?= $msg ?></p>
            <?php endif; ?>

            <div class="card-grid">
                <?php if (count($services) > 0): ?>
                    <?php foreach ($services as $row): ?>
                        <div class="service-card">
                            <?php
                            if (!empty($row['image'])) {
                                echo '<img src="get_image.php?id=' . urlencode($row['service_id']) . '" alt="' . htmlspecialchars($row['name']) . '">';
                            } else {
                                echo '<img src="https://via.placeholder.com/280x180?text=No+Image" alt="No Image Available">';
                            }
                            ?>
                            <h2><?= htmlspecialchars($row['name']) ?></h2>
                            <p class="description"><?= htmlspecialchars($row['description']) ?></p>
                            <p class="price">$<?= htmlspecialchars(number_format($row['price'], 2)) ?></p>
                            <button class="book-now" onclick="window.location.href='appointment.php?service_id=<?= urlencode($row['service_id']) ?>'">Book Now</button>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-results">No services found<?= !empty($search_term) ? ' matching your search criteria' : '' ?>.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> DentalMM. All rights reserved.</p>
        </div>
    </footer>

</body>

</html>