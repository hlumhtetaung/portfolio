<?php
require_once 'connect.php';

$stmt = $conn->query("
    SELECT 
      doctor_id,
      name,
      title,
      description,
      credentials
    FROM dentists
");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>DentalMM ‑ Dentist Management</title>
    <link rel="stylesheet" href="../css/user-management.css"><!-- uses same CSS -->
</head>

<body>
    <div class="dashboard-container">

        <!-- LEFT SIDEBAR -->
        <aside class="sidebar sidebar-left">
            <h2 class="logo">DentalMM</h2>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">🏠 Dashboard</a></li>
                    <li><a href="user-management.php">👥 Users</a></li>
                    <li class="active"><a href="#">🧑‍⚕️ Dentists</a></li>
                    <li><a href="services_admin.php">🔍 Services</a></li>
                </ul>
            </nav>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">
            <section class="overview">
                <h1>Dentist Management</h1>
                <p>Showing all registered dentists in the system.</p>
            </section>

            <section class="user-table-section">
                <h2>All Dentists</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Doctor ID</th>
                                <th>Name</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Credentials</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($stmt->rowCount()): ?>
                                <?php foreach ($stmt as $row): ?>
                                    <tr>
                                        <td data-label="Doctor ID"><?= htmlspecialchars($row['doctor_id']) ?></td>
                                        <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
                                        <td data-label="Title"><?= htmlspecialchars($row['title']) ?></td>
                                        <td data-label="Description"><?= htmlspecialchars($row['description']) ?></td>
                                        <td data-label="Credentials"><?= htmlspecialchars($row['credentials']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" style="text-align:center;">No dentists found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <!-- RIGHT SIDEBAR -->
        <aside class="sidebar sidebar-right">
            <h3>Quick Actions</h3>
            <ul>
                <li><a href="new_user.php">➕ New User</a></li>
                <li><a href="new_dentists.php">➕ New Dentist</a></li>
                <li><a href="new_services.php">➕ New Service</a></li>
            </ul>
        </aside>

    </div>

    <?php $conn = null; ?>
</body>

</html>