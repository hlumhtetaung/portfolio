<?php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price       = (float) $_POST['price'];
    $doctor_id   = (int) $_POST['doctor_id'];
    $imageData   = null;
    if (!empty($_FILES['image']['tmp_name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageData = file_get_contents($_FILES['image']['tmp_name']);
    }

    $sql = "
      INSERT INTO services
        (name, description, price, doctor_id, image)
      VALUES
        (:name, :description, :price, :doctor_id, :image)
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':name',        $name);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':price',       $price);
    $stmt->bindParam(':doctor_id',   $doctor_id, PDO::PARAM_INT);
    $stmt->bindParam(':image',       $imageData, PDO::PARAM_LOB);
    if ($stmt->execute()) {
        echo "<script>alert('Service created successfully!');</script>";
    } else {
        echo "<script>alert('Failed to create service.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>DentalMM ‑ New Service</title>
    <link rel="stylesheet" href="../css/user-management.css" />
    <link rel="stylesheet" href="../css/new_user.css" />
</head>

<body>
    <div class="dashboard-container">
        <aside class="sidebar sidebar-left">
            <h2 class="logo">DentalMM</h2>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">🏠 Dashboard</a></li>
                    <li><a href="user-management.php">👥 Users</a></li>
                    <li><a href="dentist.php">🧑‍⚕️ Dentists</a></li>
                    <li class="active"><a href="services_admin.php">🔍 Services</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="form-container">
                <h2>Add New Service</h2>
                <form action="" method="POST" enctype="multipart/form-data">
                    <label for="name">Service Name</label>
                    <input id="name" name="name" type="text" required />
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                    <div class="form-row">
                        <div class="form-field">
                            <label for="price">Price</label>
                            <input id="price" name="price" type="number" step="0.01" required />
                        </div>
                        <div class="form-field">
                            <label for="doctor_id">Dentist ID</label>
                            <input id="doctor_id" name="doctor_id" type="number" required />
                        </div>
                    </div>
                    <label for="image">Image</label>
                    <input id="image" name="image" type="file" accept="image/*" />
                    <button type="submit" class="btn btn-primary">Create Service</button>
                </form>
            </div>
        </main>
        <aside class="sidebar sidebar-right">
            <h3>Quick Actions</h3>
            <ul>
                <li><a href="new_user.php">➕ New User</a></li>
                <li><a href="new_dentists.php">➕ New Dentist</a></li>
                <li class="active"><a href="#">➕ New Service</a></li>
            </ul>
        </aside>
    </div>
</body>

</html>