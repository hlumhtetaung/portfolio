<?php
session_start();
include "connect.php";

$services_list = [];
try {
    $stmt = $conn->query("SELECT service_id, name FROM services");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $services_list[$row['service_id']] = $row['name'];
    }
} catch (PDOException $e) {
    echo "Error fetching services.";
    exit;
}

$dentists_list = [];
$doctor_options_js = [];
try {
    $stmt = $conn->query("SELECT doctor_id, name FROM dentists");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $dentists_list[$row['doctor_id']] = $row['name'];
        $doctor_options_js[$row['doctor_id']] = $row['name'];
    }
} catch (PDOException $e) {
    echo "Error fetching dentists.";
    exit;
}

$service_doctor_mapping_php = [];
foreach ($services_list as $sid => $sname) {
    switch ($sid) {
        case 1:
            $list = [1, 10, 14];
            break;
        case 2:
            $list = [1, 5, 10];
            break;
        case 3:
            $list = [1, 5, 10, 14];
            break;
        case 4:
            $list = [6, 10];
            break;
        case 5:
            $list = [9, 1, 8];
            break;
        case 6:
            $list = [9, 10];
            break;
        case 7:
            $list = [8, 1];
            break;
        case 8:
            $list = [12, 10, 1];
            break;
        case 9:
            $list = [8, 5];
            break;
        case 10:
            $list = [4, 1];
            break;
        case 11:
            $list = [2, 11, 1];
            break;
        case 12:
            $list = [7, 10];
            break;
        case 13:
            $list = [5, 1, 14];
            break;
        case 14:
            $list = [10, 1, 14];
            break;
        case 15:
            $list = [9, 5];
            break;
        case 16:
            $list = [14, 10];
            break;
        case 17:
            $list = [13, 10];
            break;
        case 18:
            $list = [15, 10];
            break;
        case 19:
            $list = [3, 10];
            break;
        case 20:
            $list = [3, 10, 14];
            break;
        default:
            $list = [1, 10];
            break;
    }
    // filter out any missing dentist IDs
    $service_doctor_mapping_php[$sid] = array_values(
        array_filter($list, fn($d) => isset($dentists_list[$d]))
    );
}

// Booking handler
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    echo "<script>alert('Please log in to book.'); window.location='login.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve & validate
    $service_id = (int)($_POST['service'] ?? 0);
    $doctor_id  = (int)($_POST['doctor'] ?? 0);
    $date       = $_POST['date']    ?? '';
    $time       = $_POST['time']    ?? '';
    $note       = trim($_POST['note'] ?? '');

    if (
        !isset($services_list[$service_id]) ||
        !isset($dentists_list[$doctor_id]) ||
        !in_array($doctor_id, $service_doctor_mapping_php[$service_id] ?? [], true)
    ) {
        echo "Invalid service or doctor.";
        exit;
    }

    // Business hours check: 08:00–16:00
    if ($time < '08:00' || $time > '16:00') {
        echo "Please choose a time between 08:00 and 16:00.";
        exit;
    }

    // Prepare insert
    $user_id = $_SESSION['user_id'];
    $status          = 'queued';
    $payment_status  = 'unpaid';
    $created_at      = date("Y-m-d H:i:s");
    $updated_at      = $created_at;

    $sql = $conn->prepare("
        INSERT INTO appointments
        (user_id, service_id, doctor_id, appointment_date, appointment_time,
         status, notes, payment_status, created_at, updated_at)
        VALUES
        (:user_id, :service_id, :doctor_id, :date, :time,
         :status, :note, :payment_status, :created_at, :updated_at)
    ");

    try {
        $sql->execute([
            ':user_id'        => $user_id,
            ':service_id'     => $service_id,
            ':doctor_id'      => $doctor_id,
            ':date'           => $date,
            ':time'           => $time,
            ':status'         => $status,
            ':note'           => $note,
            ':payment_status' => $payment_status,
            ':created_at'     => $created_at,
            ':updated_at'     => $updated_at,
        ]);

        $_SESSION['appointment_id'] = $conn->lastInsertId();
        header("Location: thank_you.php");
        exit;
    } catch (PDOException $e) {
        error_log("Booking error: " . $e->getMessage());
        echo "An error occurred. Please try again.";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="../css/appointment.css">
    <title>DentalMM - Book Appointment</title>
</head>

<body>
    <header class="header">
        <div class="header-container">
            <h2 class="logo">DentalMM</h2>
            <nav class="nav">
                <a href="home.php">Home</a>
                <a href="services.php">Services</a>
                <a href="dentists_customer.php">Dentists</a>
                <a href="about-us.php">About</a>
            </nav>
        </div>
    </header>

    <div class="appointment-page-container">
        <main class="appointment-form">
            <h1>Make an Appointment</h1>
            <form method="POST" action="appointment.php">

                <div class="form-group full-width-group">
                    <div class="input-wrapper">
                        <label for="service">Service:</label>
                        <select id="service" name="service" required>
                            <option value="" disabled selected>-- Select a Service --</option>
                            <?php foreach ($services_list as $id => $nm): ?>
                                <option value="<?= htmlspecialchars($id) ?>"><?= htmlspecialchars($nm) ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>

                    <div class="input-wrapper">
                        <label for="doctor">Dentist:</label>
                        <select id="doctor" name="doctor" required>
                            <option value="" disabled selected>-- Select a Doctor --</option>
                        </select>
                    </div>
                </div>

                <div class="form-group date-time-group">
                    <div class="input-wrapper">
                        <label for="date">Preferred Date:</label>
                        <input type="date" id="date" name="date" required>
                    </div>

                    <div class="input-wrapper">
                        <label for="time">Preferred Time:</label>
                        <input
                            type="time"
                            id="time"
                            name="time"
                            min="08:00"
                            max="16:00"
                            required>
                        <small>Available slots: 08:00 – 16:00</small>
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-wrapper">
                        <label for="note">Additional Notes:</label>
                        <textarea id="note" name="note" rows="4"
                            placeholder="Any specific requests or concerns"></textarea>
                    </div>
                </div>

                <button type="submit">Book Appointment</button>
            </form>
        </main>

        <aside class="doctor-info">
            <h2>Why DentalMM Doctors?</h2>
            <p><strong>Friendly & Approachable:</strong> Our Doctors are very friendly.</p>
            <p><strong>Highly Experienced:</strong> Over 10+ years in experience.</p>
            <p><strong>Patient-Centered Care:</strong> Every efforts to satisfy patients.</p>
        </aside>
    </div>

    <footer class="site-footer">
        <div class="footer-container">
            <center>
                <h3>DentalMM</h3>
                <p>Your trusted dental management platform</p>
                <p>&copy; <?= date('Y') ?> DentalMM. All rights reserved.</p>
            </center>
        </div>
    </footer>

    <script>
        // Service→Doctor dropdown logic
        const mapping = <?= json_encode($service_doctor_mapping_php) ?>;
        const docs = <?= json_encode($doctor_options_js) ?>;
        const svcSel = document.getElementById('service');
        const docSel = document.getElementById('doctor');

        svcSel.addEventListener('change', () => {
            const allowed = mapping[svcSel.value] || [];
            docSel.innerHTML = '<option value="" disabled selected>-- Select a Doctor --</option>';
            allowed.forEach(id => {
                if (docs[id]) {
                    let opt = document.createElement('option');
                    opt.value = id;
                    opt.text = docs[id];
                    docSel.appendChild(opt);
                }
            });
        });

        // Instant time-range feedback
        const timeInput = document.getElementById('time');
        const minTime = "08:00",
            maxTime = "16:00";
        timeInput.addEventListener('input', function() {
            if (this.value < minTime || this.value > maxTime) {
                this.setCustomValidity('Please pick between 08:00 and 16:00.');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>

</html>