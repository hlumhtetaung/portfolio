<?php
require_once 'connect.php';
header('Content-Type: application/json');

$in = json_decode(file_get_contents('php://input'), true);
$user_id = $in['user_id'] ?? null;

if (!$user_id) {
  echo json_encode(['success' => false, 'error' => 'No user_id provided']);
  exit;
}

// 1) Find out if this user is an admin
$stmt = $conn->prepare("SELECT role FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
  echo json_encode(['success' => false, 'error' => 'User not found']);
  exit;
}

if ($row['role'] === 'admin') {
  // 2) Count how many admins remain
  $adminCount = (int)$conn
    ->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")
    ->fetchColumn();

  // 3) If this is the last admin, block the delete
  if ($adminCount <= 1) {
    echo json_encode([
      'success' => false,
      'error'   => 'Cannot delete the last admin user.'
    ]);
    exit;
  }
}

// 4) Otherwise proceed with deletion
$del = $conn->prepare("DELETE FROM users WHERE user_id = ?");
$del->execute([$user_id]);
echo json_encode(['success' => true]);
