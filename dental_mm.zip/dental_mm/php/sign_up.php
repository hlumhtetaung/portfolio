<?php
session_start();
include "connect.php";

require __DIR__ . '/../PHPMailer-6.10.0/src/Exception.php';
require __DIR__ . '/../PHPMailer-6.10.0/src/PHPMailer.php';
require __DIR__ . '/../PHPMailer-6.10.0/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $address = trim($_POST['address']);
    $age = date_diff(date_create($dob), date_create('today'))->y;
    $last_visit = date('Y-m-d');
    $role = "patient";

    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $max_size = 2 * 1024 * 1024;
    $errorMsg = '';
    $successMsg = '';

    if (
        isset($_FILES['image'])
        && $_FILES['image']['error'] === UPLOAD_ERR_OK
        && in_array($_FILES['image']['type'], $allowed_types)
        && $_FILES['image']['size'] <= $max_size
    ) {
        $imgData = file_get_contents($_FILES['image']['tmp_name']);
    } else {
        $imgData = null;
        $errorMsg = "Invalid image! Only JPG, PNG, GIF, WEBP files up to 2MB are allowed.";
    }

    if ($imgData && empty($errorMsg)) {
        $sql = "INSERT INTO users 
            (first_name, last_name, age, gender, phone_number, email, password, address, last_visit_date, role, image) 
            VALUES (:fname, :lname, :age, :gender, :phone, :email, :password, :address, :visit, :role, :image)";
        try {
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':fname', $firstname, PDO::PARAM_STR);
            $stmt->bindParam(':lname', $lastname, PDO::PARAM_STR);
            $stmt->bindParam(':age', $age, PDO::PARAM_INT);
            $stmt->bindParam(':gender', $gender, PDO::PARAM_STR);
            $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':password', $password, PDO::PARAM_STR);
            $stmt->bindParam(':address', $address, PDO::PARAM_STR);
            $stmt->bindParam(':visit', $last_visit, PDO::PARAM_STR);
            $stmt->bindParam(':role', $role, PDO::PARAM_STR);
            $stmt->bindParam(':image', $imgData, PDO::PARAM_LOB);

            if ($stmt->execute()) {
                $_SESSION['user_id'] = $conn->lastInsertId();
                $_SESSION['firstname'] = $firstname;
                $_SESSION['lastname'] = $lastname;
                $_SESSION['logged_in'] = true;
                try {
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'coolapple2691@gmail.com';
                    $mail->Password   = 'izru xysg sobs pzyq';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port       = 587;

                    $mail->setFrom('coolapple2691@gmail.com', 'DentalMM Support');
                    $mail->addAddress($email, "$firstname $lastname");

                    $mail->isHTML(true);
                    $mail->Subject = "Welcome to DentalMM, $firstname!";
                    $mail->Body    = "
                                <h1>Hello $firstname,</h1>
                                <p>Thank you for registering at <strong>DentalMM</strong>!</p>
                                <p>We’re thrilled to have you on board.</p>
                                <hr>
                                <p>— The DentalMM Team</p>";

                    $mail->send();
                } catch (Exception $e) {
                    error_log('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');
                }
                header("Location: thank_you.php");
                exit();
            } else {
                $errorMsg = "Database error. Please try again.";
            }
        } catch (PDOException $e) {
            $errorMsg = "Database error: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dentalmm - Sign Up</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/sign_up.css">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <div class="logo">
                <h2>DentalMM</h2>
            </div>
            <nav class="nav">
                <a href="home.php">Home</a>
                <a href="services.php">Services</a>
                <a href="#dentists">Dentists</a>
                <a href="about-us.php">About</a>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="info-section">
                <h1>Welcome to Dentalmm</h1>
                <ul>
                    <li>🌟 Experienced and friendly dental team</li>
                    <li>🦷 Modern facilities & painless treatments</li>
                    <li>😃 Personalized, patient-centered care</li>
                    <li>🛰️ Convenient online booking & reminders</li>
                    <li>🎉 Affordable plans and flexible payment options</li>
                </ul>
            </div>
            <div class="form-section">
                <h2>Create Your Account</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="field">
                            <label for="firstname">First Name</label>
                            <input id="firstname" name="firstname" type="text" required>
                        </div>
                        <div class="field">
                            <label for="lastname">Last Name</label>
                            <input id="lastname" name="lastname" type="text" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label for="dob">Date of Birth</label>
                            <input id="dob" name="dob" type="date" required>
                        </div>
                        <div class="field">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender" required>
                                <option value="">Select</option>
                                <option>Female</option>
                                <option>Male</option>
                                <option>Non-binary</option>
                                <option>Prefer not to say</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label for="phone">Phone Number</label>
                            <input id="phone" name="phone" type="tel" required>
                        </div>
                        <div class="field">
                            <label for="email">Email</label>
                            <input id="email" name="email" type="email" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label for="password">Password</label>
                            <input id="password" name="password" type="password" required>
                        </div>
                        <div class="field">
                            <label for="address">Address</label>
                            <input id="address" name="address" type="text" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="field">
                            <label for="image">Profile Photo</label>
                            <div class="custom-file-input">
                                <input id="image" name="image" type="file" accept="image/*" required>
                                <button type="button" id="chooseImgBtn" class="choose-btn">Choose Image</button>
                                <span id="fileName" class="file-name">No file chosen</span>
                            </div>
                            <div class="img-preview" id="imgPreview"></div>
                        </div>
                    </div>
                    <button type="submit">Sign Up</button>
                </form>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-brand">
                <span class="footer-logo">DentalMM</span>
                <p>Your Smile, Our Passion</p>
            </div>
            <div class="footer-links">
                <a href="home.php">Home</a>
                <a href="#services">Services</a>
                <a href="#dentists">Dentists</a>
                <a href="about-us.php">About</a>
            </div>
            <div class="footer-contact">
                <p><strong>Contact:</strong> <a href="tel:+1234567890">09 123-4567</a></p>
                <p><strong>Email:</strong> <a href="mailto:info@dentalmm.com">info@dentalmm.com</a></p>
                <p>© <?php echo date("Y"); ?> Dentalmm. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        document.getElementById('chooseImgBtn').onclick = function() {
            document.getElementById('image').click();
        };

        document.getElementById('image').onchange = function(e) {
            const fileName = e.target.files[0]?.name || 'No file chosen';
            document.getElementById('fileName').innerText = fileName;

            const preview = document.getElementById('imgPreview');
            preview.innerHTML = "";
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(evt) {
                    const img = document.createElement('img');
                    img.src = evt.target.result;
                    preview.appendChild(img);
                }
                reader.readAsDataURL(e.target.files[0]);
            }
        };
    </script>
</body>

</html>