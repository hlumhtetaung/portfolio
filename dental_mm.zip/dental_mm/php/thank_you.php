<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DentalMM - Thank You</title>
    <link rel="stylesheet" href="../css/thank_you.css">
</head>
<body>
    <div class="container">
        <div class="tick-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-circle">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                <path d="m9 11 3 3L22 4"/>
            </svg>
        </div>
        <h1>Thank You from DentalMM team!</h1>
        <p>Welcome to <span class="website-name">dentalmm</span>. Thank you for choosing <span class="website-name">DentalMM</span>.</p>
        <p>We appreciate your trust in us and look forward to serving you.</p>
        <p>If you are making an appointment, please pay in your account.</p>
        <a href="home.php" class="button">Go to Homepage</a>
    </div>
</body>
</html>