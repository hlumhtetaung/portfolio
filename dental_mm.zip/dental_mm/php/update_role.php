<?php
require_once 'connect.php';
header('Content-Type: application/json');

// 1) Parse JSON input
$in = json_decode(file_get_contents('php://input'), true);
$user_id  = $in['user_id']  ?? null;
$new_role = $in['new_role'] ?? null;

if (!$user_id || !$new_role) {
  echo json_encode(['success' => false, 'error' => 'Missing user_id or new_role']);
  exit;
}

// 2) Fetch the user’s current role
$stmt = $conn->prepare("SELECT role FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
  echo json_encode(['success' => false, 'error' => 'User not found']);
  exit;
}

$old_role = $row['role'];

// 3) If they’re currently an admin and are being demoted…
if ($old_role === 'admin' && $new_role !== 'admin') {
  // count how many admins remain
  $adminCount = (int)$conn
    ->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")
    ->fetchColumn();

  if ($adminCount <= 1) {
    echo json_encode([
      'success' => false,
      'error'   => 'Cannot demote the last admin.'
    ]);
    exit;
  }
}

// 4) All good—perform the update
$upd = $conn->prepare("UPDATE users SET role = ? WHERE user_id = ?");
$upd->execute([$new_role, $user_id]);

echo json_encode(['success' => true]);
