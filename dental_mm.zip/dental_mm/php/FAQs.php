<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DentalMM - Frequently Asked Questions</title>
    <link rel="stylesheet" href="../css/FAQs.css">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <h1 class="header-title">DentalMM</h1>
                <p class="header-subtitle">Your Trusted Dental Care Partner</p>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <div class="container">
            <!-- Hero Section -->
            <section class="hero">
                <h2 class="hero-title">Frequently Asked Questions</h2>
                <p class="hero-description">
                    Find answers to common questions about our dental services, appointments, and patient care.
                </p>
            </section>

            <!-- Contact Info Cards -->
            <section class="contact-cards">
                <div class="card contact-card">
                    <div class="contact-icon">📞</div>
                    <h3 class="contact-title">Call Us</h3>
                    <p class="contact-subtitle">Schedule Today</p>
                </div>
                <div class="card contact-card">
                    <div class="contact-icon">🕒</div>
                    <h3 class="contact-title">Office Hours</h3>
                    <p class="contact-subtitle">Mon-Sat</p>
                </div>
                <div class="card contact-card">
                    <div class="contact-icon">📍</div>
                    <h3 class="contact-title">Location</h3>
                    <p class="contact-subtitle">Easy Parking</p>
                </div>
                <div class="card contact-card">
                    <div class="contact-icon">✉️</div>
                    <h3 class="contact-title">Emergency</h3>
                    <p class="contact-subtitle">24/7 Support</p>
                </div>
            </section>

            <!-- FAQ Sections -->
            <div class="faq-sections">
                <!-- General Information -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">General Information</h3>
                        <p class="section-description">Learn about our services and practice</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What services does DentalMM offer?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>DentalMM provides comprehensive dental care including routine cleanings, fillings, crowns, bridges, root canals, teeth whitening, orthodontics, oral surgery, and emergency dental services. We focus on both preventive and restorative dentistry to keep your smile healthy.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What are your office hours?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>We're open Monday through Friday from 8:00 AM to 6:00 PM, and Saturdays from 9:00 AM to 3:00 PM. We're closed on Sundays and major holidays. Emergency appointments may be available outside regular hours.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Where are you located?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Our modern dental facility is conveniently located with ample parking. Please visit our contact page for detailed directions and parking information.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Appointments & Scheduling -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">Appointments & Scheduling</h3>
                        <p class="section-description">Everything about booking and managing your visits</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>How do I schedule an appointment?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>You can schedule an appointment by calling our office, using our online booking system, or requesting an appointment through our website. We'll confirm your appointment within 24 hours.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>How far in advance should I book my appointment?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>For routine cleanings and check-ups, we recommend booking 2-3 weeks in advance. For urgent dental needs, we offer same-day or next-day appointments when possible.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What should I bring to my first appointment?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Please bring a valid ID, your insurance card, a list of current medications, and any previous dental records or X-rays. Arrive 15 minutes early to complete paperwork.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What is your cancellation policy?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>We require at least 24 hours notice for appointment cancellations or changes. Late cancellations or no-shows may incur a fee.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Insurance & Payment -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">Insurance & Payment</h3>
                        <p class="section-description">Payment options and insurance information</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Do you accept dental insurance?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, we accept most major dental insurance plans. Our team will verify your benefits and help maximize your coverage. We'll handle the insurance paperwork for you.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What payment methods do you accept?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>We accept cash, credit cards (Visa, MasterCard, American Express), debit cards, and offer flexible payment plans. We also work with CareCredit for financing options.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Do you offer payment plans?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, we offer flexible payment plans to make dental care affordable. We'll work with you to create a payment schedule that fits your budget.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Dental Procedures -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">Dental Procedures</h3>
                        <p class="section-description">Information about treatments and procedures</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>How often should I have a dental cleaning?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Most patients should have professional cleanings every 6 months. However, some patients with gum disease or other conditions may need more frequent cleanings every 3-4 months.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Are dental X-rays safe?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, dental X-rays are very safe. We use digital X-ray technology that reduces radiation exposure by up to 90% compared to traditional film X-rays. We only take X-rays when necessary for diagnosis.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>How long do dental procedures take?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Procedure times vary: routine cleanings take 45-60 minutes, fillings take 30-60 minutes, and crowns typically require two visits. We'll provide time estimates when scheduling your appointment.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Do you offer sedation options?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, we offer various sedation options including nitrous oxide (laughing gas) and oral sedation to help anxious patients feel comfortable during procedures.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Emergency Care -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">Emergency Care</h3>
                        <p class="section-description">Urgent dental care and after-hours support</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Do you handle dental emergencies?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, we provide emergency dental care for severe tooth pain, broken teeth, knocked-out teeth, and other urgent dental issues. Call our office immediately for emergency situations.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What should I do if I have a dental emergency after hours?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Call our office number - our answering service will connect you with our on-call dentist for urgent situations. For severe trauma, go to the nearest emergency room.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Oral Health -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">Oral Health</h3>
                        <p class="section-description">Prevention and care tips for healthy teeth</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>How can I prevent cavities?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Brush twice daily with fluoride toothpaste, floss daily, limit sugary and acidic foods, drink plenty of water, and visit us regularly for cleanings and check-ups.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>When should children first visit the dentist?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Children should have their first dental visit by age 1 or within 6 months of their first tooth appearing. Early visits help establish good oral health habits.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Do you treat children?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, we welcome patients of all ages and provide gentle, child-friendly dental care. Our team is experienced in making children feel comfortable during their visits.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Technology & Safety -->
                <section class="card faq-section">
                    <div class="section-header">
                        <h3 class="section-title">Technology & Safety</h3>
                        <p class="section-description">Our commitment to modern care and safety</p>
                    </div>
                    <div class="accordion">
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>What safety measures do you have in place?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>We follow strict sterilization protocols, use disposable items when possible, and maintain the highest standards of infection control. Our facility meets or exceeds all health department requirements.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-trigger" aria-expanded="false">
                                <span>Do you use modern dental technology?</span>
                                <span class="accordion-icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Yes, we use state-of-the-art equipment including digital X-rays, intraoral cameras, laser dentistry, and computer-aided design for crowns and bridges to provide the best possible care.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Contact CTA -->
            <section class="card cta-section">
                <div class="cta-content">
                    <h3 class="cta-title">Still Have Questions?</h3>
                    <p class="cta-description">Contact our friendly team at DentalMM - we're always happy to help!</p>
                    <div class="cta-buttons">
                        <button class="btn btn-primary" onclick="window.location.href='services.php'">View Services</button>
                        <button class="btn btn-secondary" onclick="window.location.href='dentists_customer.php'">View Dentists</button>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <h4 class="footer-title">DentalMM</h4>
                <p class="footer-subtitle">Professional Dental Care You Can Trust</p>
            </div>
        </div>
    </footer>

    <script>
        // Accordion functionality
        document.addEventListener('DOMContentLoaded', function() {
            const accordionTriggers = document.querySelectorAll('.accordion-trigger');

            accordionTriggers.forEach(trigger => {
                trigger.addEventListener('click', function() {
                    const isExpanded = this.getAttribute('aria-expanded') === 'true';
                    const content = this.nextElementSibling;
                    const icon = this.querySelector('.accordion-icon');

                    // Close all other accordions in the same section
                    const accordion = this.closest('.accordion');
                    const allTriggers = accordion.querySelectorAll('.accordion-trigger');
                    const allContents = accordion.querySelectorAll('.accordion-content');
                    const allIcons = accordion.querySelectorAll('.accordion-icon');

                    allTriggers.forEach(t => t.setAttribute('aria-expanded', 'false'));
                    allContents.forEach(c => c.style.maxHeight = '0');
                    allIcons.forEach(i => i.textContent = '+');

                    // Toggle current accordion
                    if (!isExpanded) {
                        this.setAttribute('aria-expanded', 'true');
                        content.style.maxHeight = content.scrollHeight + 'px';
                        icon.textContent = '−';
                    }
                });
            });
        });
    </script>
</body>

</html>