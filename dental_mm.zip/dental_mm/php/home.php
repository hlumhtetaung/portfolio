<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DentalMM - Professional Dental Care</title>
    <link rel="stylesheet" href="../css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <h2>DentalMM</h2>
            </div>
            <nav class="nav">
                <a href="#">Home</a>
                <a href="#services">Services</a>
                <a href="dentists_customer.php">Dentists</a>
                <a href="about-us.php">About</a>
                <a href="#contact">Contact</a>
                <a href="appointment.php">Make Appointment</a>
                <a href="FAQs.php">FAQs</a>
            </nav>
            <div class="header-cta user-dropdown-parent">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                    <img src="profile_image.php" alt="Profile Photo" class="user-icon" id="userDropdownBtn">
                    <div class="user-dropdown" id="userDropdownMenu">
                        <p class="user_name"><?php echo htmlspecialchars($_SESSION['firstname'] . ' ' . $_SESSION['lastname']); ?></p>
                        <a href="user_profile.php">My Profile</a>
                        <a href="user_appointments.php">Appointments</a>
                        <a href="payment.php">Payment</a>
                        <a href="logout.php">Log Out</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="btn-secondary">Sign In</a>
                    <a href="sign_up.php" class="btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1>Your Smile is Our Priority</h1>
                    <p>Experience exceptional dental care with our team of experienced professionals. We provide comprehensive dental services in a comfortable, modern environment.</p>
                    <div class="hero-buttons">
                        <a href="appointment.php" class="btn-primary">Schedule Appointment</a>
                        <a href="dentists_customer.php" class="btn-outline">Our Dentists</a>
                    </div>
                </div>
                <div class="hero-image">
                    <img src="../images/Modern-Dental-Office.webp" alt="Modern Dental Office">
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <div class="section-header">
                <h2>Our Services</h2>
                <p>Comprehensive dental care for the whole family</p>
            </div>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">🦷</div>
                    <h3>General Dentistry</h3>
                    <p>Regular checkups, cleanings, and preventive care to maintain optimal oral health.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">✨</div>
                    <h3>Cosmetic Dentistry</h3>
                    <p>Teeth whitening, veneers, and smile makeovers to enhance your appearance.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">🔧</div>
                    <h3>Restorative Care</h3>
                    <p>Crowns, bridges, and implants to restore function and aesthetics.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">👶</div>
                    <h3>Pediatric Dentistry</h3>
                    <p>Specialized care for children in a friendly, comfortable environment.</p>
                </div>
            </div>
        </div>
        <center><a href="services.php" class="btn-outline">View Services</a></center>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>About DentalMM</h2>
                    <p>With over 15 years of experience, DentalMM has been providing exceptional dental care to families in our community. Our state-of-the-art facility and experienced team ensure you receive the highest quality treatment.</p>
                    <div class="stats">
                        <div class="stat">
                            <h3>5000+</h3>
                            <p>Happy Patients</p>
                        </div>
                        <div class="stat">
                            <h3>15+</h3>
                            <p>Years Experience</p>
                        </div>
                        <div class="stat">
                            <h3>98%</h3>
                            <p>Success Rate</p>
                        </div>
                    </div>
                    <a href="about-us.php" class="btn-outline">Learn More</a>
                </div>
                <div class="about-image">
                    <img src="../images/Professional-Dentist.webp" alt="Professional Dentist">
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-header">
                <h2>Contact Us</h2>
                <p>Get in touch to schedule your appointment</p>
            </div>
            <div class="contact-content">
                <div class="contact-info">
                    <div class="contact-item">
                        <h4>📍 Address</h4>
                        <p>123 Dental Street<br>Medical District, MD 12345</p>
                    </div>
                    <div class="contact-item">
                        <h4>📞 Phone</h4>
                        <p>09 123-4567</p>
                    </div>
                    <div class="contact-item">
                        <h4>✉️ Email</h4>
                        <p>info@dentalmm.com</p>
                    </div>
                    <div class="contact-item">
                        <h4>🕒 Hours</h4>
                        <p>Mon-Fri: 8:00 AM - 6:00 PM<br>Sat: 9:00 AM - 3:00 PM</p>
                    </div>
                </div>
                <form class="contact-form" method="POST" action="home.php">
                    <input type="text" name="name" placeholder="Your Name" required>
                    <textarea name="message" placeholder="Your Message" rows="8" required></textarea>
                    <button type="submit" class="btn-primary">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <h3>DentalMM</h3>
                    <p>Professional dental care you can trust</p>
                </div>
                <div class="footer-links">
                    <a href="#">Home</a>
                    <a href="services.php">Services</a>
                    <a href="dentists_customer.php">Dentists</a>
                    <a href="about-us.php">About</a>
                    <a href="appointment.php">Make Appointment</a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> DentalMM. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var btn = document.getElementById('userDropdownBtn');
            var menu = document.getElementById('userDropdownMenu');
            if (btn && menu) {
                btn.onclick = function(e) {
                    menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
                    e.stopPropagation();
                };
                document.body.addEventListener('click', function() {
                    menu.style.display = 'none';
                });
            }
        });
    </script>
</body>

<?php
include "connect.php";
if (isset($_POST['name']) && isset($_POST['message'])) {
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
        $user_id = $_SESSION['user_id'];
        $name = htmlspecialchars($_POST['name']);
        $message = htmlspecialchars($_POST['message']);
        $submitted_at = date('Y-m-d H:i:s');

        $sql = "INSERT INTO contact_us (user_id, name, message, submitted_date) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$user_id, $name, $message, $submitted_at]);

        if ($stmt) {
            echo "<script>alert('Message sent successfully!');</script>";
        } else {
            echo "<script>alert('Failed to send message. Please try again later.');</script>";
        }
    } else {
        echo "<script>alert('Please log in to send a message.');</script>";
    }
}
?>

</html>