This is the dental clinic website that can do basic tasks such as appointments and checking services.

The website should start running from home.php and will need xampp to run it.
Download xampp application, start Apache and MySQL servers, and run home.php.

You will also need to import the sql database into your MySQL server in xampp.

*Please note that the website might contain flaws.

Thank you!